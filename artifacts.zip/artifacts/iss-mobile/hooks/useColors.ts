import { useTheme } from "@/context/ThemeContext";

/**
 * Returns the active design tokens for the app.
 *
 * The palette is driven by the user's chosen THEME + ACCENT (see
 * ThemeContext / constants/themes.ts), mirroring the web app's theme picker.
 * Defaults to Light + Indigo, exactly like the web app.
 */
export function useColors() {
  return useTheme().colors;
}
