import type { User } from "@workspace/api-client-react";

/** Mirrors the web app's all-centers viewer predicate. */
export function isAllCentersViewer(
  u: { department?: string | null } | null | undefined
): boolean {
  return !!u && (u.department === "MIS" || u.department === "Director");
}

/** Role-derived flags used to gate the "More" menu destinations. */
export function roleFlags(user: User | null | undefined) {
  const isBoss = user?.department === "Management" || user?.role === "Boss";
  const isCenterHead = user?.role === "Center Head";
  const isMis = isAllCentersViewer(user);
  const isTl = user?.role === "Team Leader";
  return { isBoss, isCenterHead, isMis, isTl };
}

export function canSeeAttendance(user: User | null | undefined): boolean {
  const { isBoss, isCenterHead, isMis } = roleFlags(user);
  return isBoss || isCenterHead || isMis;
}

export function canSeeEod(user: User | null | undefined): boolean {
  const { isBoss, isCenterHead, isMis, isTl } = roleFlags(user);
  return isBoss || isCenterHead || isMis || isTl;
}

/** Boss / MIS may manage master data (create/delete categories, users, etc.). */
export function canManage(user: User | null | undefined): boolean {
  const { isBoss, isMis } = roleFlags(user);
  return isBoss || isMis;
}

/**
 * Canonical display order of the company's centers. Head Office first, then the
 * outer centers. Mirrors the web app's `CENTER_ORDER`.
 */
export const CENTER_ORDER = [
  "Head Office",
  "Thane Center",
  "Malad Center",
  "Pune Center",
  "Navi Mumbai Center",
];

/**
 * A single navigation entry / controllable app section. Mirrors the web app's
 * `NavItem` in `iss-task-pro/src/lib/permissions.ts`.
 *   - `always`  → page can never be restricted (Dashboard).
 *   - `system`  → page governed by role defaults ONLY, never per-user override
 *                 (Access Control itself).
 */
export interface NavItem {
  href: string;
  label: string;
  icon: string;
  bossOnly?: boolean;
  teamOnly?: boolean;
  centerHead?: boolean;
  mis?: boolean;
  tl?: boolean;
  accounts?: boolean;
  always?: boolean;
  system?: boolean;
}

export const NAV_ITEMS: NavItem[] = [
  { href: "/", label: "Dashboard", icon: "📊" },
  { href: "/my-tasks", label: "My Tasks", icon: "✅" },
  { href: "/tasks", label: "All Tasks", icon: "📋" },
  { href: "/tasks/daily", label: "Daily Tasks", icon: "📅" },
  { href: "/tasks/weekly", label: "Weekly Tasks", icon: "📆" },
  { href: "/tasks/monthly", label: "Monthly Tasks", icon: "🗓" },
  { href: "/assign", label: "Assign Task", icon: "➕" },
  { href: "/team", label: "Team", icon: "👥" },
  { href: "/holidays", label: "Holidays", icon: "🎉" },
  { href: "/attendance", label: "Attendance", icon: "🗓", bossOnly: true, centerHead: true, mis: true },
  { href: "/eod", label: "EOD Report", icon: "📝", bossOnly: true, centerHead: true, tl: true, mis: true },
  { href: "/hierarchy", label: "Credentials & Hierarchy", icon: "🔑", bossOnly: true, centerHead: true, mis: true },
  { href: "/monitor", label: "Assignment Monitor", icon: "🕵", bossOnly: true, centerHead: true, mis: true },
  { href: "/access", label: "Access Control", icon: "🔐", bossOnly: true, mis: true, system: true },
  { href: "/reports", label: "Reports", icon: "📈" },
  { href: "/sales-report", label: "Sales Report", icon: "💰", bossOnly: true, centerHead: true, tl: true, mis: true },
  { href: "/settings", label: "Email Settings", icon: "✉", bossOnly: true, mis: true },
];

/** Sections a Boss/MIS may turn on/off per user (excludes always-on & system). */
export const CONTROLLABLE_ITEMS = NAV_ITEMS.filter((i) => !i.always && !i.system);

/**
 * Build the full recursive org-chart subtree under `rootId`.
 * Returns a Set of user IDs: rootId + all direct & indirect reports.
 */
export function buildHierarchySet(
  rootId: number,
  allUsers: { id: number; reportsTo?: number | null }[]
): Set<number> {
  const result = new Set<number>([rootId]);
  const queue = [rootId];
  while (queue.length > 0) {
    const parentId = queue.shift()!;
    for (const u of allUsers) {
      if (u.reportsTo === parentId && !result.has(u.id)) {
        result.add(u.id);
        queue.push(u.id);
      }
    }
  }
  return result;
}

/**
 * Whether a section is visible to a user purely by their role/department/team —
 * the behaviour before any manual per-user override is applied. Mirrors the web
 * app's `roleDefaultVisible`.
 */
export function roleDefaultVisible(
  item: NavItem,
  user:
    | { id: number; role?: string | null; department?: string | null }
    | null
    | undefined,
  allUsers: { id: number; reportsTo?: number | null }[]
): boolean {
  if (!user) return false;
  const isBoss = user.department === "Management" || user.role === "Boss";
  const isCenterHead = user.role === "Center Head";
  const isMis = isAllCentersViewer(user);
  const isTl = user.role === "Team Leader";
  const isAccounts = user.department === "Accounts";
  const hasTeam = buildHierarchySet(user.id, allUsers).size > 1;

  if (
    item.bossOnly &&
    !isBoss &&
    !(item.centerHead && isCenterHead) &&
    !(item.mis && isMis) &&
    !(item.tl && isTl) &&
    !(item.accounts && isAccounts)
  ) {
    return false;
  }
  if (item.teamOnly && !isBoss && !hasTeam && !(item.mis && isMis)) return false;
  return true;
}
