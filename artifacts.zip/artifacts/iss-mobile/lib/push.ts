import { subscribeExpoPush, unsubscribeExpoPush } from "@workspace/api-client-react";
import Constants from "expo-constants";
import * as Device from "expo-device";
import * as Notifications from "expo-notifications";
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

// Persist the device's Expo token so sign-out can still unregister it even
// after a cold start (the in-memory copy is gone on a fresh launch).
const PUSH_TOKEN_KEY = "iss_expo_push_token";

// Foreground behaviour: still show the banner + play sound while the app is open.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

let lastToken: string | null = null;

async function readStoredToken(): Promise<string | null> {
  if (lastToken) return lastToken;
  try {
    return await SecureStore.getItemAsync(PUSH_TOKEN_KEY);
  } catch {
    return null;
  }
}

/**
 * Ask for permission, get this device's Expo push token, and register it on
 * the server for the given user. Safe to call repeatedly (idempotent upsert).
 * No-ops on simulators/web where push isn't available.
 */
export async function registerForPush(userId: number): Promise<void> {
  try {
    if (!Device.isDevice) return;

    if (Platform.OS === "android") {
      await Notifications.setNotificationChannelAsync("default", {
        name: "Task Alerts",
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: "#6366f1",
      });
    }

    const existing = await Notifications.getPermissionsAsync();
    let status = existing.status;
    if (status !== "granted") {
      const req = await Notifications.requestPermissionsAsync();
      status = req.status;
    }
    if (status !== "granted") return;

    const projectId =
      Constants.expoConfig?.extra?.eas?.projectId ??
      (Constants as unknown as { easConfig?: { projectId?: string } }).easConfig?.projectId;
    if (!projectId) return;

    const tokenResp = await Notifications.getExpoPushTokenAsync({ projectId });
    const token = tokenResp.data;
    lastToken = token;
    try {
      await SecureStore.setItemAsync(PUSH_TOKEN_KEY, token);
    } catch {
      // non-fatal — in-memory copy still works for this session
    }
    await subscribeExpoPush({ userId, token });
  } catch {
    // Push is best-effort — never block sign-in on it.
  }
}

/** Remove this device's token on sign-out so a new user doesn't inherit alerts. */
export async function unregisterForPush(): Promise<void> {
  try {
    const token = await readStoredToken();
    if (token) await unsubscribeExpoPush({ token });
  } catch {
    // ignore — clearing local session regardless
  } finally {
    lastToken = null;
    try {
      await SecureStore.deleteItemAsync(PUSH_TOKEN_KEY);
    } catch {
      // ignore
    }
  }
}
