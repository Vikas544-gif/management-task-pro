import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

import {
  ACCENTS,
  AppColors,
  AccentName,
  buildColors,
  isDarkTheme,
  THEMES,
  ThemeName,
} from "@/constants/themes";

const STORAGE_KEY = "iss_theme";

interface ThemeState {
  theme: ThemeName;
  accent: AccentName;
  colors: AppColors;
  isDark: boolean;
  setTheme: (t: ThemeName) => void;
  setAccent: (a: AccentName) => void;
}

const ThemeContext = createContext<ThemeState | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<ThemeName>("light");
  const [accent, setAccentState] = useState<AccentName>("indigo");
  const [hydrated, setHydrated] = useState(false);

  // Hydrate the saved choice once on mount.
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (THEMES.some((t) => t.id === parsed?.theme)) setThemeState(parsed.theme);
          if (ACCENTS.some((a) => a.id === parsed?.accent)) setAccentState(parsed.accent);
        }
      } catch {
        /* ignore */
      } finally {
        setHydrated(true);
      }
    })();
  }, []);

  // Persist whenever the committed theme/accent pair changes (post-hydration),
  // so storage always reflects the final state even under rapid toggles.
  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ theme, accent })).catch(() => {});
  }, [theme, accent, hydrated]);

  const value = useMemo<ThemeState>(
    () => ({
      theme,
      accent,
      colors: buildColors(theme, accent),
      isDark: isDarkTheme(theme),
      setTheme: setThemeState,
      setAccent: setAccentState,
    }),
    [theme, accent],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeState {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within a ThemeProvider");
  return ctx;
}
