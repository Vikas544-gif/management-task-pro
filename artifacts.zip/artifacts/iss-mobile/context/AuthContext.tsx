import type { User } from "@workspace/api-client-react";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import * as SecureStore from "expo-secure-store";
import React, { createContext, useContext, useEffect, useState } from "react";

import { registerForPush, unregisterForPush } from "@/lib/push";

const TOKEN_KEY = "iss_token";
const USER_KEY = "iss_user";

// Module-level token so the fetch auth getter always reads the latest value,
// even outside React render. Registered once at import time.
let currentToken: string | null = null;
setAuthTokenGetter(() => currentToken);

interface AuthContextValue {
  user: User | null;
  token: string | null;
  loading: boolean;
  signIn: (user: User, token: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const t = await SecureStore.getItemAsync(TOKEN_KEY);
        const u = await SecureStore.getItemAsync(USER_KEY);
        // Only treat the session as authenticated when BOTH a token and a
        // cached user exist — a user without a valid token must not unlock
        // protected routes.
        if (t && u) {
          currentToken = t;
          setToken(t);
          const restored = JSON.parse(u) as User;
          setUser(restored);
          // Re-register this device for push on every launch (token can rotate).
          void registerForPush(restored.id);
        } else {
          currentToken = null;
        }
      } catch {
        // ignore — treat as logged out
        currentToken = null;
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const signIn = async (nextUser: User, nextToken: string) => {
    // Drop any data cached under a previous session before the new one loads.
    queryClient.clear();
    currentToken = nextToken;
    setToken(nextToken);
    setUser(nextUser);
    await SecureStore.setItemAsync(TOKEN_KEY, nextToken);
    await SecureStore.setItemAsync(USER_KEY, JSON.stringify(nextUser));
    // Register this device for phone push under the freshly signed-in user.
    void registerForPush(nextUser.id);
  };

  const signOut = async () => {
    // Drop this device's push token first (needs the auth token to be valid).
    await unregisterForPush();
    currentToken = null;
    setToken(null);
    setUser(null);
    await SecureStore.deleteItemAsync(TOKEN_KEY);
    await SecureStore.deleteItemAsync(USER_KEY);
    // Prevent stale user-scoped data from leaking to the next account.
    queryClient.clear();
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
