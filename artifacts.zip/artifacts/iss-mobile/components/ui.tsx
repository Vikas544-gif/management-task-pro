import { Feather } from "@expo/vector-icons";
import React from "react";
import {
  ActivityIndicator,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleProp,
  StyleSheet,
  Text,
  TextInput,
  View,
  ViewStyle,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";

/** Top inset: real safe-area on native, fixed status-bar allowance on web. */
export function useTopInset() {
  const insets = useSafeAreaInsets();
  return Platform.OS === "web" ? 67 : insets.top;
}

/** Bottom padding that clears the floating tab bar. */
export function useTabContentPadding() {
  const insets = useSafeAreaInsets();
  return Platform.OS === "web" ? 100 : insets.bottom + 80;
}

export function AppHeader({
  title,
  subtitle,
  right,
}: {
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
}) {
  const colors = useColors();
  const topInset = useTopInset();
  return (
    <View
      style={[
        styles.header,
        { paddingTop: topInset + 8, backgroundColor: colors.background, borderBottomColor: colors.border },
      ]}
    >
      <View style={{ flex: 1 }}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]} numberOfLines={1}>
          {title}
        </Text>
        {subtitle ? (
          <Text style={[styles.headerSubtitle, { color: colors.mutedForeground }]} numberOfLines={1}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {right}
    </View>
  );
}

export function Card({
  children,
  style,
}: {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.card,
        { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
        style,
      ]}
    >
      {children}
    </View>
  );
}

type ButtonVariant = "primary" | "secondary" | "destructive";

export function Button({
  label,
  onPress,
  variant = "primary",
  icon,
  loading,
  disabled,
  style,
}: {
  label: string;
  onPress: () => void;
  variant?: ButtonVariant;
  icon?: keyof typeof Feather.glyphMap;
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
}) {
  const colors = useColors();
  const bg =
    variant === "primary"
      ? colors.primary
      : variant === "destructive"
        ? colors.destructive
        : colors.secondary;
  const fg =
    variant === "primary"
      ? colors.primaryForeground
      : variant === "destructive"
        ? colors.destructiveForeground
        : colors.secondaryForeground;
  const isDisabled = disabled || loading;
  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: bg, borderRadius: colors.radius, opacity: isDisabled ? 0.5 : pressed ? 0.85 : 1 },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} size="small" />
      ) : (
        <>
          {icon ? <Feather name={icon} size={16} color={fg} /> : null}
          <Text style={[styles.buttonText, { color: fg }]}>{label}</Text>
        </>
      )}
    </Pressable>
  );
}

const STATUS_META: Record<string, { label: string; key: "warning" | "primary" | "success" }> = {
  pending: { label: "Pending", key: "warning" },
  inProgress: { label: "In Progress", key: "primary" },
  done: { label: "Done", key: "success" },
};

export function StatusPill({ status }: { status: string }) {
  const colors = useColors();
  const meta = STATUS_META[status] ?? { label: status, key: "primary" as const };
  const color = colors[meta.key];
  return (
    <View style={[styles.pill, { backgroundColor: color + "22" }]}>
      <View style={[styles.pillDot, { backgroundColor: color }]} />
      <Text style={[styles.pillText, { color }]}>{meta.label}</Text>
    </View>
  );
}

export function PriorityBadge({ priority }: { priority: string }) {
  const colors = useColors();
  const color =
    priority === "high" ? colors.destructive : priority === "low" ? colors.mutedForeground : colors.warning;
  return (
    <View style={[styles.priority, { borderColor: color }]}>
      <Text style={[styles.priorityText, { color }]}>{priority.toUpperCase()}</Text>
    </View>
  );
}

export function EmptyState({
  icon = "inbox",
  title,
  message,
}: {
  icon?: keyof typeof Feather.glyphMap;
  title: string;
  message?: string;
}) {
  const colors = useColors();
  return (
    <View style={styles.centerBox}>
      <Feather name={icon} size={44} color={colors.mutedForeground} />
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      {message ? (
        <Text style={[styles.emptyMessage, { color: colors.mutedForeground }]}>{message}</Text>
      ) : null}
    </View>
  );
}

export function LoadingState() {
  const colors = useColors();
  return (
    <View style={styles.centerBox}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );
}

export function ErrorState({ onRetry }: { onRetry?: () => void }) {
  const colors = useColors();
  return (
    <View style={styles.centerBox}>
      <Feather name="alert-triangle" size={40} color={colors.destructive} />
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Something went wrong</Text>
      <Text style={[styles.emptyMessage, { color: colors.mutedForeground }]}>
        Could not load data. Please try again.
      </Text>
      {onRetry ? <Button label="Retry" icon="refresh-cw" onPress={onRetry} style={{ marginTop: 16 }} /> : null}
    </View>
  );
}

export function FieldLabel({ children }: { children: React.ReactNode }) {
  const colors = useColors();
  return <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>{children}</Text>;
}

export function TextField({
  label,
  value,
  onChangeText,
  placeholder,
  multiline,
  keyboardType,
}: {
  label?: string;
  value: string;
  onChangeText: (t: string) => void;
  placeholder?: string;
  multiline?: boolean;
  keyboardType?: "default" | "numeric" | "email-address";
}) {
  const colors = useColors();
  return (
    <View style={{ gap: 6 }}>
      {label ? <FieldLabel>{label}</FieldLabel> : null}
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.mutedForeground}
        multiline={multiline}
        keyboardType={keyboardType}
        style={[
          styles.input,
          {
            color: colors.foreground,
            backgroundColor: colors.card,
            borderColor: colors.border,
            borderRadius: colors.radius,
            minHeight: multiline ? 88 : 46,
            textAlignVertical: multiline ? "top" : "center",
          },
        ]}
      />
    </View>
  );
}

export type Option = { label: string; value: string };

export function Select({
  label,
  value,
  options,
  onChange,
  placeholder = "Select…",
}: {
  label?: string;
  value: string | null;
  options: Option[];
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  const colors = useColors();
  const [open, setOpen] = React.useState(false);
  const selected = options.find((o) => o.value === value);
  return (
    <View style={{ gap: 6 }}>
      {label ? <FieldLabel>{label}</FieldLabel> : null}
      <Pressable
        onPress={() => setOpen(true)}
        style={[
          styles.input,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
            borderRadius: colors.radius,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          },
        ]}
      >
        <Text
          style={{
            fontFamily: "Inter_500Medium",
            fontSize: 15,
            color: selected ? colors.foreground : colors.mutedForeground,
            flex: 1,
          }}
          numberOfLines={1}
        >
          {selected ? selected.label : placeholder}
        </Text>
        <Feather name="chevron-down" size={18} color={colors.mutedForeground} />
      </Pressable>
      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setOpen(false)}>
          <Pressable
            style={[styles.modalSheet, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={(e) => e.stopPropagation()}
          >
            {label ? (
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>{label}</Text>
            ) : null}
            <ScrollView style={{ maxHeight: 360 }}>
              {options.length === 0 ? (
                <Text style={{ fontFamily: "Inter_400Regular", color: colors.mutedForeground, padding: 16 }}>
                  No options available.
                </Text>
              ) : (
                options.map((o) => {
                  const active = o.value === value;
                  return (
                    <Pressable
                      key={o.value}
                      onPress={() => {
                        onChange(o.value);
                        setOpen(false);
                      }}
                      style={[styles.modalRow, { borderBottomColor: colors.border }]}
                    >
                      <Text
                        style={{
                          flex: 1,
                          fontFamily: active ? "Inter_600SemiBold" : "Inter_400Regular",
                          fontSize: 15,
                          color: active ? colors.primary : colors.foreground,
                        }}
                      >
                        {o.label}
                      </Text>
                      {active ? <Feather name="check" size={18} color={colors.primary} /> : null}
                    </Pressable>
                  );
                })
              )}
            </ScrollView>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

export function Segmented({
  options,
  value,
  onChange,
}: {
  options: Option[];
  value: string;
  onChange: (value: string) => void;
}) {
  const colors = useColors();
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ gap: 8, paddingRight: 4 }}
    >
      {options.map((o) => {
        const active = o.value === value;
        return (
          <Pressable
            key={o.value}
            onPress={() => onChange(o.value)}
            style={[
              styles.segment,
              {
                backgroundColor: active ? colors.primary : colors.card,
                borderColor: active ? colors.primary : colors.border,
                borderRadius: 999,
              },
            ]}
          >
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 13,
                color: active ? colors.primaryForeground : colors.mutedForeground,
              }}
            >
              {o.label}
            </Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingBottom: 14,
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  headerTitle: { fontFamily: "Inter_700Bold", fontSize: 26 },
  headerSubtitle: { fontFamily: "Inter_400Regular", fontSize: 14, marginTop: 2 },
  card: { borderWidth: StyleSheet.hairlineWidth, padding: 16 },
  button: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 18,
  },
  buttonText: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  pill: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  pillDot: { width: 7, height: 7, borderRadius: 999 },
  pillText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  priority: { borderWidth: 1, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  priorityText: { fontFamily: "Inter_600SemiBold", fontSize: 11, letterSpacing: 0.5 },
  centerBox: { flex: 1, alignItems: "center", justifyContent: "center", padding: 32, gap: 10 },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 17, marginTop: 6 },
  emptyMessage: { fontFamily: "Inter_400Regular", fontSize: 14, textAlign: "center", lineHeight: 20 },
  fieldLabel: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.4, marginLeft: 2 },
  input: {
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontFamily: "Inter_500Medium",
    fontSize: 15,
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.45)",
    justifyContent: "center",
    padding: 24,
  },
  modalSheet: { borderWidth: StyleSheet.hairlineWidth, borderRadius: 16, padding: 8, maxHeight: "80%" },
  modalTitle: { fontFamily: "Inter_700Bold", fontSize: 16, padding: 12 },
  modalRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  segment: { paddingHorizontal: 14, paddingVertical: 8, borderWidth: StyleSheet.hairlineWidth },
});
