import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Svg, { Circle, G, Line, Path, Polyline, Rect } from "react-native-svg";

import { useColors } from "@/hooks/useColors";

export const CHART_COLORS = {
  pending: "#ef4444",
  inProgress: "#f59e0b",
  done: "#22c55e",
  total: "#3b82f6",
  purple: "#8b5cf6",
  slate: "#64748b",
};

function niceMax(v: number) {
  if (v <= 0) return 1;
  return v;
}

/* Donut / status distribution */
export function DonutChart({
  data,
  size = 150,
  strokeWidth = 22,
}: {
  data: { label: string; value: number; color: string }[];
  size?: number;
  strokeWidth?: number;
}) {
  const colors = useColors();
  const total = data.reduce((s, d) => s + d.value, 0);
  const r = (size - strokeWidth) / 2;
  const c = 2 * Math.PI * r;
  const cx = size / 2;
  const cy = size / 2;

  let offset = 0;
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 16 }}>
      <Svg width={size} height={size}>
        <G rotation={-90} originX={cx} originY={cy}>
          <Circle cx={cx} cy={cy} r={r} stroke={colors.border} strokeWidth={strokeWidth} fill="none" />
          {total > 0 &&
            data.map((d, i) => {
              const frac = d.value / total;
              const dash = frac * c;
              const seg = (
                <Circle
                  key={i}
                  cx={cx}
                  cy={cy}
                  r={r}
                  stroke={d.color}
                  strokeWidth={strokeWidth}
                  fill="none"
                  strokeDasharray={`${dash} ${c - dash}`}
                  strokeDashoffset={-offset}
                  strokeLinecap="butt"
                />
              );
              offset += dash;
              return seg;
            })}
        </G>
      </Svg>
      <View style={{ gap: 8, flex: 1 }}>
        <Text style={{ fontFamily: "Inter_700Bold", fontSize: 22, color: colors.foreground }}>{total}</Text>
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, marginTop: -6 }}>
          Total tasks
        </Text>
        {data.map((d) => (
          <View key={d.label} style={legend.row}>
            <View style={[legend.dot, { backgroundColor: d.color }]} />
            <Text style={[legend.label, { color: colors.mutedForeground }]}>{d.label}</Text>
            <Text style={[legend.val, { color: colors.foreground }]}>{d.value}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

/* Single-series vertical bars (priority breakdown) */
export function BarChart({
  data,
  width,
  height = 160,
}: {
  data: { label: string; value: number; color?: string }[];
  width: number;
  height?: number;
}) {
  const colors = useColors();
  const pad = { top: 12, bottom: 26, left: 6, right: 6 };
  const chartH = height - pad.top - pad.bottom;
  const max = niceMax(Math.max(...data.map((d) => d.value), 0));
  const n = data.length || 1;
  const slot = (width - pad.left - pad.right) / n;
  const barW = Math.min(slot * 0.55, 46);

  return (
    <View>
      <Svg width={width} height={height}>
        <Line x1={pad.left} y1={pad.top + chartH} x2={width - pad.right} y2={pad.top + chartH} stroke={colors.border} strokeWidth={1} />
        {data.map((d, i) => {
          const h = max > 0 ? (d.value / max) * chartH : 0;
          const x = pad.left + slot * i + (slot - barW) / 2;
          const y = pad.top + chartH - h;
          return <Rect key={i} x={x} y={y} width={barW} height={Math.max(h, 1)} rx={4} fill={d.color ?? CHART_COLORS.total} />;
        })}
      </Svg>
      <View style={[bars.labelRow, { width }]}>
        {data.map((d) => (
          <View key={d.label} style={{ width: slot, alignItems: "center" }}>
            <Text style={[bars.value, { color: colors.foreground }]}>{d.value}</Text>
            <Text style={[bars.label, { color: colors.mutedForeground }]} numberOfLines={1}>
              {d.label}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}

/* Grouped bars: done vs pending per day */
export function GroupedBarChart({
  data,
  width,
  height = 180,
}: {
  data: { label: string; done: number; pending: number }[];
  width: number;
  height?: number;
}) {
  const colors = useColors();
  const pad = { top: 12, bottom: 26, left: 6, right: 6 };
  const chartH = height - pad.top - pad.bottom;
  const max = niceMax(Math.max(...data.flatMap((d) => [d.done, d.pending]), 0));
  const n = data.length || 1;
  const slot = (width - pad.left - pad.right) / n;
  const barW = Math.min(slot * 0.32, 16);
  const gap = 3;

  return (
    <View>
      <Svg width={width} height={height}>
        <Line x1={pad.left} y1={pad.top + chartH} x2={width - pad.right} y2={pad.top + chartH} stroke={colors.border} strokeWidth={1} />
        {data.map((d, i) => {
          const groupCenter = pad.left + slot * i + slot / 2;
          const doneH = max > 0 ? (d.done / max) * chartH : 0;
          const pendH = max > 0 ? (d.pending / max) * chartH : 0;
          const baseY = pad.top + chartH;
          return (
            <G key={i}>
              <Rect x={groupCenter - barW - gap / 2} y={baseY - doneH} width={barW} height={Math.max(doneH, d.done > 0 ? 1 : 0)} rx={3} fill={CHART_COLORS.done} />
              <Rect x={groupCenter + gap / 2} y={baseY - pendH} width={barW} height={Math.max(pendH, d.pending > 0 ? 1 : 0)} rx={3} fill={CHART_COLORS.pending} />
            </G>
          );
        })}
      </Svg>
      <View style={[bars.labelRow, { width }]}>
        {data.map((d, i) => (
          <View key={i} style={{ width: slot, alignItems: "center" }}>
            <Text style={[bars.label, { color: colors.mutedForeground }]} numberOfLines={1}>
              {d.label}
            </Text>
          </View>
        ))}
      </View>
      <Legend items={[{ label: "Done", color: CHART_COLORS.done }, { label: "Pending", color: CHART_COLORS.pending }]} />
    </View>
  );
}

/* Line trend: completed vs total due */
export function LineTrend({
  data,
  width,
  height = 180,
}: {
  data: { label: string; completed: number; total: number }[];
  width: number;
  height?: number;
}) {
  const colors = useColors();
  const pad = { top: 14, bottom: 26, left: 8, right: 8 };
  const chartH = height - pad.top - pad.bottom;
  const max = niceMax(Math.max(...data.flatMap((d) => [d.completed, d.total]), 0));
  const n = data.length;
  const step = n > 1 ? (width - pad.left - pad.right) / (n - 1) : 0;
  const x = (i: number) => pad.left + step * i;
  const y = (v: number) => pad.top + chartH - (max > 0 ? (v / max) * chartH : 0);

  const line = (key: "completed" | "total") =>
    data.map((d, i) => `${x(i)},${y(d[key])}`).join(" ");

  return (
    <View>
      <Svg width={width} height={height}>
        <Line x1={pad.left} y1={pad.top + chartH} x2={width - pad.right} y2={pad.top + chartH} stroke={colors.border} strokeWidth={1} />
        <Polyline points={line("total")} fill="none" stroke={CHART_COLORS.total} strokeWidth={2} />
        <Polyline points={line("completed")} fill="none" stroke={CHART_COLORS.done} strokeWidth={2} />
        {data.map((d, i) => (
          <G key={i}>
            <Circle cx={x(i)} cy={y(d.total)} r={3} fill={CHART_COLORS.total} />
            <Circle cx={x(i)} cy={y(d.completed)} r={3} fill={CHART_COLORS.done} />
          </G>
        ))}
      </Svg>
      <View style={[bars.labelRow, { width }]}>
        {data.map((d, i) => (
          <View key={i} style={{ width: step || width / n, alignItems: "center", marginLeft: i === 0 ? pad.left - (step || 0) / 2 : 0 }}>
            <Text style={[bars.label, { color: colors.mutedForeground }]} numberOfLines={1}>
              {d.label}
            </Text>
          </View>
        ))}
      </View>
      <Legend items={[{ label: "Completed", color: CHART_COLORS.done }, { label: "Total Due", color: CHART_COLORS.total }]} />
    </View>
  );
}

export function Legend({ items }: { items: { label: string; color: string }[] }) {
  const colors = useColors();
  return (
    <View style={legend.legendRow}>
      {items.map((it) => (
        <View key={it.label} style={legend.row}>
          <View style={[legend.dot, { backgroundColor: it.color }]} />
          <Text style={[legend.label, { color: colors.mutedForeground }]}>{it.label}</Text>
        </View>
      ))}
    </View>
  );
}

const legend = StyleSheet.create({
  legendRow: { flexDirection: "row", gap: 16, marginTop: 10, justifyContent: "center" },
  row: { flexDirection: "row", alignItems: "center", gap: 6 },
  dot: { width: 10, height: 10, borderRadius: 3 },
  label: { fontFamily: "Inter_400Regular", fontSize: 12 },
  val: { fontFamily: "Inter_600SemiBold", fontSize: 12, marginLeft: "auto" },
});

const bars = StyleSheet.create({
  labelRow: { flexDirection: "row", marginTop: 4 },
  label: { fontFamily: "Inter_400Regular", fontSize: 11 },
  value: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
});
