/**
 * Semantic design tokens for the Task Pro mobile app.
 *
 * Synced from the sibling web artifact (artifacts/iss-task-pro/src/index.css).
 * HSL values there are converted to hex here so both artifacts share the same
 * indigo-on-slate visual identity. Light + dark palettes are provided; the
 * useColors() hook picks the palette based on the device appearance.
 */

const colors = {
  light: {
    // Legacy aliases
    text: "#0f172a",
    tint: "#6366f1",

    background: "#f8fafc",
    foreground: "#0f172a",

    card: "#ffffff",
    cardForeground: "#0f172a",

    primary: "#6366f1",
    primaryForeground: "#ffffff",

    secondary: "#f1f5f9",
    secondaryForeground: "#0f172a",

    muted: "#f1f5f9",
    mutedForeground: "#64748b",

    accent: "#eef2ff",
    accentForeground: "#312e81",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    success: "#16a34a",
    warning: "#d97706",

    border: "#e2e8f0",
    input: "#e2e8f0",
  },

  dark: {
    text: "#f8fafc",
    tint: "#818cf8",

    background: "#0b1120",
    foreground: "#f8fafc",

    card: "#111a2e",
    cardForeground: "#f8fafc",

    primary: "#818cf8",
    primaryForeground: "#0b1120",

    secondary: "#1d2839",
    secondaryForeground: "#f8fafc",

    muted: "#1d2839",
    mutedForeground: "#94a3b8",

    accent: "#1e293b",
    accentForeground: "#c7d2fe",

    destructive: "#f87171",
    destructiveForeground: "#0b1120",

    success: "#4ade80",
    warning: "#fbbf24",

    border: "#22304a",
    input: "#253352",
  },

  radius: 12,
};

export default colors;
