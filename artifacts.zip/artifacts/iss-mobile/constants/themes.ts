/**
 * Full theme system mirrored from the web app
 * (artifacts/iss-task-pro/src/lib/theme.tsx + src/index.css).
 *
 * The web app lets the user pick a THEME (palette) and an ACCENT (primary
 * colour). Those choices are stored client-side and applied via CSS variables.
 * On mobile we reproduce the exact same palettes here as raw "H S% L%" HSL
 * triplets and expose buildColors(theme, accent) which returns the same
 * semantic tokens the app already consumes through useColors().
 */

export type ThemeName =
  | "light"
  | "dark"
  | "midnight"
  | "slate"
  | "sepia"
  | "ocean"
  | "forest"
  | "sunset"
  | "coffee"
  | "neon"
  | "bubblegum";

export type AccentName =
  | "indigo"
  | "blue"
  | "sky"
  | "cyan"
  | "teal"
  | "emerald"
  | "lime"
  | "amber"
  | "orange"
  | "rose"
  | "pink"
  | "fuchsia"
  | "violet";

/** Format an "H S% L%" triplet into a React Native friendly hsl() string. */
function hsl(triplet: string): string {
  const [h, s, l] = triplet.trim().split(/\s+/);
  return `hsl(${h}, ${s}, ${l})`;
}

export const THEMES: { id: ThemeName; label: string; emoji: string; bg: string; fg: string }[] = [
  { id: "light", label: "Light", emoji: "☀️", bg: hsl("210 40% 98%"), fg: hsl("222 47% 11%") },
  { id: "dark", label: "Dark", emoji: "🌑", bg: hsl("222 47% 9%"), fg: hsl("210 40% 98%") },
  { id: "midnight", label: "Midnight", emoji: "🌌", bg: hsl("230 45% 11%"), fg: hsl("214 32% 92%") },
  { id: "slate", label: "Slate", emoji: "🪨", bg: hsl("215 22% 17%"), fg: hsl("210 22% 93%") },
  { id: "sepia", label: "Sepia", emoji: "📜", bg: hsl("40 38% 95%"), fg: hsl("30 28% 16%") },
  { id: "ocean", label: "Ocean", emoji: "🌊", bg: hsl("200 60% 8%"), fg: hsl("190 30% 92%") },
  { id: "forest", label: "Forest", emoji: "🌲", bg: hsl("150 30% 8%"), fg: hsl("120 15% 90%") },
  { id: "sunset", label: "Sunset", emoji: "🌇", bg: hsl("280 35% 10%"), fg: hsl("30 40% 94%") },
  { id: "coffee", label: "Coffee", emoji: "☕", bg: hsl("25 25% 11%"), fg: hsl("35 25% 90%") },
  { id: "neon", label: "Neon", emoji: "⚡", bg: hsl("250 50% 6%"), fg: hsl("180 60% 88%") },
  { id: "bubblegum", label: "Bubblegum", emoji: "🍬", bg: hsl("330 60% 97%"), fg: hsl("320 40% 18%") },
];

export const ACCENTS: { id: AccentName; label: string; swatch: string }[] = [
  { id: "indigo", label: "Indigo", swatch: hsl("239 84% 67%") },
  { id: "blue", label: "Blue", swatch: hsl("217 91% 60%") },
  { id: "sky", label: "Sky", swatch: hsl("199 89% 48%") },
  { id: "cyan", label: "Cyan", swatch: hsl("188 86% 43%") },
  { id: "teal", label: "Teal", swatch: hsl("175 84% 32%") },
  { id: "emerald", label: "Emerald", swatch: hsl("160 84% 39%") },
  { id: "lime", label: "Lime", swatch: hsl("84 70% 40%") },
  { id: "amber", label: "Amber", swatch: hsl("32 95% 44%") },
  { id: "orange", label: "Orange", swatch: hsl("25 95% 53%") },
  { id: "rose", label: "Rose", swatch: hsl("347 77% 50%") },
  { id: "pink", label: "Pink", swatch: hsl("330 81% 60%") },
  { id: "fuchsia", label: "Fuchsia", swatch: hsl("292 84% 61%") },
  { id: "violet", label: "Violet", swatch: hsl("262 83% 58%") },
];

export const DARK_THEMES: ThemeName[] = [
  "dark",
  "midnight",
  "slate",
  "ocean",
  "forest",
  "sunset",
  "coffee",
  "neon",
];

const ACCENT_PRIMARY: Record<AccentName, string> = {
  indigo: "239 84% 67%",
  blue: "217 91% 60%",
  sky: "199 89% 48%",
  cyan: "188 86% 43%",
  teal: "175 84% 32%",
  emerald: "160 84% 39%",
  lime: "84 70% 40%",
  amber: "32 95% 44%",
  orange: "25 95% 53%",
  rose: "347 77% 50%",
  pink: "330 81% 60%",
  fuchsia: "292 84% 61%",
  violet: "262 83% 58%",
};

type Palette = {
  background: string;
  foreground: string;
  border: string;
  input: string;
  card: string;
  cardForeground: string;
  secondary: string;
  secondaryForeground: string;
  muted: string;
  mutedForeground: string;
  accent: string;
  accentForeground: string;
  destructive: string;
};

/** Per-theme semantic tokens, copied verbatim from src/index.css. */
const PALETTES: Record<ThemeName, Palette> = {
  light: {
    background: "210 40% 98%",
    foreground: "222 47% 11%",
    border: "214 32% 91%",
    input: "214 32% 91%",
    card: "0 0% 100%",
    cardForeground: "222 47% 11%",
    secondary: "210 40% 96%",
    secondaryForeground: "222 47% 11%",
    muted: "210 40% 96%",
    mutedForeground: "215 16% 47%",
    accent: "210 40% 96%",
    accentForeground: "222 47% 11%",
    destructive: "0 84% 60%",
  },
  dark: {
    background: "222 47% 9%",
    foreground: "210 40% 98%",
    border: "217 33% 20%",
    input: "217 33% 22%",
    card: "222 44% 13%",
    cardForeground: "210 40% 98%",
    secondary: "217 33% 17%",
    secondaryForeground: "210 40% 98%",
    muted: "217 33% 17%",
    mutedForeground: "215 20% 65%",
    accent: "217 33% 17%",
    accentForeground: "210 40% 98%",
    destructive: "0 72% 51%",
  },
  midnight: {
    background: "230 45% 11%",
    foreground: "214 32% 92%",
    border: "230 30% 24%",
    input: "230 30% 24%",
    card: "231 41% 15%",
    cardForeground: "214 32% 92%",
    secondary: "230 30% 20%",
    secondaryForeground: "214 32% 92%",
    muted: "230 30% 20%",
    mutedForeground: "225 20% 70%",
    accent: "230 30% 20%",
    accentForeground: "214 32% 92%",
    destructive: "0 72% 56%",
  },
  slate: {
    background: "215 22% 17%",
    foreground: "210 22% 93%",
    border: "215 15% 31%",
    input: "215 15% 31%",
    card: "215 19% 22%",
    cardForeground: "210 22% 93%",
    secondary: "215 15% 27%",
    secondaryForeground: "210 22% 93%",
    muted: "215 15% 27%",
    mutedForeground: "215 14% 72%",
    accent: "215 15% 27%",
    accentForeground: "210 22% 93%",
    destructive: "0 70% 56%",
  },
  sepia: {
    background: "40 38% 95%",
    foreground: "30 28% 16%",
    border: "38 26% 82%",
    input: "38 26% 82%",
    card: "44 50% 99%",
    cardForeground: "30 28% 16%",
    secondary: "40 32% 90%",
    secondaryForeground: "30 28% 16%",
    muted: "40 32% 90%",
    mutedForeground: "34 16% 40%",
    accent: "40 32% 90%",
    accentForeground: "30 28% 16%",
    destructive: "0 70% 48%",
  },
  ocean: {
    background: "200 60% 8%",
    foreground: "190 30% 92%",
    border: "198 40% 20%",
    input: "198 40% 22%",
    card: "200 50% 12%",
    cardForeground: "190 30% 92%",
    secondary: "198 40% 17%",
    secondaryForeground: "190 30% 92%",
    muted: "198 40% 17%",
    mutedForeground: "195 25% 68%",
    accent: "198 40% 17%",
    accentForeground: "190 30% 92%",
    destructive: "0 72% 56%",
  },
  forest: {
    background: "150 30% 8%",
    foreground: "120 15% 90%",
    border: "150 20% 20%",
    input: "150 20% 22%",
    card: "150 25% 11%",
    cardForeground: "120 15% 90%",
    secondary: "150 20% 16%",
    secondaryForeground: "120 15% 90%",
    muted: "150 20% 16%",
    mutedForeground: "140 12% 66%",
    accent: "150 20% 16%",
    accentForeground: "120 15% 90%",
    destructive: "0 70% 55%",
  },
  sunset: {
    background: "280 35% 10%",
    foreground: "30 40% 94%",
    border: "290 25% 24%",
    input: "290 25% 24%",
    card: "285 32% 14%",
    cardForeground: "30 40% 94%",
    secondary: "290 25% 20%",
    secondaryForeground: "30 40% 94%",
    muted: "290 25% 20%",
    mutedForeground: "300 18% 72%",
    accent: "290 25% 20%",
    accentForeground: "30 40% 94%",
    destructive: "0 75% 58%",
  },
  coffee: {
    background: "25 25% 11%",
    foreground: "35 25% 90%",
    border: "28 18% 24%",
    input: "28 18% 24%",
    card: "26 22% 15%",
    cardForeground: "35 25% 90%",
    secondary: "28 18% 20%",
    secondaryForeground: "35 25% 90%",
    muted: "28 18% 20%",
    mutedForeground: "32 16% 68%",
    accent: "28 18% 20%",
    accentForeground: "35 25% 90%",
    destructive: "0 65% 52%",
  },
  neon: {
    background: "250 50% 6%",
    foreground: "180 60% 88%",
    border: "255 40% 22%",
    input: "255 40% 22%",
    card: "252 45% 10%",
    cardForeground: "180 60% 88%",
    secondary: "255 40% 16%",
    secondaryForeground: "180 60% 88%",
    muted: "255 40% 16%",
    mutedForeground: "260 30% 72%",
    accent: "255 40% 16%",
    accentForeground: "180 60% 88%",
    destructive: "340 90% 62%",
  },
  bubblegum: {
    background: "330 60% 97%",
    foreground: "320 40% 18%",
    border: "330 40% 88%",
    input: "330 40% 88%",
    card: "0 0% 100%",
    cardForeground: "320 40% 18%",
    secondary: "330 50% 93%",
    secondaryForeground: "320 40% 18%",
    muted: "330 50% 93%",
    mutedForeground: "325 20% 45%",
    accent: "330 50% 93%",
    accentForeground: "320 40% 18%",
    destructive: "0 75% 55%",
  },
};

export type AppColors = {
  text: string;
  tint: string;
  background: string;
  foreground: string;
  card: string;
  cardForeground: string;
  primary: string;
  primaryForeground: string;
  secondary: string;
  secondaryForeground: string;
  muted: string;
  mutedForeground: string;
  accent: string;
  accentForeground: string;
  destructive: string;
  destructiveForeground: string;
  success: string;
  warning: string;
  border: string;
  input: string;
  isDark: boolean;
  radius: number;
};

export function isDarkTheme(theme: ThemeName): boolean {
  return DARK_THEMES.includes(theme);
}

export function buildColors(theme: ThemeName, accent: AccentName): AppColors {
  const p = PALETTES[theme] ?? PALETTES.light;
  const dark = isDarkTheme(theme);
  const primary = hsl(ACCENT_PRIMARY[accent] ?? ACCENT_PRIMARY.indigo);
  return {
    text: hsl(p.foreground),
    tint: primary,
    background: hsl(p.background),
    foreground: hsl(p.foreground),
    card: hsl(p.card),
    cardForeground: hsl(p.cardForeground),
    primary,
    primaryForeground: "hsl(0, 0%, 100%)",
    secondary: hsl(p.secondary),
    secondaryForeground: hsl(p.secondaryForeground),
    muted: hsl(p.muted),
    mutedForeground: hsl(p.mutedForeground),
    accent: hsl(p.accent),
    accentForeground: hsl(p.accentForeground),
    destructive: hsl(p.destructive),
    destructiveForeground: "hsl(0, 0%, 100%)",
    success: dark ? hsl("142 71% 55%") : hsl("142 71% 38%"),
    warning: dark ? hsl("38 92% 60%") : hsl("32 95% 44%"),
    border: hsl(p.border),
    input: hsl(p.input),
    isDark: dark,
    radius: 12,
  };
}
