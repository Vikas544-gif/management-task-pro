import type { Task } from "@workspace/api-client-react";
import { getGetTaskQueryKey, useGetTask, useUpdateTask, useUpdateTaskStatus } from "@workspace/api-client-react";
import { Feather } from "@expo/vector-icons";
import { useQueryClient } from "@tanstack/react-query";
import { Stack, useLocalSearchParams } from "expo-router";
import * as Haptics from "expo-haptics";
import React from "react";
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Button, Card, ErrorState, LoadingState, PriorityBadge, StatusPill, TextField } from "@/components/ui";
import { useColors } from "@/hooks/useColors";

const STATUS_FLOW: { value: string; label: string; icon: keyof typeof Feather.glyphMap }[] = [
  { value: "pending", label: "Pending", icon: "clock" },
  { value: "inProgress", label: "In Progress", icon: "loader" },
  { value: "done", label: "Done", icon: "check-circle" },
];

function Field({ icon, label, value }: { icon: keyof typeof Feather.glyphMap; label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.field}>
      <Feather name={icon} size={16} color={colors.mutedForeground} />
      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground, width: 90 }}>
        {label}
      </Text>
      <Text style={{ fontFamily: "Inter_500Medium", fontSize: 14, color: colors.foreground, flex: 1 }}>
        {value}
      </Text>
    </View>
  );
}

export default function TaskDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const taskId = Number(id);
  const qc = useQueryClient();

  const query = useGetTask(taskId, {
    query: { enabled: Number.isFinite(taskId), queryKey: getGetTaskQueryKey(taskId) },
  });
  const updateStatus = useUpdateTaskStatus();
  const updateTask = useUpdateTask();

  const task: Task | undefined = query.data;

  const [remarkDraft, setRemarkDraft] = React.useState("");
  const hydratedFor = React.useRef<number | null>(null);
  React.useEffect(() => {
    if (task && hydratedFor.current !== task.id) {
      hydratedFor.current = task.id;
      setRemarkDraft(task.remark ?? "");
    }
  }, [task]);

  const onSetStatus = async (status: string) => {
    if (!task || task.status === status) return;
    if (Platform.OS !== "web") Haptics.selectionAsync();
    await updateStatus.mutateAsync({ id: task.id, data: { status } });
    qc.invalidateQueries();
  };

  const onSaveRemark = async () => {
    if (!task) return;
    try {
      const trimmed = remarkDraft.trim();
      await updateTask.mutateAsync({ id: task.id, data: { remark: trimmed || null } });
      setRemarkDraft(trimmed);
      qc.invalidateQueries();
      if (Platform.OS === "web") window.alert("Remark saved.");
      else Alert.alert("Remark saved.");
    } catch {
      if (Platform.OS === "web") window.alert("Could not save the remark. Please try again.");
      else Alert.alert("Could not save the remark. Please try again.");
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Stack.Screen options={{ title: "Task Details" }} />
      {query.isLoading ? (
        <LoadingState />
      ) : query.isError || !task ? (
        <ErrorState onRetry={() => query.refetch()} />
      ) : (
        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 32, gap: 16 }}>
          <Card style={{ gap: 12 }}>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 20, color: colors.foreground }}>
              {task.title}
            </Text>
            <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
              <StatusPill status={task.status} />
              <PriorityBadge priority={task.priority} />
            </View>
            {task.description ? (
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 15, color: colors.foreground, lineHeight: 22 }}>
                {task.description}
              </Text>
            ) : null}
          </Card>

          <Card style={{ gap: 14 }}>
            <Text style={[styles.cardHeading, { color: colors.foreground }]}>Details</Text>
            <Field icon="tag" label="Type" value={task.type} />
            {task.category ? <Field icon="folder" label="Category" value={task.category} /> : null}
            {task.dueDate ? (
              <Field icon="calendar" label="Due date" value={task.dueDate + (task.dueTime ? ` ${task.dueTime}` : "")} />
            ) : null}
            {task.assignedToName ? <Field icon="user" label="Assigned to" value={task.assignedToName} /> : null}
            {task.assignedByName ? <Field icon="user-check" label="Assigned by" value={task.assignedByName} /> : null}
          </Card>

          <Card style={{ gap: 12 }}>
            <Text style={[styles.cardHeading, { color: colors.foreground }]}>Remark</Text>
            <TextField
              value={remarkDraft}
              onChangeText={setRemarkDraft}
              placeholder="Add a remark…"
            />
            <Button
              label="Save Remark"
              icon="message-square"
              onPress={onSaveRemark}
              loading={updateTask.isPending}
            />
          </Card>

          <Card style={{ gap: 12 }}>
            <Text style={[styles.cardHeading, { color: colors.foreground }]}>Update status</Text>
            <View style={{ gap: 10 }}>
              {STATUS_FLOW.map((s) => {
                const active = task.status === s.value;
                return (
                  <Pressable
                    key={s.value}
                    onPress={() => onSetStatus(s.value)}
                    disabled={updateStatus.isPending}
                    style={[
                      styles.statusOption,
                      {
                        backgroundColor: active ? colors.primary : colors.secondary,
                        borderColor: active ? colors.primary : colors.border,
                        borderRadius: colors.radius,
                        opacity: updateStatus.isPending ? 0.6 : 1,
                      },
                    ]}
                  >
                    <Feather
                      name={s.icon}
                      size={18}
                      color={active ? colors.primaryForeground : colors.mutedForeground}
                    />
                    <Text
                      style={{
                        fontFamily: "Inter_600SemiBold",
                        fontSize: 15,
                        color: active ? colors.primaryForeground : colors.foreground,
                        flex: 1,
                      }}
                    >
                      {s.label}
                    </Text>
                    {active ? <Feather name="check" size={18} color={colors.primaryForeground} /> : null}
                  </Pressable>
                );
              })}
            </View>
          </Card>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  cardHeading: { fontFamily: "Inter_600SemiBold", fontSize: 16 },
  field: { flexDirection: "row", alignItems: "center", gap: 10 },
  statusOption: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderWidth: StyleSheet.hairlineWidth,
  },
});
