import type { Attendance, User } from "@workspace/api-client-react";
import {
  getListAttendanceQueryKey,
  getListUsersQueryKey,
  useListAttendance,
  useListUsers,
  useUpsertAttendance,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import React, { useMemo, useState } from "react";
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Button, Card, EmptyState, ErrorState, LoadingState } from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

const STATUSES = [
  { value: "present", label: "P", full: "Present", color: "#10b981" },
  { value: "half_day", label: "½", full: "Half Day", color: "#f59e0b" },
  { value: "leave", label: "L", full: "Leave", color: "#3b82f6" },
  { value: "absent", label: "A", full: "Absent", color: "#ef4444" },
];

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export default function AttendanceScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const { user } = useAuth();
  const date = todayStr();

  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey() } });
  const attendanceQuery = useListAttendance(
    { date },
    { query: { queryKey: getListAttendanceQueryKey({ date }) } },
  );
  const upsert = useUpsertAttendance();

  const statusByUser = useMemo(() => {
    const map = new Map<number, string>();
    (attendanceQuery.data ?? []).forEach((a: Attendance) => map.set(a.userId, a.status));
    return map;
  }, [attendanceQuery.data]);

  const [pending, setPending] = useState<number | null>(null);

  const members: User[] = useMemo(
    () => (usersQuery.data ?? []).slice().sort((a: User, b: User) => a.name.localeCompare(b.name)),
    [usersQuery.data],
  );

  const notify = (msg: string) => {
    if (Platform.OS === "web") window.alert(msg);
    else Alert.alert(msg);
  };

  const mark = async (member: User, status: string) => {
    setPending(member.id);
    try {
      await upsert.mutateAsync({
        data: { userId: member.id, date, status, center: member.center ?? null, markedBy: user?.id ?? null },
      });
      qc.invalidateQueries({ queryKey: getListAttendanceQueryKey({ date }) });
    } catch {
      notify("Could not save attendance. Please try again.");
    } finally {
      setPending(null);
    }
  };

  const markAllPresent = async () => {
    const toMark = members.filter((m) => !statusByUser.has(m.id));
    for (const m of toMark) {
      try {
        await upsert.mutateAsync({
          data: { userId: m.id, date, status: "present", center: m.center ?? null, markedBy: user?.id ?? null },
        });
      } catch {
        // continue with the rest
      }
    }
    qc.invalidateQueries({ queryKey: getListAttendanceQueryKey({ date }) });
  };

  if (usersQuery.isLoading || attendanceQuery.isLoading) return <LoadingState />;
  if (usersQuery.isError) return <ErrorState onRetry={() => usersQuery.refetch()} />;

  const markedCount = members.filter((m) => statusByUser.has(m.id)).length;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={styles.bar}>
        <View>
          <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground }}>{date}</Text>
          <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
            {markedCount}/{members.length} marked
          </Text>
        </View>
        <Button label="Mark all present" icon="check-circle" variant="secondary" onPress={markAllPresent} />
      </View>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 24, gap: 10 }}>
        {members.length === 0 ? (
          <View style={{ paddingTop: 60 }}>
            <EmptyState icon="calendar" title="No members" message="There is no one to mark attendance for." />
          </View>
        ) : (
          members.map((m) => {
            const current = statusByUser.get(m.id);
            return (
              <Card key={m.id} style={{ gap: 10, opacity: pending === m.id ? 0.6 : 1 }}>
                <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground }} numberOfLines={1}>
                  {m.name}
                  {m.center ? (
                    <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                      {"  "}· {m.center}
                    </Text>
                  ) : null}
                </Text>
                <View style={{ flexDirection: "row", gap: 8 }}>
                  {STATUSES.map((s) => {
                    const active = current === s.value;
                    return (
                      <Pressable
                        key={s.value}
                        onPress={() => mark(m, s.value)}
                        style={[
                          styles.statusBtn,
                          {
                            backgroundColor: active ? s.color : colors.card,
                            borderColor: active ? s.color : colors.border,
                          },
                        ]}
                      >
                        <Text
                          style={{
                            fontFamily: "Inter_700Bold",
                            fontSize: 13,
                            color: active ? "#fff" : colors.mutedForeground,
                          }}
                        >
                          {s.full}
                        </Text>
                      </Pressable>
                    );
                  })}
                </View>
              </Card>
            );
          })
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  statusBtn: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: StyleSheet.hairlineWidth,
  },
});
