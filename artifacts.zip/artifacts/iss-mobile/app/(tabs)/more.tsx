import { useLogout, useUpdateUser } from "@workspace/api-client-react";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { AppHeader, Card, useTabContentPadding } from "@/components/ui";
import { ACCENTS, THEMES } from "@/constants/themes";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { useColors } from "@/hooks/useColors";
import { canManage, canSeeAttendance, canSeeEod, roleFlags } from "@/lib/permissions";

type Row = { icon: keyof typeof Feather.glyphMap; label: string; route: string };

export default function MoreScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user, signOut } = useAuth();
  const { theme, accent, setTheme, setAccent } = useTheme();
  const logout = useLogout();
  const updateUser = useUpdateUser();
  const bottomPad = useTabContentPadding();

  const { isBoss, isCenterHead, isMis, isTl } = roleFlags(user);
  const canOversee = isBoss || isCenterHead || isMis;
  const canViewSales = canOversee || isTl;

  const [showPwForm, setShowPwForm] = React.useState(false);
  const [newPw, setNewPw] = React.useState("");
  const [confirmPw, setConfirmPw] = React.useState("");
  const [pwError, setPwError] = React.useState("");
  const [pwSuccess, setPwSuccess] = React.useState(false);

  const features: Row[] = [
    { icon: "plus-circle", label: "Assign Task", route: "/assign-task" },
    { icon: "users", label: "Team", route: "/team" },
    ...(canSeeAttendance(user) ? [{ icon: "calendar" as const, label: "Attendance", route: "/attendance" }] : []),
    ...(canSeeEod(user) ? [{ icon: "file-text" as const, label: "EOD Report", route: "/eod" }] : []),
    { icon: "bar-chart-2", label: "Reports", route: "/reports" },
    ...(canViewSales ? [{ icon: "trending-up" as const, label: "Sales Report", route: "/sales-report" }] : []),
    ...(canOversee ? [{ icon: "activity" as const, label: "Assignment Monitor", route: "/assignment-monitor" }] : []),
    ...(canOversee ? [{ icon: "git-merge" as const, label: "Hierarchy & Credentials", route: "/hierarchy" }] : []),
    { icon: "sun", label: "Holidays", route: "/holidays" },
    ...(canManage(user) ? [{ icon: "shield" as const, label: "Access Control", route: "/access-control" }] : []),
    ...(canManage(user) ? [{ icon: "mail" as const, label: "Email Settings", route: "/email-settings" }] : []),
  ];

  const resetPwForm = () => {
    setShowPwForm(false);
    setNewPw("");
    setConfirmPw("");
    setPwError("");
  };

  const handleChangePassword = () => {
    setPwError("");
    if (!newPw.trim()) {
      setPwError("Please enter a new password");
      return;
    }
    if (newPw !== confirmPw) {
      setPwError("Passwords do not match");
      return;
    }
    if (!user) return;
    updateUser.mutate(
      { id: user.id, data: { password: newPw } },
      {
        onSuccess: () => {
          resetPwForm();
          setPwSuccess(true);
          setTimeout(() => setPwSuccess(false), 2500);
        },
        onError: () => setPwError("Password could not be changed, please try again"),
      },
    );
  };

  const confirmLogout = () => {
    const doLogout = async () => {
      try {
        await logout.mutateAsync();
      } catch {
        // ignore server error — clear local session regardless
      }
      await signOut();
    };
    if (Platform.OS === "web") {
      doLogout();
    } else {
      Alert.alert("Sign out", "Are you sure you want to sign out?", [
        { text: "Cancel", style: "cancel" },
        { text: "Sign out", style: "destructive", onPress: doLogout },
      ]);
    }
  };

  const initials = (user?.name ?? "?")
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <AppHeader title="More" />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: bottomPad, gap: 16 }}>
        <Card style={{ flexDirection: "row", alignItems: "center", gap: 14 }}>
          <View style={[styles.avatar, { backgroundColor: colors.primary }]}>
            <Text style={{ fontFamily: "Inter_700Bold", color: colors.primaryForeground, fontSize: 18 }}>
              {initials}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 17, color: colors.foreground }}>{user?.name}</Text>
            <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>
              {user?.role}
              {user?.center ? ` · ${user.center}` : ""}
            </Text>
          </View>
        </Card>

        {/* Theme + Accent */}
        <View>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>🎨 THEME</Text>
          <Card style={{ gap: 14 }}>
            <View style={styles.themeGrid}>
              {THEMES.map((t) => {
                const active = theme === t.id;
                return (
                  <Pressable
                    key={t.id}
                    onPress={() => setTheme(t.id)}
                    style={[
                      styles.themeItem,
                      { borderColor: active ? colors.primary : colors.border, borderWidth: active ? 2 : 1 },
                    ]}
                  >
                    <View style={[styles.themeSwatch, { backgroundColor: t.bg, borderColor: colors.border }]}>
                      <Text style={{ fontSize: 12 }}>{t.emoji}</Text>
                      <View style={{ width: 11, height: 11, borderRadius: 6, backgroundColor: t.fg }} />
                    </View>
                    <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 12, color: colors.foreground }}>
                      {t.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            <View style={{ gap: 8 }}>
              <Text style={[styles.sectionLabel, { color: colors.mutedForeground, marginBottom: 0, marginLeft: 0 }]}>
                ✨ ACCENT
              </Text>
              <View style={styles.accentRow}>
                {ACCENTS.map((a) => {
                  const active = accent === a.id;
                  return (
                    <Pressable
                      key={a.id}
                      onPress={() => setAccent(a.id)}
                      accessibilityLabel={a.label}
                      style={[
                        styles.accentSwatch,
                        {
                          backgroundColor: a.swatch,
                          borderColor: active ? colors.foreground : "transparent",
                          transform: [{ scale: active ? 1.12 : 1 }],
                        },
                      ]}
                    >
                      {active ? <Text style={styles.accentCheck}>✓</Text> : null}
                    </Pressable>
                  );
                })}
              </View>
            </View>
          </Card>
        </View>

        {/* Account */}
        <View>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ACCOUNT</Text>
          <Card style={{ gap: 10 }}>
            {pwSuccess ? (
              <Text style={{ fontFamily: "Inter_500Medium", fontSize: 13, color: colors.success }}>
                ✓ Password changed successfully
              </Text>
            ) : null}
            {showPwForm ? (
              <View style={{ gap: 10 }}>
                {pwError ? (
                  <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12.5, color: colors.destructive }}>
                    {pwError}
                  </Text>
                ) : null}
                <TextInput
                  secureTextEntry
                  autoFocus
                  value={newPw}
                  onChangeText={setNewPw}
                  placeholder="New password"
                  placeholderTextColor={colors.mutedForeground}
                  style={[styles.input, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]}
                />
                <TextInput
                  secureTextEntry
                  value={confirmPw}
                  onChangeText={setConfirmPw}
                  placeholder="Confirm new password"
                  placeholderTextColor={colors.mutedForeground}
                  style={[styles.input, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]}
                />
                <View style={{ flexDirection: "row", gap: 10 }}>
                  <Pressable
                    onPress={handleChangePassword}
                    disabled={updateUser.isPending}
                    style={[styles.pwBtn, { backgroundColor: colors.primary, opacity: updateUser.isPending ? 0.6 : 1 }]}
                  >
                    <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.primaryForeground }}>
                      {updateUser.isPending ? "Saving..." : "Save"}
                    </Text>
                  </Pressable>
                  <Pressable onPress={resetPwForm} style={[styles.pwBtn, { backgroundColor: colors.secondary }]}>
                    <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.secondaryForeground }}>
                      Cancel
                    </Text>
                  </Pressable>
                </View>
              </View>
            ) : (
              <Pressable
                onPress={() => {
                  setPwSuccess(false);
                  setShowPwForm(true);
                }}
                style={styles.accountRow}
              >
                <Feather name="key" size={18} color={colors.mutedForeground} />
                <Text style={{ flex: 1, fontFamily: "Inter_500Medium", fontSize: 15, color: colors.foreground }}>
                  Change Password
                </Text>
                <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
              </Pressable>
            )}
          </Card>
        </View>

        <View>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>FEATURES</Text>
          <Card style={{ padding: 0 }}>
            {features.map((row, i) => (
              <Pressable
                key={row.label}
                onPress={() => router.push(row.route as never)}
                style={({ pressed }) => [
                  styles.row,
                  { opacity: pressed ? 0.6 : 1 },
                  i < features.length - 1
                    ? { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth }
                    : null,
                ]}
              >
                <Feather name={row.icon} size={19} color={colors.mutedForeground} />
                <Text style={{ flex: 1, fontFamily: "Inter_500Medium", fontSize: 15, color: colors.foreground }}>
                  {row.label}
                </Text>
                <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
              </Pressable>
            ))}
          </Card>
        </View>

        <Pressable onPress={confirmLogout}>
          <Card style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <Feather name="log-out" size={18} color={colors.destructive} />
            <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 15, color: colors.destructive }}>Sign Out</Text>
          </Card>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  avatar: { width: 52, height: 52, borderRadius: 26, alignItems: "center", justifyContent: "center" },
  sectionLabel: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.6, marginBottom: 8, marginLeft: 4 },
  row: { flexDirection: "row", alignItems: "center", gap: 14, paddingHorizontal: 16, paddingVertical: 16 },
  accountRow: { flexDirection: "row", alignItems: "center", gap: 14, paddingVertical: 4 },
  themeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  themeItem: {
    width: "30.5%",
    flexGrow: 1,
    alignItems: "center",
    gap: 5,
    borderRadius: 10,
    padding: 7,
  },
  themeSwatch: {
    width: "100%",
    height: 30,
    borderRadius: 7,
    borderWidth: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 7,
  },
  accentRow: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  accentSwatch: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  accentCheck: {
    color: "#fff",
    fontSize: 12,
    fontFamily: "Inter_700Bold",
    textShadowColor: "rgba(0,0,0,0.9)",
    textShadowRadius: 2,
  },
  input: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, fontFamily: "Inter_400Regular", fontSize: 14 },
  pwBtn: { flex: 1, borderRadius: 10, paddingVertical: 11, alignItems: "center", justifyContent: "center" },
});
