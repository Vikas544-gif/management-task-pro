import AsyncStorage from "@react-native-async-storage/async-storage";
import type { Category, Task } from "@workspace/api-client-react";
import {
  getListCategoriesQueryKey,
  getListTasksQueryKey,
  useCreateTask,
  useDeleteTask,
  useListCategories,
  useListTasks,
  useUpdateTaskStatus,
} from "@workspace/api-client-react";
import { Feather } from "@expo/vector-icons";
import { useQueryClient } from "@tanstack/react-query";
import * as Notifications from "expo-notifications";
import { useRouter } from "expo-router";
import React, { useEffect, useMemo, useState } from "react";
import { Alert, FlatList, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import {
  AppHeader,
  Button,
  Card,
  EmptyState,
  ErrorState,
  FieldLabel,
  LoadingState,
  PriorityBadge,
  Segmented,
  Select,
  StatusPill,
  TextField,
  useTabContentPadding,
  type Option,
} from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

type StatusKey = "all" | "pending" | "inProgress" | "done";
const STATUS_FILTERS: { key: StatusKey; label: string }[] = [
  { key: "all", label: "All" },
  { key: "pending", label: "Pending" },
  { key: "inProgress", label: "In Progress" },
  { key: "done", label: "Done" },
];

// Priority filter mirrors the web TaskList (All / High / Medium / Low). The
// stored value is compared case-insensitively against task.priority.
const PRIORITY_OPTIONS: Option[] = [
  { value: "all", label: "All" },
  { value: "high", label: "High" },
  { value: "medium", label: "Medium" },
  { value: "low", label: "Low" },
];

// Date window filter. taskDateOf = dueDate || createdAt (date part), matching
// the web filter's `t.dueDate || t.createdAt?.split("T")[0]`.
type DateKey = "all" | "today" | "week" | "month";
const DATE_OPTIONS: Option[] = [
  { value: "all", label: "All Dates" },
  { value: "today", label: "Today" },
  { value: "week", label: "This Week" },
  { value: "month", label: "This Month" },
];

function pad2(n: number) {
  return String(n).padStart(2, "0");
}
function fmtDate(d: Date) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

export default function MyTasksScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useAuth();
  const bottomPad = useTabContentPadding();

  const [status, setStatus] = useState<StatusKey>("all");
  const [search, setSearch] = useState("");
  const [priority, setPriority] = useState("all");
  const [dateFilter, setDateFilter] = useState<DateKey>("all");
  const [category, setCategory] = useState("all");

  // "Add My Task" — mirrors the web MyTasks self-task form: the task is
  // assigned to and by the current user (no notification is sent for
  // self-assigned tasks).
  const qc = useQueryClient();
  const createTask = useCreateTask();
  const [showAdd, setShowAdd] = useState(false);
  const [addTitle, setAddTitle] = useState("");
  const [addDescription, setAddDescription] = useState("");
  const [addDueDate, setAddDueDate] = useState("");
  const [addPriority, setAddPriority] = useState("medium");
  const [addType, setAddType] = useState("daily");
  const [addCategory, setAddCategory] = useState("");
  const [addRemark, setAddRemark] = useState("");

  const openAdd = () => {
    setAddTitle("");
    setAddDescription("");
    setAddDueDate("");
    setAddPriority("medium");
    setAddType("daily");
    setAddCategory("");
    setAddRemark("");
    setShowAdd(true);
  };

  const notify = (msg: string) => {
    if (Platform.OS === "web") window.alert(msg);
    else Alert.alert(msg);
  };

  const onAddTask = async () => {
    if (!user?.id) return;
    if (!addTitle.trim()) {
      notify("Please enter a task title.");
      return;
    }
    try {
      await createTask.mutateAsync({
        data: {
          title: addTitle.trim(),
          description: addDescription.trim() || null,
          assignedTo: user.id,
          assignedBy: user.id,
          dueDate: addDueDate.trim() || null,
          priority: addPriority,
          type: addType,
          category: addCategory || null,
          remark: addRemark.trim() || null,
        },
      });
      qc.invalidateQueries();
      setShowAdd(false);
    } catch {
      notify("Could not add the task. Please try again.");
    }
  };

  // ── Delete (assigner or elevated only — mirrors the server gate) ──
  const deleteTask = useDeleteTask();
  const isElevatedViewer =
    user?.department === "Management" ||
    user?.role === "Boss" ||
    user?.department === "MIS" ||
    user?.department === "Director" ||
    user?.role === "Center Head";
  const canDelete = (t: Task) =>
    isElevatedViewer || (t.assignedBy != null && t.assignedBy === user?.id);
  const onDelete = (t: Task) => {
    const doDelete = () =>
      deleteTask.mutate(
        { id: t.id },
        {
          onSuccess: () => {
            void removeReminderEntries([t.id]);
            qc.invalidateQueries();
          },
          onError: () => notify("Could not delete the task. Please try again."),
        },
      );
    if (Platform.OS === "web") {
      if (window.confirm(`Delete the "${t.title}" task?`)) doDelete();
    } else {
      Alert.alert("Delete Task", `Delete the "${t.title}" task?`, [
        { text: "Cancel", style: "cancel" },
        { text: "Delete", style: "destructive", onPress: doDelete },
      ]);
    }
  };

  // ── Bulk select + complete (mirrors the web TaskList) ──
  const updateStatus = useUpdateTaskStatus();
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const toggleSelect = (id: number) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  const exitSelect = () => {
    setSelectMode(false);
    setSelected(new Set());
  };
  const bulkComplete = async (visible: Task[]) => {
    if (bulkBusy) return;
    const ids = visible.filter((t) => selected.has(t.id) && t.status !== "done").map((t) => t.id);
    if (ids.length === 0) {
      exitSelect();
      return;
    }
    setBulkBusy(true);
    const results = await Promise.allSettled(
      ids.map((id) => updateStatus.mutateAsync({ id, data: { status: "done" } })),
    );
    setBulkBusy(false);
    qc.invalidateQueries();
    const failed = ids.filter((_, i) => results[i].status === "rejected");
    // A completed task no longer needs its pending reminder.
    const completed = ids.filter((_, i) => results[i].status === "fulfilled");
    if (completed.length > 0) void removeReminderEntries(completed);
    if (failed.length > 0) {
      // Keep only the failed rows selected so the user can retry just those.
      setSelected(new Set(failed));
      notify(`${failed.length} task${failed.length === 1 ? "" : "s"} could not be completed. Please try again.`);
    } else {
      exitSelect();
    }
  };

  // ── Personal reminders (scheduled local notifications; native only) ──
  const remindersKey = `taskReminders:${user?.id ?? 0}`;
  const [reminders, setReminders] = useState<Record<string, { id: string; when: string }>>({});
  const [reminderTask, setReminderTask] = useState<Task | null>(null);
  const [remDate, setRemDate] = useState("");
  const [remTime, setRemTime] = useState("");
  useEffect(() => {
    // Always reset state for the current user (prevents cross-account leakage),
    // and prune entries whose fire time has already passed.
    setReminders({});
    if (!user?.id) return;
    AsyncStorage.getItem(`taskReminders:${user.id}`)
      .then((raw) => {
        let parsed: Record<string, { id: string; when: string }> = {};
        if (raw) {
          try {
            parsed = JSON.parse(raw);
          } catch {
            parsed = {};
          }
        }
        const now = Date.now();
        const pruned: typeof parsed = {};
        for (const [k, v] of Object.entries(parsed)) {
          if (v?.when && new Date(v.when).getTime() > now) pruned[k] = v;
        }
        setReminders(pruned);
        if (Object.keys(pruned).length !== Object.keys(parsed).length) {
          AsyncStorage.setItem(`taskReminders:${user.id}`, JSON.stringify(pruned)).catch(() => {});
        }
      })
      .catch(() => {});
  }, [user?.id]);
  const persistReminders = (next: Record<string, { id: string; when: string }>) => {
    setReminders(next);
    AsyncStorage.setItem(remindersKey, JSON.stringify(next)).catch(() => {});
  };
  /** Cancel + forget reminders for tasks that were completed or deleted. */
  const removeReminderEntries = async (taskIds: number[]) => {
    const keys = taskIds.map(String).filter((k) => reminders[k]);
    if (keys.length === 0) return;
    for (const k of keys) {
      await Notifications.cancelScheduledNotificationAsync(reminders[k].id).catch(() => {});
    }
    const next = { ...reminders };
    for (const k of keys) delete next[k];
    persistReminders(next);
  };
  const hasActiveReminder = (taskId: number) => {
    const r = reminders[String(taskId)];
    return !!r && new Date(r.when).getTime() > Date.now();
  };
  const openReminder = (t: Task) => {
    const existing = reminders[String(t.id)];
    if (existing && new Date(existing.when).getTime() > Date.now()) {
      const d = new Date(existing.when);
      setRemDate(fmtDate(d));
      setRemTime(`${pad2(d.getHours())}:${pad2(d.getMinutes())}`);
    } else {
      setRemDate(t.dueDate ? String(t.dueDate).slice(0, 10) : fmtDate(new Date()));
      setRemTime("09:00");
    }
    setReminderTask(t);
  };
  const saveReminder = async () => {
    if (!reminderTask) return;
    const when = new Date(`${remDate.trim()}T${remTime.trim()}:00`);
    if (Number.isNaN(when.getTime()) || when.getTime() <= Date.now()) {
      notify("Please enter a future date (YYYY-MM-DD) and time (HH:MM).");
      return;
    }
    try {
      const perm = await Notifications.requestPermissionsAsync();
      if (!perm.granted) {
        notify("Please allow notifications to use reminders.");
        return;
      }
      const prev = reminders[String(reminderTask.id)];
      if (prev) await Notifications.cancelScheduledNotificationAsync(prev.id).catch(() => {});
      const notifId = await Notifications.scheduleNotificationAsync({
        content: {
          title: "Task Reminder",
          body: reminderTask.title,
          sound: "default",
          data: { taskId: reminderTask.id },
        },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when },
      });
      persistReminders({ ...reminders, [String(reminderTask.id)]: { id: notifId, when: when.toISOString() } });
      setReminderTask(null);
    } catch {
      notify("Could not set the reminder. Please try again.");
    }
  };
  const clearReminder = async () => {
    if (!reminderTask) return;
    const prev = reminders[String(reminderTask.id)];
    if (prev) await Notifications.cancelScheduledNotificationAsync(prev.id).catch(() => {});
    const next = { ...reminders };
    delete next[String(reminderTask.id)];
    persistReminders(next);
    setReminderTask(null);
  };

  const tasksQuery = useListTasks(
    { assignedTo: user?.id ?? undefined },
    {
      query: {
        enabled: !!user?.id,
        queryKey: getListTasksQueryKey({ assignedTo: user?.id ?? undefined }),
      },
    },
  );
  const categoriesQuery = useListCategories({
    query: { queryKey: getListCategoriesQueryKey() },
  });

  const tasks: Task[] = tasksQuery.data ?? [];

  // Category filter options come from the task categories, but only ones that
  // actually appear on the user's tasks are useful — mirror web by listing all
  // known categories plus "All".
  const categoryOptions: Option[] = useMemo(() => {
    const names = new Set<string>();
    for (const c of (categoriesQuery.data ?? []) as Category[]) {
      if (c.name) names.add(c.name);
    }
    for (const t of tasks) {
      if (t.category) names.add(t.category);
    }
    return [
      { value: "all", label: "All" },
      ...Array.from(names)
        .sort((a, b) => a.localeCompare(b))
        .map((n) => ({ value: n, label: n })),
    ];
  }, [categoriesQuery.data, tasks]);

  // Precompute the current date windows once per render.
  const { today, weekStart, weekEnd, monthPrefix } = useMemo(() => {
    const now = new Date();
    const diffToMonday = (now.getDay() + 6) % 7;
    const ws = new Date(now);
    ws.setDate(now.getDate() - diffToMonday);
    const we = new Date(ws);
    we.setDate(ws.getDate() + 6);
    return {
      today: fmtDate(now),
      weekStart: fmtDate(ws),
      weekEnd: fmtDate(we),
      monthPrefix: `${now.getFullYear()}-${pad2(now.getMonth() + 1)}`,
    };
  }, []);

  // AND-combine every filter, exactly like the web TaskList.
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return tasks.filter((t) => {
      if (status !== "all" && t.status !== status) return false;
      if (priority !== "all" && t.priority !== priority) return false;
      if (category !== "all" && t.category !== category) return false;
      if (dateFilter !== "all") {
        const d = t.dueDate || t.createdAt?.split("T")[0] || "";
        if (!d) return false;
        if (dateFilter === "today" && d !== today) return false;
        if (dateFilter === "week" && (d < weekStart || d > weekEnd)) return false;
        if (dateFilter === "month" && !d.startsWith(monthPrefix)) return false;
      }
      if (
        q &&
        !t.title.toLowerCase().includes(q) &&
        !(t.assignedToName ?? "").toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [tasks, status, priority, category, dateFilter, search, today, weekStart, weekEnd, monthPrefix]);

  if (tasksQuery.isLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <AppHeader title="My Tasks" />
        <LoadingState />
      </View>
    );
  }

  const filtersHeader = (
    <View style={{ gap: 12 }}>
      <View
        style={[
          styles.searchBox,
          { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
        ]}
      >
        <Feather name="search" size={16} color={colors.mutedForeground} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Search task or member..."
          placeholderTextColor={colors.mutedForeground}
          style={[styles.searchInput, { color: colors.foreground }]}
        />
        {search ? (
          <Pressable onPress={() => setSearch("")} hitSlop={8}>
            <Feather name="x" size={16} color={colors.mutedForeground} />
          </Pressable>
        ) : null}
      </View>

      <View style={{ gap: 6 }}>
        <Text style={[styles.filterLabel, { color: colors.mutedForeground }]}>Status</Text>
        <Segmented options={STATUS_FILTERS.map((f) => ({ value: f.key, label: f.label }))} value={status} onChange={(v) => setStatus(v as StatusKey)} />
      </View>

      <View style={{ gap: 6 }}>
        <Text style={[styles.filterLabel, { color: colors.mutedForeground }]}>Priority</Text>
        <Segmented options={PRIORITY_OPTIONS} value={priority} onChange={setPriority} />
      </View>

      <View style={{ gap: 6 }}>
        <Text style={[styles.filterLabel, { color: colors.mutedForeground }]}>Date</Text>
        <Segmented options={DATE_OPTIONS} value={dateFilter} onChange={(v) => setDateFilter(v as DateKey)} />
      </View>

      {categoryOptions.length > 1 ? (
        <View style={{ gap: 6 }}>
          <Text style={[styles.filterLabel, { color: colors.mutedForeground }]}>Category</Text>
          <Segmented options={categoryOptions} value={category} onChange={setCategory} />
        </View>
      ) : null}
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <AppHeader
        title="My Tasks"
        subtitle={`${filtered.length} of ${tasks.length}`}
        right={
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <Pressable
              onPress={() => (selectMode ? exitSelect() : setSelectMode(true))}
              hitSlop={8}
              style={{
                borderRadius: 999,
                borderWidth: 1,
                borderColor: selectMode ? colors.primary : colors.border,
                paddingHorizontal: 12,
                paddingVertical: 7,
              }}
            >
              <Text
                style={{
                  fontFamily: "Inter_600SemiBold",
                  fontSize: 13,
                  color: selectMode ? colors.primary : colors.mutedForeground,
                }}
              >
                {selectMode ? "Cancel" : "Select"}
              </Text>
            </Pressable>
            {!selectMode ? (
              <Pressable
                onPress={openAdd}
                hitSlop={8}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 5,
                  backgroundColor: colors.primary,
                  borderRadius: 999,
                  paddingHorizontal: 12,
                  paddingVertical: 7,
                }}
              >
                <Feather name="plus" size={15} color={colors.primaryForeground} />
                <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.primaryForeground }}>
                  Add Task
                </Text>
              </Pressable>
            ) : null}
          </View>
        }
      />

      {tasksQuery.isError ? (
        <ErrorState onRetry={() => tasksQuery.refetch()} />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={{ padding: 16, paddingBottom: bottomPad, gap: 12 }}
          ListHeaderComponent={filtersHeader}
          ListHeaderComponentStyle={{ marginBottom: 4 }}
          refreshing={tasksQuery.isRefetching}
          onRefresh={() => tasksQuery.refetch()}
          ListEmptyComponent={
            <View style={{ paddingTop: 60 }}>
              <EmptyState icon="check-square" title="No tasks here" message="Try adjusting your filters, or check back later." />
            </View>
          }
          renderItem={({ item }) => (
            <Pressable onPress={() => (selectMode ? toggleSelect(item.id) : router.push(`/task/${item.id}`))}>
              <Card style={{ gap: 10 }}>
                <View style={styles.taskTop}>
                  {selectMode ? (
                    <Feather
                      name={selected.has(item.id) ? "check-circle" : "circle"}
                      size={20}
                      color={selected.has(item.id) ? colors.primary : colors.mutedForeground}
                    />
                  ) : null}
                  <Text style={[styles.taskTitle, { color: colors.foreground }]} numberOfLines={2}>
                    {item.title}
                  </Text>
                  {selectMode ? null : (
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 14 }}>
                      {Platform.OS !== "web" ? (
                        <Pressable onPress={() => openReminder(item)} hitSlop={8}>
                          <Feather
                            name="bell"
                            size={17}
                            color={hasActiveReminder(item.id) ? colors.primary : colors.mutedForeground}
                          />
                        </Pressable>
                      ) : null}
                      {canDelete(item) ? (
                        <Pressable onPress={() => onDelete(item)} hitSlop={8}>
                          <Feather name="trash-2" size={17} color="#ef4444" />
                        </Pressable>
                      ) : null}
                      <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
                    </View>
                  )}
                </View>
                {item.description ? (
                  <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }} numberOfLines={2}>
                    {item.description}
                  </Text>
                ) : null}
                {item.remark ? (
                  <View style={styles.remarkBox}>
                    <Text style={styles.remarkText} numberOfLines={2}>
                      💬 {item.remark}
                    </Text>
                  </View>
                ) : null}
                <View style={styles.taskMeta}>
                  <StatusPill status={item.status} />
                  <PriorityBadge priority={item.priority} />
                  {item.category ? (
                    <View style={[styles.tag, { borderColor: colors.border }]}>
                      <Text style={{ fontFamily: "Inter_500Medium", fontSize: 12, color: colors.mutedForeground }}>
                        {item.category}
                      </Text>
                    </View>
                  ) : null}
                  {item.dueDate ? (
                    <View style={styles.due}>
                      <Feather name="calendar" size={12} color={colors.mutedForeground} />
                      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                        {item.dueDate}
                      </Text>
                    </View>
                  ) : null}
                </View>
              </Card>
            </Pressable>
          )}
        />
      )}

      <Modal visible={showAdd} transparent animationType="slide" onRequestClose={() => setShowAdd(false)}>
        <View style={styles.modalBackdrop}>
          <Pressable style={{ flex: 1 }} onPress={() => setShowAdd(false)} />
          <View style={[styles.modalSheet, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>Add My Task</Text>
              <Pressable onPress={() => setShowAdd(false)} hitSlop={10}>
                <Feather name="x" size={20} color={colors.mutedForeground} />
              </Pressable>
            </View>
            <ScrollView
              contentContainerStyle={{ gap: 14, paddingBottom: 24 }}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
            >
              <TextField label="Task Title *" value={addTitle} onChangeText={setAddTitle} placeholder="What do you need to do?" />
              <TextField label="Description" value={addDescription} onChangeText={setAddDescription} placeholder="Optional details…" multiline />
              <TextField label="Due Date" value={addDueDate} onChangeText={setAddDueDate} placeholder="YYYY-MM-DD" />
              <View style={{ gap: 6 }}>
                <FieldLabel>Priority</FieldLabel>
                <Segmented
                  options={[
                    { value: "high", label: "High" },
                    { value: "medium", label: "Medium" },
                    { value: "low", label: "Low" },
                  ]}
                  value={addPriority}
                  onChange={setAddPriority}
                />
              </View>
              <View style={{ gap: 6 }}>
                <FieldLabel>Type</FieldLabel>
                <Segmented
                  options={[
                    { value: "daily", label: "Daily" },
                    { value: "weekly", label: "Weekly" },
                    { value: "monthly", label: "Monthly" },
                    { value: "one_time", label: "One Time" },
                  ]}
                  value={addType}
                  onChange={setAddType}
                />
              </View>
              {categoryOptions.length > 1 ? (
                <Select
                  label="Category"
                  value={addCategory || null}
                  options={[
                    { value: "", label: "None" },
                    ...categoryOptions.filter((o) => o.value !== "all"),
                  ]}
                  onChange={(v) => setAddCategory(v)}
                  placeholder="None"
                />
              ) : null}
              <TextField label="Remark" value={addRemark} onChangeText={setAddRemark} placeholder="Optional remark…" />
              <Button label="Add Task" icon="plus-circle" onPress={onAddTask} loading={createTask.isPending} />
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Modal visible={reminderTask != null} transparent animationType="slide" onRequestClose={() => setReminderTask(null)}>
        <View style={styles.modalBackdrop}>
          <Pressable style={{ flex: 1 }} onPress={() => setReminderTask(null)} />
          <View style={[styles.modalSheet, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>Set Reminder</Text>
              <Pressable onPress={() => setReminderTask(null)} hitSlop={10}>
                <Feather name="x" size={20} color={colors.mutedForeground} />
              </Pressable>
            </View>
            <ScrollView
              contentContainerStyle={{ gap: 14, paddingBottom: 24 }}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
            >
              <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground }} numberOfLines={2}>
                {reminderTask?.title}
              </Text>
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>
                You will get a notification on this device at the chosen time.
              </Text>
              <TextField label="Date *" value={remDate} onChangeText={setRemDate} placeholder="YYYY-MM-DD" />
              <TextField label="Time * (24-hour)" value={remTime} onChangeText={setRemTime} placeholder="HH:MM" />
              <Button label="Save Reminder" icon="bell" onPress={saveReminder} />
              {reminderTask && reminders[String(reminderTask.id)] ? (
                <Button label="Remove Reminder" variant="secondary" icon="bell-off" onPress={clearReminder} />
              ) : null}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {selectMode ? (
        <View
          style={[
            styles.bulkBar,
            { backgroundColor: colors.card, borderColor: colors.border, bottom: bottomPad - 16 },
          ]}
        >
          <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground }}>
            {selected.size} selected
          </Text>
          <View style={{ flex: 1 }} />
          <Pressable
            onPress={() => bulkComplete(filtered)}
            disabled={bulkBusy || selected.size === 0}
            style={{
              backgroundColor: selected.size === 0 || bulkBusy ? colors.muted : colors.primary,
              borderRadius: 999,
              paddingHorizontal: 16,
              paddingVertical: 9,
              flexDirection: "row",
              alignItems: "center",
              gap: 6,
            }}
          >
            <Feather
              name="check-circle"
              size={15}
              color={selected.size === 0 || bulkBusy ? colors.mutedForeground : colors.primaryForeground}
            />
            <Text
              style={{
                fontFamily: "Inter_600SemiBold",
                fontSize: 13,
                color: selected.size === 0 || bulkBusy ? colors.mutedForeground : colors.primaryForeground,
              }}
            >
              {bulkBusy ? "Completing…" : "Mark Done"}
            </Text>
          </Pressable>
        </View>
      ) : null}
    </View>
  );
}

/** Shared helper so task detail can invalidate this list after mutations. */
export function useInvalidateMyTasks() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return () => {
    qc.invalidateQueries({ queryKey: getListTasksQueryKey({ assignedTo: user?.id ?? undefined }) });
    qc.invalidateQueries();
  };
}

const styles = StyleSheet.create({
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 14,
    borderWidth: StyleSheet.hairlineWidth,
    height: 46,
  },
  searchInput: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 15, paddingVertical: 0 },
  filterLabel: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.4, marginLeft: 2 },
  taskTop: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  taskTitle: { fontFamily: "Inter_600SemiBold", fontSize: 15, flex: 1 },
  taskMeta: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" },
  tag: { borderWidth: StyleSheet.hairlineWidth, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  remarkBox: { backgroundColor: "rgba(245,158,11,0.12)", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 5 },
  remarkText: { fontFamily: "Inter_500Medium", fontSize: 12, color: "#b45309" },
  due: { flexDirection: "row", alignItems: "center", gap: 4 },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" },
  modalSheet: {
    maxHeight: "85%",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 18,
    paddingTop: 16,
    paddingBottom: 28,
  },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 14 },
  modalTitle: { fontFamily: "Inter_700Bold", fontSize: 17 },
  bulkBar: {
    position: "absolute",
    left: 16,
    right: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: "#000",
    shadowOpacity: 0.12,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
});
