import type { Notification } from "@workspace/api-client-react";
import {
  getListNotificationsQueryKey,
  useListNotifications,
  useMarkAllNotificationsRead,
  useMarkNotificationRead,
} from "@workspace/api-client-react";
import { Feather } from "@expo/vector-icons";
import { useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";

import {
  AppHeader,
  Card,
  EmptyState,
  ErrorState,
  LoadingState,
  useTabContentPadding,
} from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export default function NotificationsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useAuth();
  const qc = useQueryClient();
  const bottomPad = useTabContentPadding();

  const query = useListNotifications(
    { userId: user?.id ?? 0 },
    {
      query: {
        enabled: !!user?.id,
        refetchInterval: 30000,
        queryKey: getListNotificationsQueryKey({ userId: user?.id ?? 0 }),
      },
    },
  );
  const markRead = useMarkNotificationRead();
  const markAll = useMarkAllNotificationsRead();

  const items: Notification[] = query.data ?? [];
  const unread = items.filter((n) => !n.read).length;

  const invalidate = () =>
    qc.invalidateQueries({ queryKey: getListNotificationsQueryKey({ userId: user?.id ?? 0 }) });

  const onPressItem = async (n: Notification) => {
    if (!n.read) {
      await markRead.mutateAsync({ id: n.id });
      invalidate();
    }
    if (n.taskId) router.push(`/task/${n.taskId}`);
  };

  const onMarkAll = async () => {
    if (!user?.id) return;
    await markAll.mutateAsync({ data: { userId: user.id } });
    invalidate();
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <AppHeader
        title="Notifications"
        subtitle={unread > 0 ? `${unread} unread` : "All caught up"}
        right={
          unread > 0 ? (
            <Pressable onPress={onMarkAll} hitSlop={8} style={styles.markAll}>
              <Feather name="check-circle" size={16} color={colors.primary} />
              <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.primary }}>
                Mark all
              </Text>
            </Pressable>
          ) : undefined
        }
      />

      {query.isLoading ? (
        <LoadingState />
      ) : query.isError ? (
        <ErrorState onRetry={() => query.refetch()} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={{ padding: 16, paddingBottom: bottomPad, gap: 10 }}
          refreshing={query.isRefetching}
          onRefresh={() => query.refetch()}
          scrollEnabled={items.length > 0}
          ListEmptyComponent={
            <View style={{ paddingTop: 80 }}>
              <EmptyState icon="bell" title="No notifications" message="You'll be notified about task activity here." />
            </View>
          }
          renderItem={({ item }) => (
            <Pressable onPress={() => onPressItem(item)}>
              <Card
                style={{
                  flexDirection: "row",
                  gap: 12,
                  backgroundColor: item.read ? colors.card : colors.accent,
                  borderColor: item.read ? colors.border : colors.primary,
                }}
              >
                <View style={[styles.dotWrap]}>
                  {!item.read ? <View style={[styles.dot, { backgroundColor: colors.primary }]} /> : null}
                  <Feather name="bell" size={18} color={item.read ? colors.mutedForeground : colors.primary} />
                </View>
                <View style={{ flex: 1, gap: 4 }}>
                  <Text style={{ fontFamily: item.read ? "Inter_400Regular" : "Inter_600SemiBold", color: colors.foreground, fontSize: 14 }}>
                    {item.message}
                  </Text>
                  <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                    {timeAgo(item.createdAt)}
                  </Text>
                </View>
              </Card>
            </Pressable>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  markAll: { flexDirection: "row", alignItems: "center", gap: 5 },
  dotWrap: { width: 24, alignItems: "center", justifyContent: "center" },
  dot: { position: "absolute", top: -2, right: -2, width: 8, height: 8, borderRadius: 999, zIndex: 1 },
});
