import type { Task, User } from "@workspace/api-client-react";
import {
  getListTasksQueryKey,
  getListUsersQueryKey,
  useListTasks,
  useListUsers,
} from "@workspace/api-client-react";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";

import {
  AppHeader,
  Card,
  EmptyState,
  ErrorState,
  LoadingState,
  PriorityBadge,
  Segmented,
  Select,
  StatusPill,
  useTabContentPadding,
  type Option,
} from "@/components/ui";
import { useColors } from "@/hooks/useColors";

// Preferred display order of centers; any others fall after these (mirrors web).
const CENTER_ORDER = ["Head Office", "Thane Center", "Malad Center", "Pune Center", "Navi Mumbai Center"];

const STATUS_OPTIONS: Option[] = [
  { value: "all", label: "All Status" },
  { value: "pending", label: "Pending" },
  { value: "inProgress", label: "In Progress" },
  { value: "done", label: "Done" },
];

const TYPE_OPTIONS: Option[] = [
  { value: "all", label: "All Types" },
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "one_time", label: "One Time" },
];

export default function AllTasksScreen() {
  const colors = useColors();
  const router = useRouter();
  const bottomPad = useTabContentPadding();
  const [status, setStatus] = useState("all");
  const [type, setType] = useState("all");
  const [center, setCenter] = useState("all");
  const [member, setMember] = useState("all");

  const tasksQuery = useListTasks(
    {},
    { query: { queryKey: getListTasksQueryKey({}) } },
  );
  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey() } });

  const users = usersQuery.data ?? [];
  const nameById = useMemo(() => {
    const map = new Map<number, string>();
    users.forEach((u: User) => map.set(u.id, u.name));
    return map;
  }, [users]);
  const centerById = useMemo(() => {
    const map = new Map<number, string>();
    users.forEach((u: User) => {
      if (u.center) map.set(u.id, u.center);
    });
    return map;
  }, [users]);

  // Center options — Head Office first, then known centers in display order (mirrors web).
  const centerOptions = useMemo(() => {
    const set = new Set(users.map((u: User) => u.center).filter((c): c is string => Boolean(c)));
    const rank = (c: string) => {
      const i = CENTER_ORDER.indexOf(c);
      return i === -1 ? CENTER_ORDER.length : i;
    };
    const sorted = Array.from(set).sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
    return [{ value: "all", label: "All Centers" }, ...sorted.map((c) => ({ value: c, label: c }))];
  }, [users]);

  // Member options — narrowed to the selected center, sorted by name.
  const memberOptions = useMemo(() => {
    const list = users
      .filter((u: User) => center === "all" || u.center === center)
      .slice()
      .sort((a: User, b: User) => a.name.localeCompare(b.name));
    return [
      { value: "all", label: "All Members" },
      ...list.map((u: User) => ({ value: String(u.id), label: u.center ? `${u.name} — ${u.center}` : u.name })),
    ];
  }, [users, center]);

  const tasks: Task[] = tasksQuery.data ?? [];
  const filtered = tasks.filter(
    (t) =>
      (status === "all" || t.status === status) &&
      (type === "all" || t.type === type) &&
      (center === "all" || (t.assignedTo != null && centerById.get(t.assignedTo) === center)) &&
      (member === "all" || String(t.assignedTo) === member),
  );

  if (tasksQuery.isLoading) return <LoadingState />;
  if (tasksQuery.isError) return <ErrorState onRetry={() => tasksQuery.refetch()} />;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <AppHeader title="All Tasks" subtitle={`${filtered.length} of ${tasks.length}`} />
      <View style={{ paddingHorizontal: 16, paddingTop: 12, gap: 10 }}>
        <Segmented options={STATUS_OPTIONS} value={status} onChange={setStatus} />
        <Segmented options={TYPE_OPTIONS} value={type} onChange={setType} />
        <View style={{ flexDirection: "row", gap: 10 }}>
          {centerOptions.length > 2 ? (
            <View style={{ flex: 1 }}>
              <Select
                value={center === "all" ? null : center}
                options={centerOptions}
                onChange={(v) => {
                  setCenter(v);
                  setMember("all");
                }}
                placeholder="All Centers"
              />
            </View>
          ) : null}
          <View style={{ flex: 1 }}>
            <Select
              value={member === "all" ? null : member}
              options={memberOptions}
              onChange={(v) => setMember(v)}
              placeholder="All Members"
            />
          </View>
        </View>
      </View>
      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPad, gap: 12 }}
        refreshing={tasksQuery.isRefetching}
        onRefresh={() => tasksQuery.refetch()}
        scrollEnabled={filtered.length > 0}
        ListEmptyComponent={
          <View style={{ paddingTop: 80 }}>
            <EmptyState icon="list" title="No tasks found" message="Try changing the filters above." />
          </View>
        }
        renderItem={({ item }) => (
          <Pressable onPress={() => router.push(`/task/${item.id}`)}>
            <Card style={{ gap: 10 }}>
              <View style={styles.top}>
                <Text style={[styles.title, { color: colors.foreground }]} numberOfLines={2}>
                  {item.title}
                </Text>
                <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
              </View>
              <View style={styles.meta}>
                <StatusPill status={item.status} />
                <PriorityBadge priority={item.priority} />
              </View>
              <View style={styles.meta}>
                {item.assignedTo != null ? (
                  <View style={styles.metaItem}>
                    <Feather name="user" size={12} color={colors.mutedForeground} />
                    <Text style={[styles.metaText, { color: colors.mutedForeground }]}>
                      {nameById.get(item.assignedTo) ?? `#${item.assignedTo}`}
                    </Text>
                  </View>
                ) : (
                  <Text style={[styles.metaText, { color: colors.mutedForeground }]}>Unassigned</Text>
                )}
                {item.dueDate ? (
                  <View style={styles.metaItem}>
                    <Feather name="calendar" size={12} color={colors.mutedForeground} />
                    <Text style={[styles.metaText, { color: colors.mutedForeground }]}>{item.dueDate}</Text>
                  </View>
                ) : null}
              </View>
            </Card>
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  title: { fontFamily: "Inter_600SemiBold", fontSize: 15, flex: 1 },
  meta: { flexDirection: "row", alignItems: "center", gap: 10, flexWrap: "wrap" },
  metaItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  metaText: { fontFamily: "Inter_400Regular", fontSize: 12 },
});
