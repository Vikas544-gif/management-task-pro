import { useListAttendance, useListTasks, useListUsers } from "@workspace/api-client-react";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import React from "react";
import {
  Dimensions,
  Modal,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  BarChart,
  CHART_COLORS,
  DonutChart,
  GroupedBarChart,
  LineTrend,
} from "@/components/charts";
import { Card, ErrorState, LoadingState, useTabContentPadding } from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

const CENTER_ORDER = ["Head Office", "Thane Center", "Malad Center", "Pune Center", "Navi Mumbai Center"];
const DEPT_ORDER = ["Management", "Accounts", "MIS", "HR", "IT"];
const AVATAR_COLORS = ["#0ea5e9", "#8b5cf6", "#ec4899", "#f59e0b", "#10b981", "#ef4444", "#6366f1", "#14b8a6"];
const DATE_MODES = [
  { key: "all", label: "All dates" },
  { key: "today", label: "Today" },
  { key: "week", label: "This Week" },
  { key: "month", label: "This Month" },
] as const;
type DateMode = (typeof DATE_MODES)[number]["key"];

type Task = {
  id: number;
  title?: string | null;
  status: string;
  type: string;
  priority: string;
  dueDate?: string | null;
  createdAt: string;
  assignedTo?: number | null;
  assignedToName?: string | null;
  assignedBy?: number | null;
  department?: string | null;
};

const STATUS_META: Record<string, { label: string; color: string }> = {
  pending: { label: "Pending", color: "#ef4444" },
  inProgress: { label: "In Progress", color: "#f59e0b" },
  done: { label: "Done", color: "#22c55e" },
};

function taskDateOf(t: Task) {
  return t.dueDate || t.createdAt?.split("T")[0] || "";
}

function isoOf(d: Date) {
  return `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, "0")}-${d.getDate().toString().padStart(2, "0")}`;
}

function rangeFor(mode: DateMode): { from: string | null; to: string | null } {
  const now = new Date();
  const today = isoOf(now);
  if (mode === "today") return { from: today, to: today };
  if (mode === "week") {
    const f = new Date(now);
    f.setDate(now.getDate() - 6);
    return { from: isoOf(f), to: today };
  }
  if (mode === "month") return { from: isoOf(new Date(now.getFullYear(), now.getMonth(), 1)), to: today };
  return { from: null, to: null };
}

/** Mirror of web isTaskHiddenByAbsence: only DAILY tasks hide when the
 *  assignee was marked absent/leave on the task's due date. */
function isHiddenByAbsence(t: Task, absenceSet: Set<string>) {
  if (t.type !== "daily") return false;
  if (!t.assignedTo || !t.dueDate) return false;
  return absenceSet.has(`${t.assignedTo}|${String(t.dueDate).slice(0, 10)}`);
}

function fmtClock(d: Date) {
  let h = d.getHours();
  const m = d.getMinutes().toString().padStart(2, "0");
  const ap = h >= 12 ? "pm" : "am";
  h = h % 12 || 12;
  return `${h.toString().padStart(2, "0")}:${m} ${ap}`;
}

function initials(name: string) {
  const p = name.trim().split(/\s+/);
  return ((p[0]?.[0] ?? "") + (p[1]?.[0] ?? "")).toUpperCase() || "?";
}

function priorityColor(p: string) {
  const k = p.toLowerCase();
  if (k.includes("urgent") || k.includes("high")) return CHART_COLORS.pending;
  if (k.includes("med")) return CHART_COLORS.inProgress;
  if (k.includes("low")) return CHART_COLORS.done;
  return CHART_COLORS.slate;
}

function Pill({
  label,
  active,
  onPress,
  leading,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
  leading?: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={[
        pillS.pill,
        {
          backgroundColor: active ? colors.primary : colors.card,
          borderColor: active ? colors.primary : colors.border,
        },
      ]}
    >
      {leading}
      <Text
        style={{
          fontFamily: "Inter_500Medium",
          fontSize: 12.5,
          color: active ? colors.primaryForeground : colors.foreground,
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}

function FilterRow({ children }: { children: React.ReactNode }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={pillS.row}>
      {children}
    </ScrollView>
  );
}

function KpiCard({
  value,
  label,
  sub,
  bg,
  onPress,
}: {
  value: string | number;
  label: string;
  sub: string;
  bg: string;
  onPress?: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={[kpiS.card, { backgroundColor: bg }]}>
      <Text style={kpiS.value}>{value}</Text>
      <Text style={kpiS.label}>{label}</Text>
      <Text style={kpiS.sub}>{sub}</Text>
    </Pressable>
  );
}

function QuickCard({
  title,
  total,
  done,
  pending,
  rate,
}: {
  title: string;
  total: number;
  done: number;
  pending: number;
  rate: number;
}) {
  const colors = useColors();
  return (
    <Card style={{ gap: 8 }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
        <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 12, color: colors.mutedForeground, letterSpacing: 0.4 }}>
          {title.toUpperCase()}
        </Text>
        <Text style={{ fontFamily: "Inter_700Bold", fontSize: 13, color: colors.primary }}>{rate}%</Text>
      </View>
      <Text style={{ fontFamily: "Inter_700Bold", fontSize: 28, color: colors.foreground }}>{total}</Text>
      <View style={{ flexDirection: "row", gap: 14 }}>
        <Text style={{ fontFamily: "Inter_500Medium", fontSize: 12, color: CHART_COLORS.done }}>✓ {done} done</Text>
        <Text style={{ fontFamily: "Inter_500Medium", fontSize: 12, color: CHART_COLORS.pending }}>⚠ {pending} pending</Text>
      </View>
      <View style={{ height: 6, borderRadius: 3, backgroundColor: colors.border, overflow: "hidden" }}>
        <View style={{ width: `${rate}%`, height: "100%", backgroundColor: colors.primary }} />
      </View>
    </Card>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  const colors = useColors();
  return (
    <Card style={{ gap: 12 }}>
      <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 12, color: colors.mutedForeground, letterSpacing: 0.4 }}>
        {title.toUpperCase()}
      </Text>
      {children}
    </Card>
  );
}

export default function DashboardScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const bottomPad = useTabContentPadding();

  const tasksQuery = useListTasks({});
  const usersQuery = useListUsers();
  const attendanceQuery = useListAttendance();

  const [clock, setClock] = React.useState(() => fmtClock(new Date()));
  React.useEffect(() => {
    const id = setInterval(() => setClock(fmtClock(new Date())), 10000);
    return () => clearInterval(id);
  }, []);

  const [centerFilter, setCenterFilter] = React.useState<string | null>(null);
  const [deptFilter, setDeptFilter] = React.useState<string | null>(null);
  const [memberFilter, setMemberFilter] = React.useState<number | null>(null);
  const [dateMode, setDateMode] = React.useState<DateMode>("all");
  const [detailStatus, setDetailStatus] = React.useState<"pending" | "inProgress" | "done" | "all" | null>(null);

  const allTasks = (tasksQuery.data ?? []) as Task[];
  const users = usersQuery.data ?? [];

  const userCenter = React.useMemo(
    () => new Map(users.map((u) => [u.id, u.center])),
    [users],
  );

  const userName = React.useMemo(
    () => new Map(users.map((u) => [u.id, u.name])),
    [users],
  );

  const absenceSet = React.useMemo(() => {
    const set = new Set<string>();
    for (const a of attendanceQuery.data ?? []) {
      if (a.status === "absent" || a.status === "leave") set.add(`${a.userId}|${a.date}`);
    }
    return set;
  }, [attendanceQuery.data]);

  const centers = React.useMemo(() => {
    const present = new Set(users.map((u) => u.center).filter(Boolean) as string[]);
    const ordered = CENTER_ORDER.filter((c) => present.has(c));
    const extras = [...present].filter((c) => !CENTER_ORDER.includes(c));
    return [...ordered, ...extras];
  }, [users]);

  const departments = React.useMemo(() => {
    const present = new Set(users.map((u) => u.department).filter(Boolean));
    const ordered = DEPT_ORDER.filter((d) => present.has(d));
    const extras = [...present].filter((d) => !DEPT_ORDER.includes(d));
    return [...ordered, ...extras];
  }, [users]);

  const members = React.useMemo(
    () =>
      users
        .filter((u) => (!centerFilter || u.center === centerFilter) && (!deptFilter || u.department === deptFilter))
        .sort((a, b) => a.name.localeCompare(b.name)),
    [users, centerFilter, deptFilter],
  );

  const scopedTasks = React.useMemo(() => {
    let t = allTasks.filter((x) => !isHiddenByAbsence(x, absenceSet));
    if (centerFilter) t = t.filter((x) => x.assignedTo != null && userCenter.get(x.assignedTo) === centerFilter);
    if (deptFilter) t = t.filter((x) => x.department === deptFilter);
    if (memberFilter) t = t.filter((x) => x.assignedTo === memberFilter);
    return t;
  }, [allTasks, centerFilter, deptFilter, memberFilter, userCenter, absenceSet]);

  const range = React.useMemo(() => rangeFor(dateMode), [dateMode]);

  const tasks = React.useMemo(() => {
    if (!range.from) return scopedTasks;
    return scopedTasks.filter((x) => {
      const d = taskDateOf(x);
      return d >= range.from! && d <= range.to!;
    });
  }, [scopedTasks, range]);

  const pending = tasks.filter((t) => t.status === "pending").length;
  const inProgress = tasks.filter((t) => t.status === "inProgress").length;
  const done = tasks.filter((t) => t.status === "done").length;
  const total = tasks.length;
  const doneRate = total > 0 ? Math.round((done / total) * 100) : 0;

  const typeStats = React.useMemo(
    () =>
      (["daily", "weekly", "monthly"] as const).map((ty) => {
        const list = tasks.filter((x) => x.type === ty);
        const d = list.filter((x) => x.status === "done").length;
        const tot = list.length;
        return { ty, total: tot, done: d, pending: tot - d, rate: tot ? Math.round((d / tot) * 100) : 0 };
      }),
    [tasks],
  );

  const periodDays = React.useMemo(() => {
    const out: { iso: string; label: string }[] = [];
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const iso = `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, "0")}-${d.getDate().toString().padStart(2, "0")}`;
      out.push({ iso, label: d.toLocaleDateString("en-US", { weekday: "short" }) });
    }
    return out;
  }, []);

  const trendData = periodDays.map((p) => ({
    label: p.label,
    completed: scopedTasks.filter((t) => taskDateOf(t) === p.iso && t.status === "done").length,
    total: scopedTasks.filter((t) => taskDateOf(t) === p.iso).length,
  }));

  const weeklyData = periodDays.map((p) => ({
    label: p.label,
    done: scopedTasks.filter((t) => taskDateOf(t) === p.iso && t.status === "done").length,
    pending: scopedTasks.filter((t) => taskDateOf(t) === p.iso && t.status === "pending").length,
  }));

  const priorityData = React.useMemo(() => {
    const map = new Map<string, number>();
    tasks.forEach((t) => map.set(t.priority, (map.get(t.priority) ?? 0) + 1));
    return [...map.entries()]
      .map(([label, value]) => ({ label, value, color: priorityColor(label) }))
      .sort((a, b) => b.value - a.value);
  }, [tasks]);

  const statusData = [
    { label: "Pending", value: pending, color: CHART_COLORS.pending },
    { label: "In Progress", value: inProgress, color: CHART_COLORS.inProgress },
    { label: "Done", value: done, color: CHART_COLORS.done },
  ];

  const chartW = Dimensions.get("window").width - 32 - 32;
  const refreshing = tasksQuery.isRefetching || usersQuery.isRefetching;
  const onRefresh = () => {
    tasksQuery.refetch();
    usersQuery.refetch();
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <LinearGradient
        colors={["#0f1729", "#122a3a", "#14384a"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.hero, { paddingTop: insets.top + 14 }]}
      >
        <View style={styles.brandRow}>
          <View style={styles.brandBars}>
            <View style={[styles.bar, { height: 10, backgroundColor: "#22d3ee" }]} />
            <View style={[styles.bar, { height: 15, backgroundColor: "#2dd4bf" }]} />
            <View style={[styles.bar, { height: 20, backgroundColor: "#34d399" }]} />
          </View>
          <Text style={styles.brandText}>MANAGEMENT TASK PRO</Text>
        </View>
        <Text style={styles.heroTitle}>Task Analytics Dashboard</Text>
        <View style={styles.heroMeta}>
          <Text style={styles.heroMetaText}>
            {user?.name ?? "User"}
            {user?.role ? ` · ${user.role}` : ""}
          </Text>
          <View style={styles.liveDot} />
          <Text style={styles.heroLive}>Live</Text>
          <Text style={styles.heroMetaText}>· {clock}</Text>
        </View>
      </LinearGradient>

      {tasksQuery.isLoading ? (
        <LoadingState />
      ) : tasksQuery.isError ? (
        <ErrorState onRetry={() => tasksQuery.refetch()} />
      ) : (
        <ScrollView
          contentContainerStyle={{ padding: 16, paddingBottom: bottomPad, gap: 16 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
        >
          {/* Filters */}
          <Card style={{ gap: 12 }}>
            <View style={{ gap: 6 }}>
              <Text style={filterS.head}>FILTER BY DATE</Text>
              <FilterRow>
                {DATE_MODES.map((m) => (
                  <Pill key={m.key} label={m.label} active={dateMode === m.key} onPress={() => setDateMode(m.key)} />
                ))}
              </FilterRow>
            </View>

            {centers.length > 1 ? (
              <View style={{ gap: 6 }}>
                <Text style={filterS.head}>CENTER</Text>
                <FilterRow>
                  <Pill
                    label="All Centers"
                    active={!centerFilter}
                    onPress={() => {
                      setCenterFilter(null);
                      setDeptFilter(null);
                      setMemberFilter(null);
                    }}
                  />
                  {centers.map((c) => (
                    <Pill
                      key={c}
                      label={c}
                      active={centerFilter === c}
                      onPress={() => {
                        setCenterFilter(c);
                        setDeptFilter(null);
                        setMemberFilter(null);
                      }}
                    />
                  ))}
                </FilterRow>
              </View>
            ) : null}

            <View style={{ gap: 6 }}>
              <Text style={filterS.head}>DEPARTMENT</Text>
              <FilterRow>
                <Pill
                  label="All"
                  active={!deptFilter}
                  onPress={() => {
                    setDeptFilter(null);
                    setMemberFilter(null);
                  }}
                />
                {departments.map((d) => (
                  <Pill
                    key={d}
                    label={d}
                    active={deptFilter === d}
                    onPress={() => {
                      setDeptFilter(d);
                      setMemberFilter(null);
                    }}
                  />
                ))}
              </FilterRow>
            </View>

            <View style={{ gap: 6 }}>
              <Text style={filterS.head}>MEMBER</Text>
              <FilterRow>
                <Pill label="All Members" active={!memberFilter} onPress={() => setMemberFilter(null)} />
                {members.map((m, i) => (
                  <Pill
                    key={m.id}
                    label={m.name.split(/\s+/)[0]}
                    active={memberFilter === m.id}
                    onPress={() => setMemberFilter(m.id)}
                    leading={
                      <View style={[filterS.avatar, { backgroundColor: AVATAR_COLORS[i % AVATAR_COLORS.length] }]}>
                        <Text style={filterS.avatarTxt}>{initials(m.name)}</Text>
                      </View>
                    }
                  />
                ))}
              </FilterRow>
            </View>
          </Card>

          {/* KPI cards */}
          <View style={kpiS.grid}>
            <KpiCard value={pending} label="Pending" sub="Click to view ›" bg="#ef4444" onPress={() => setDetailStatus("pending")} />
            <KpiCard value={inProgress} label="In Progress" sub="Click to view ›" bg="#f59e0b" onPress={() => setDetailStatus("inProgress")} />
            <KpiCard value={done} label="Completed" sub={`${doneRate}% · Click to view ›`} bg="#22c55e" onPress={() => setDetailStatus("done")} />
            <KpiCard value={total} label="Total Tasks" sub="All · Click to view ›" bg="#3b82f6" onPress={() => setDetailStatus("all")} />
          </View>
          <KpiCard value={`${doneRate}%`} label="Done Rate" sub="Completion rate" bg="#1e293b" />

          {/* Quick analytics */}
          <Text style={[filterS.section, { color: colors.foreground }]}>Quick Analytics — Daily / Weekly / Monthly</Text>
          {typeStats.map((s) => (
            <QuickCard
              key={s.ty}
              title={`${s.ty} tasks`}
              total={s.total}
              done={s.done}
              pending={s.pending}
              rate={s.rate}
            />
          ))}

          {/* Charts */}
          <ChartCard title="Daily Completion Trend (7 Days)">
            <LineTrend data={trendData} width={chartW} />
          </ChartCard>

          <ChartCard title="Status Distribution">
            <DonutChart data={statusData} size={128} />
          </ChartCard>

          <ChartCard title="Priority Breakdown">
            {priorityData.length ? (
              <BarChart data={priorityData} width={chartW} />
            ) : (
              <Text style={{ fontFamily: "Inter_400Regular", color: colors.mutedForeground }}>No data</Text>
            )}
          </ChartCard>

          <ChartCard title="Weekly Done vs Pending">
            <GroupedBarChart data={weeklyData} width={chartW} />
          </ChartCard>
        </ScrollView>
      )}

      <TaskDetailModal
        status={detailStatus}
        tasks={tasks}
        userName={userName}
        onClose={() => setDetailStatus(null)}
        onOpenTask={(id) => {
          setDetailStatus(null);
          router.push(`/task/${id}` as never);
        }}
      />
    </View>
  );
}

function TaskDetailModal({
  status,
  tasks,
  userName,
  onClose,
  onOpenTask,
}: {
  status: "pending" | "inProgress" | "done" | "all" | null;
  tasks: Task[];
  userName: Map<number, string>;
  onClose: () => void;
  onOpenTask: (id: number) => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [person, setPerson] = React.useState<number | "none" | "all">("all");

  // Reset the member filter whenever a different KPI card opens the modal.
  React.useEffect(() => {
    setPerson("all");
  }, [status]);

  const baseList = React.useMemo(() => {
    if (!status) return [];
    return status === "all" ? tasks : tasks.filter((t) => t.status === status);
  }, [status, tasks]);

  const people = React.useMemo(() => {
    const map = new Map<number | "none", { id: number | "none"; name: string; count: number }>();
    for (const t of baseList) {
      const id = t.assignedTo ?? "none";
      const name = t.assignedToName ?? (t.assignedTo != null ? userName.get(t.assignedTo) : null) ?? "Unassigned";
      const cur = map.get(id);
      if (cur) cur.count++;
      else map.set(id, { id, name, count: 1 });
    }
    return [...map.values()].sort((a, b) => b.count - a.count);
  }, [baseList, userName]);

  const list = React.useMemo(
    () => (person === "all" ? baseList : baseList.filter((t) => (t.assignedTo ?? "none") === person)),
    [baseList, person],
  );

  const title = status === "all" ? "All Tasks" : status ? STATUS_META[status]?.label ?? "Tasks" : "Tasks";

  return (
    <Modal visible={status !== null} animationType="slide" transparent onRequestClose={onClose}>
      <View style={modalS.backdrop}>
        <View style={[modalS.sheet, { backgroundColor: colors.card, paddingBottom: insets.bottom + 12 }]}>
          <View style={[modalS.header, { borderBottomColor: colors.border }]}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontFamily: "Inter_700Bold", fontSize: 17, color: colors.foreground }}>{title}</Text>
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12.5, color: colors.mutedForeground }}>
                {list.length} task{list.length === 1 ? "" : "s"}
              </Text>
            </View>
            <Pressable onPress={onClose} hitSlop={10} style={[modalS.close, { backgroundColor: colors.secondary }]}>
              <Text style={{ fontFamily: "Inter_700Bold", fontSize: 15, color: colors.secondaryForeground }}>✕</Text>
            </Pressable>
          </View>

          {people.length > 0 ? (
            <View style={[modalS.chipBar, { borderBottomColor: colors.border }]}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingHorizontal: 16 }}>
                <Pressable
                  onPress={() => setPerson("all")}
                  style={[
                    modalS.chip,
                    { backgroundColor: person === "all" ? colors.primary : colors.secondary },
                  ]}
                >
                  <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 12, color: person === "all" ? colors.primaryForeground : colors.secondaryForeground }}>
                    All ({baseList.length})
                  </Text>
                </Pressable>
                {people.map((p) => {
                  const active = person === p.id;
                  return (
                    <Pressable
                      key={String(p.id)}
                      onPress={() => setPerson(p.id)}
                      style={[modalS.chip, { backgroundColor: active ? colors.primary : colors.secondary }]}
                    >
                      <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 12, color: active ? colors.primaryForeground : colors.secondaryForeground }}>
                        {p.name} ({p.count})
                      </Text>
                    </Pressable>
                  );
                })}
              </ScrollView>
            </View>
          ) : null}

          <ScrollView contentContainerStyle={{ padding: 16, gap: 10 }}>
            {list.length === 0 ? (
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 14, color: colors.mutedForeground, textAlign: "center", paddingVertical: 24 }}>
                No tasks to show.
              </Text>
            ) : (
              list.map((t) => {
                const meta = STATUS_META[t.status];
                const assignee = t.assignedToName ?? (t.assignedTo != null ? userName.get(t.assignedTo) : null);
                return (
                  <Pressable
                    key={t.id}
                    onPress={() => onOpenTask(t.id)}
                    style={({ pressed }) => [
                      modalS.taskRow,
                      { backgroundColor: colors.background, borderColor: colors.border, opacity: pressed ? 0.6 : 1 },
                    ]}
                  >
                    <View style={[modalS.dot, { backgroundColor: meta?.color ?? colors.mutedForeground }]} />
                    <View style={{ flex: 1 }}>
                      <Text numberOfLines={2} style={{ fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground }}>
                        {t.title || "Untitled task"}
                      </Text>
                      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, marginTop: 2 }}>
                        {(meta?.label ?? t.status)}
                        {assignee ? ` · ${assignee}` : ""}
                        {t.dueDate ? ` · Due ${t.dueDate}` : ""}
                      </Text>
                    </View>
                    <Text style={{ fontFamily: "Inter_400Regular", fontSize: 16, color: colors.mutedForeground }}>›</Text>
                  </Pressable>
                );
              })
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  hero: {
    paddingHorizontal: 18,
    paddingBottom: 14,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  brandBars: { flexDirection: "row", alignItems: "flex-end", gap: 3, height: 20 },
  bar: { width: 4, borderRadius: 2 },
  brandText: { fontFamily: "Inter_600SemiBold", fontSize: 12, color: "#cbd5e1", letterSpacing: 1 },
  heroTitle: { fontFamily: "Inter_700Bold", fontSize: 20, color: "#ffffff", marginTop: 8 },
  heroMeta: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 8, flexWrap: "wrap" },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#4ade80", marginLeft: 4 },
  heroLive: { fontFamily: "Inter_600SemiBold", fontSize: 12, color: "#4ade80" },
  heroMetaText: { fontFamily: "Inter_400Regular", fontSize: 13, color: "#94a3b8" },
});

const pillS = StyleSheet.create({
  row: { flexDirection: "row", gap: 8, paddingRight: 8 },
  pill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
  },
});

const filterS = StyleSheet.create({
  head: { fontFamily: "Inter_600SemiBold", fontSize: 12, color: "#94a3b8", letterSpacing: 0.6 },
  section: { fontFamily: "Inter_600SemiBold", fontSize: 15, marginTop: 4 },
  avatar: { width: 20, height: 20, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  avatarTxt: { fontFamily: "Inter_700Bold", fontSize: 10, color: "#fff" },
});

const modalS = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" },
  sheet: { maxHeight: "82%", borderTopLeftRadius: 20, borderTopRightRadius: 20, overflow: "hidden" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  close: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  chipBar: { paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth },
  chip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999 },
  taskRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
  },
  dot: { width: 9, height: 9, borderRadius: 5 },
});

const kpiS = StyleSheet.create({
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  card: { width: "47.5%", flexGrow: 1, borderRadius: 14, padding: 13, gap: 1 },
  value: { fontFamily: "Inter_700Bold", fontSize: 24, color: "#fff" },
  label: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: "#fff" },
  sub: { fontFamily: "Inter_400Regular", fontSize: 12, color: "rgba(255,255,255,0.85)", marginTop: 1 },
});
