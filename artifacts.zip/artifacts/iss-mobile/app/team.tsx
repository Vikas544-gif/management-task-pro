import type { AgentMetric, User } from "@workspace/api-client-react";
import {
  getListAgentMetricsQueryKey,
  getListUsersQueryKey,
  useCreateUser,
  useDeleteUser,
  useListAgentMetrics,
  useListUsers,
  useUpdateUser,
  useUpsertAgentMetric,
} from "@workspace/api-client-react";
import { Feather } from "@expo/vector-icons";
import { useQueryClient } from "@tanstack/react-query";
import React, { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  Button,
  Card,
  EmptyState,
  FieldLabel,
  LoadingState,
  Segmented,
  Select,
  TextField,
  type Option,
} from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import {
  buildHierarchySet,
  CENTER_ORDER,
  isAllCentersViewer,
  roleFlags,
} from "@/lib/permissions";

// The four outer centers Agent Tracking covers — Head Office is never included.
const AGENT_CENTERS = ["Thane Center", "Malad Center", "Pune Center", "Navi Mumbai Center"];

// Local "YYYY-MM-DD" for today (avoids UTC quirks) — mirrors the web page.
function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// Parse a DOJ string into a LOCAL date (avoids UTC-shift bugs for "YYYY-MM-DD").
function parseDojLocal(doj: string | null | undefined): Date | null {
  if (!doj) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(doj.trim());
  if (m) {
    const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    return isNaN(d.getTime()) ? null : d;
  }
  const d = new Date(doj);
  return isNaN(d.getTime()) ? null : d;
}

// Breakdown of tenure into years / months / days from DOJ to today.
function tenureBreakdown(doj: string | null | undefined): { years: number; months: number; days: number } | null {
  const start = parseDojLocal(doj);
  if (start == null) return null;
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (start.getTime() > today.getTime()) return { years: 0, months: 0, days: 0 };

  let years = today.getFullYear() - start.getFullYear();
  let months = today.getMonth() - start.getMonth();
  let days = today.getDate() - start.getDate();

  if (days < 0) {
    months -= 1;
    const prevMonthDays = new Date(today.getFullYear(), today.getMonth(), 0).getDate();
    days += prevMonthDays;
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }
  return { years: Math.max(0, years), months: Math.max(0, months), days: Math.max(0, days) };
}

// Total whole months of tenure from DOJ to today (used for bucketing).
function tenureMonths(doj: string | null | undefined): number | null {
  const b = tenureBreakdown(doj);
  if (b == null) return null;
  return b.years * 12 + b.months;
}

// Human-readable tenure like "1 Year 4 Months 15 Days".
function tenureLabel(doj: string | null | undefined): string {
  const b = tenureBreakdown(doj);
  if (b == null) return "—";
  const parts: string[] = [];
  parts.push(`${b.years} ${b.years === 1 ? "Year" : "Years"}`);
  parts.push(`${b.months} ${b.months === 1 ? "Month" : "Months"}`);
  parts.push(`${b.days} ${b.days === 1 ? "Day" : "Days"}`);
  return parts.join(" ");
}

// Tenure bucket derived from total months: only 3 buckets (matches web).
function tenureBucket(doj: string | null | undefined): string {
  const m = tenureMonths(doj);
  if (m == null) return "—";
  if (m < 3) return "0-3 Months";
  if (m < 6) return "3-6 Months";
  return "6+ Months";
}

const METRIC_FIELDS = ["dc", "prospectCount", "salesFd", "salesMtd", "target", "last3mAvg", "last6mAvg"] as const;
type MetricField = (typeof METRIC_FIELDS)[number];
type MetricDraft = Record<MetricField, string>;
const emptyDraft = (): MetricDraft => ({
  dc: "",
  prospectCount: "",
  salesFd: "",
  salesMtd: "",
  target: "",
  last3mAvg: "",
  last6mAvg: "",
});

const METRIC_LABELS: Record<MetricField, string> = {
  dc: "DC",
  prospectCount: "Prospect Count",
  salesFd: "Sales FD",
  salesMtd: "Sales MTD",
  target: "Target",
  last3mAvg: "Last 3M Avg",
  last6mAvg: "Last 6M Avg",
};

// Roll up metric rows per agent for the "All Time" view. DC / Prospect Count /
// Sales FD are daily activity counts, so they SUM across every date. Sales MTD,
// Target and the running averages are point-in-time figures, so we keep the most
// recent NON-NULL entry per agent (rows arrive newest-first). Mirrors the web page.
function aggregateMetricsByAgent(rows: AgentMetric[]) {
  const sums = new Map<number, { dc: number; prospectCount: number; salesFd: number }>();
  const latestNonNull = new Map<number, Record<string, unknown>>();
  const POINT_FIELDS = ["salesMtd", "target", "last3mAvg", "last6mAvg", "remark"] as const;
  for (const m of rows) {
    const s = sums.get(m.agentId) ?? { dc: 0, prospectCount: 0, salesFd: 0 };
    s.dc += Number(m.dc) || 0;
    s.prospectCount += Number(m.prospectCount) || 0;
    s.salesFd += Number(m.salesFd) || 0;
    sums.set(m.agentId, s);
    const p = latestNonNull.get(m.agentId) ?? {};
    for (const f of POINT_FIELDS) {
      const val = (m as unknown as Record<string, unknown>)[f];
      if (p[f] == null && val != null) p[f] = val;
    }
    latestNonNull.set(m.agentId, p);
  }
  const out = new Map<number, Record<string, unknown>>();
  for (const [id, s] of sums) {
    const p = latestNonNull.get(id) ?? {};
    out.set(id, {
      agentId: id,
      dc: s.dc,
      prospectCount: s.prospectCount,
      salesFd: s.salesFd,
      salesMtd: p.salesMtd ?? null,
      target: p.target ?? null,
      last3mAvg: p.last3mAvg ?? null,
      last6mAvg: p.last6mAvg ?? null,
      remark: p.remark ?? null,
    });
  }
  return out;
}

/** Mirrors the web app's resolveAllowedCenters (restriction-only, Boss/MIS). */
function resolveAllowedCenters(
  viewer: User | null | undefined,
  allUsers: { center?: string | null }[],
): Set<string> | null {
  if (!viewer) return null;
  const perms = viewer.centerPermissions;
  if (perms == null) return null;
  const isBoss = viewer.department === "Management" || viewer.role === "Boss";
  const isAll = isAllCentersViewer(viewer);
  if (!isBoss && !isAll) return null;
  const ceiling = new Set(allUsers.map((u) => u.center).filter((c): c is string => Boolean(c)));
  if (isAll && !isBoss) ceiling.delete("Head Office");
  return new Set([...ceiling].filter((c) => perms.includes(c)));
}

const toNum = (s: string): number | null => {
  const t = s.trim();
  if (t === "") return null;
  const n = Number(t);
  return isNaN(n) ? null : n;
};

const showVal = (v: unknown) => (v == null || v === "" ? "—" : String(v));

export default function TeamScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const { user: currentUser } = useAuth();

  const { isBoss, isCenterHead, isMis, isTl } = roleFlags(currentUser);
  // Agent Tracking is restricted to the Boss, MIS, Center Heads and Team Leaders —
  // exactly like the web page. Everyone else is denied.
  const canSeeTracking = isBoss || isMis || isCenterHead || isTl;
  // Boss / MIS / Center Head can (re)assign which TL/head an agent reports to.
  const canAssignTl = isBoss || isMis || isCenterHead;
  // TLs may also move an agent's center (server-scoped to their own team).
  const canAssignCenter = canAssignTl || isTl;

  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey() } });
  const allUsers = useMemo(() => usersQuery.data ?? [], [usersQuery.data]);

  const [dateMode, setDateMode] = useState<"today" | "all">("today");
  const [centerFilter, setCenterFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState<"Active" | "Inactive" | "All">("Active");
  const today = todayISO();

  const dayMetricsQuery = useListAgentMetrics(
    { date: today },
    { query: { enabled: canSeeTracking && dateMode === "today", queryKey: getListAgentMetricsQueryKey({ date: today }) } },
  );
  const allMetricsQuery = useListAgentMetrics(
    {},
    { query: { enabled: canSeeTracking, queryKey: getListAgentMetricsQueryKey({}) } },
  );
  const dayMetrics = useMemo(() => dayMetricsQuery.data ?? [], [dayMetricsQuery.data]);
  const allMetrics = useMemo(() => allMetricsQuery.data ?? [], [allMetricsQuery.data]);

  const upsertMetric = useUpsertAgentMetric();
  const updateUser = useUpdateUser();
  const createUser = useCreateUser();
  const deleteUser = useDeleteUser();

  // Full recursive org-chart subtree under the current user (BFS).
  const hierarchyIds = useMemo(
    () => (currentUser ? buildHierarchySet(currentUser.id, allUsers) : new Set<number>()),
    [currentUser, allUsers],
  );
  const allowedCenters = useMemo(
    () => resolveAllowedCenters(currentUser, allUsers),
    [currentUser, allUsers],
  );
  const myCenter = useMemo(
    () => allUsers.find((u) => u.id === currentUser?.id)?.center,
    [allUsers, currentUser?.id],
  );

  // Scope of people this viewer manages (excludes self). MIS/Boss see everyone.
  const teamToShow = useMemo(() => {
    if (!currentUser) return [];
    let base: User[];
    if (isMis || isBoss) base = allUsers.filter((u) => u.id !== currentUser.id);
    else base = allUsers.filter((u) => hierarchyIds.has(u.id) && u.id !== currentUser.id);
    if (allowedCenters) base = base.filter((u) => u.center && allowedCenters.has(u.center));
    return base;
  }, [allUsers, hierarchyIds, currentUser, isMis, isBoss, allowedCenters]);

  // Agent Tracking rows: only Sales Agents in a real center (never Head Office).
  const trackingBase = useMemo(
    () => teamToShow.filter((u) => u.role === "Sales Agent" && u.center && u.center !== "Head Office"),
    [teamToShow],
  );

  // Center filter pills — always offer the four centers to Boss/MIS.
  const centerOptions = useMemo(() => {
    const set = new Set(trackingBase.map((u) => u.center).filter((c): c is string => Boolean(c)));
    if (isBoss || isMis) for (const c of AGENT_CENTERS) set.add(c);
    const rank = (c: string) => {
      const i = CENTER_ORDER.indexOf(c);
      return i === -1 ? CENTER_ORDER.length : i;
    };
    const list = [...set]
      .filter((c) => !allowedCenters || allowedCenters.has(c))
      .sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
    return ["All", ...list];
  }, [trackingBase, isBoss, isMis, allowedCenters]);

  const filtered = useMemo(
    () =>
      trackingBase.filter(
        (u) =>
          (centerFilter === "All" || u.center === centerFilter) &&
          (statusFilter === "All" || (u.status ?? "Active") === statusFilter),
      ),
    [trackingBase, centerFilter, statusFilter],
  );

  // Group displayed agents by center (center grouping like the web page).
  const sections = useMemo(() => {
    const grouped = new Map<string, User[]>();
    for (const a of filtered) {
      const c = a.center || "—";
      const list = grouped.get(c) ?? [];
      list.push(a);
      grouped.set(c, list);
    }
    const rank = (c: string) => {
      const i = CENTER_ORDER.indexOf(c);
      return i === -1 ? CENTER_ORDER.length : i;
    };
    return [...grouped.keys()]
      .sort((a, b) => rank(a) - rank(b) || a.localeCompare(b))
      .map((center) => ({
        center,
        agents: (grouped.get(center) ?? []).sort((a, b) => a.name.localeCompare(b.name)),
      }));
  }, [filtered]);

  const nameById = useMemo(() => new Map(allUsers.map((u) => [u.id, u.name])), [allUsers]);
  const isAllDates = dateMode === "all";
  const aggMap = useMemo(() => aggregateMetricsByAgent(allMetrics), [allMetrics]);

  // Latest target per agent — carries forward when today has no target of its own.
  const latestTargetByAgent = useMemo(() => {
    const m = new Map<number, number>();
    for (const r of allMetrics) if (r.target != null && !m.has(r.agentId)) m.set(r.agentId, r.target);
    return m;
  }, [allMetrics]);

  const dayByAgent = useMemo(() => {
    const m = new Map<number, AgentMetric>();
    for (const r of dayMetrics) m.set(r.agentId, r);
    return m;
  }, [dayMetrics]);

  // Managers (Center Head + TLs) an agent may report to, scoped to a center.
  const managersInCenter = (center: string | undefined | null): Option[] => {
    if (!center) return [];
    const heads = allUsers
      .filter((u) => u.role === "Center Head" && u.center === center)
      .sort((a, b) => a.name.localeCompare(b.name))
      .map((u) => ({ label: `${u.name} (Center Head)`, value: String(u.id) }));
    const tls = allUsers
      .filter((u) => u.role === "Team Leader" && u.center === center)
      .sort((a, b) => a.name.localeCompare(b.name))
      .map((u) => ({ label: u.name, value: String(u.id) }));
    return [...heads, ...tls];
  };

  // ── Local editable state ────────────────────────────────────────────────
  const [drafts, setDrafts] = useState<Record<number, MetricDraft>>({});
  const [remarkDraft, setRemarkDraft] = useState<Record<number, string>>({});
  const [flash, setFlash] = useState<Record<number, string>>({});
  const [expanded, setExpanded] = useState<Set<number>>(new Set());

  // Seed metric drafts from today's rows whenever the day data / agents change.
  useEffect(() => {
    const next: Record<number, MetricDraft> = {};
    const nextRemark: Record<number, string> = {};
    for (const a of filtered) {
      const m = dayByAgent.get(a.id);
      const carried = latestTargetByAgent.has(a.id) ? String(latestTargetByAgent.get(a.id)) : "";
      next[a.id] = m
        ? {
            dc: m.dc != null ? String(m.dc) : "",
            prospectCount: m.prospectCount != null ? String(m.prospectCount) : "",
            salesFd: m.salesFd != null ? String(m.salesFd) : "",
            salesMtd: m.salesMtd != null ? String(m.salesMtd) : "",
            target: m.target != null ? String(m.target) : carried,
            last3mAvg: m.last3mAvg != null ? String(m.last3mAvg) : "",
            last6mAvg: m.last6mAvg != null ? String(m.last6mAvg) : "",
          }
        : { ...emptyDraft(), target: carried };
      nextRemark[a.id] = m && m.remark != null ? String(m.remark) : "";
    }
    setDrafts(next);
    setRemarkDraft(nextRemark);
  }, [dayByAgent, filtered, latestTargetByAgent]);

  const showFlash = (agentId: number, msg: string) => {
    setFlash((f) => ({ ...f, [agentId]: msg }));
    setTimeout(() => setFlash((f) => ({ ...f, [agentId]: "" })), 1500);
  };

  const setDraftField = (agentId: number, field: MetricField, value: string) => {
    setDrafts((d) => ({ ...d, [agentId]: { ...(d[agentId] ?? emptyDraft()), [field]: value } }));
  };

  const saveMetrics = (agentId: number) => {
    const d = drafts[agentId] ?? emptyDraft();
    upsertMetric.mutate(
      {
        data: {
          agentId,
          date: today,
          dc: toNum(d.dc),
          prospectCount: toNum(d.prospectCount),
          salesFd: toNum(d.salesFd),
          salesMtd: toNum(d.salesMtd),
          target: toNum(d.target),
          last3mAvg: toNum(d.last3mAvg),
          last6mAvg: toNum(d.last6mAvg),
          remark: remarkDraft[agentId]?.trim() || null,
          updatedBy: currentUser?.id ?? null,
        },
      },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListAgentMetricsQueryKey({ date: today }) });
          qc.invalidateQueries({ queryKey: getListAgentMetricsQueryKey({}) });
          showFlash(agentId, "Saved");
        },
        onError: () => showFlash(agentId, "Save failed"),
      },
    );
  };

  const saveTl = (agentId: number, value: string) => {
    updateUser.mutate(
      { id: agentId, data: { reportsTo: value === "" ? null : Number(value) } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListUsersQueryKey() });
          showFlash(agentId, "TL updated");
        },
        onError: () => showFlash(agentId, "Save failed"),
      },
    );
  };

  const saveCenter = (agentId: number, value: string) => {
    if (!value) return;
    updateUser.mutate(
      { id: agentId, data: { center: value } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListUsersQueryKey() });
          showFlash(agentId, "Center updated");
        },
        onError: () => showFlash(agentId, "Save failed"),
      },
    );
  };

  const saveStatus = (agentId: number, value: string) => {
    updateUser.mutate(
      { id: agentId, data: { status: value as "Active" | "Inactive" } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListUsersQueryKey() });
          showFlash(agentId, "Status updated");
        },
        onError: () => showFlash(agentId, "Save failed"),
      },
    );
  };

  const confirmRemove = (id: number, name: string) => {
    const doIt = () =>
      deleteUser.mutate(
        { id },
        {
          onSuccess: () => {
            qc.invalidateQueries({ queryKey: getListUsersQueryKey() });
          },
          onError: () => {
            if (Platform.OS === "web") window.alert("Could not remove agent.");
            else Alert.alert("Could not remove agent.");
          },
        },
      );
    if (Platform.OS === "web") {
      if (window.confirm(`Remove "${name}"?`)) doIt();
    } else {
      Alert.alert("Remove agent", `Remove "${name}"?`, [
        { text: "Cancel", style: "cancel" },
        { text: "Remove", style: "destructive", onPress: doIt },
      ]);
    }
  };

  // ── Add Agent form ──────────────────────────────────────────────────────
  const [showAddAgent, setShowAddAgent] = useState(false);
  const [agentForm, setAgentForm] = useState({
    name: "",
    email: "",
    doj: "",
    center: "Thane Center",
    reportsTo: "",
    status: "Active",
    role: "Sales Agent",
    username: "",
    password: "",
  });
  const [agentError, setAgentError] = useState("");

  const openAddAgent = () => {
    const def = isTl
      ? myCenter && myCenter !== "Head Office"
        ? myCenter
        : "Thane Center"
      : AGENT_CENTERS.includes(centerFilter)
        ? centerFilter
        : myCenter && myCenter !== "Head Office"
          ? myCenter
          : "Thane Center";
    setAgentError("");
    setAgentForm({
      name: "",
      email: "",
      doj: "",
      center: def,
      reportsTo: isTl && currentUser ? String(currentUser.id) : "",
      status: "Active",
      role: "Sales Agent",
      username: "",
      password: "",
    });
    setShowAddAgent((v) => !v);
  };

  const handleAddAgent = () => {
    setAgentError("");
    const isNewTL = agentForm.role === "Team Leader";
    if (!agentForm.name.trim()) {
      setAgentError("Name is required");
      return;
    }
    if (!agentForm.reportsTo) {
      setAgentError(
        isNewTL
          ? "Please select the Center Head this TL reports to"
          : "Please select a TL or Center Head this agent reports to",
      );
      return;
    }
    if (isNewTL && (!agentForm.username.trim() || !agentForm.password.trim())) {
      setAgentError("Username and password are required for a Team Leader");
      return;
    }
    const center = agentForm.center.trim() || "Thane Center";
    createUser.mutate(
      {
        data: {
          name: agentForm.name.trim(),
          role: isNewTL ? "Team Leader" : "Sales Agent",
          username: isNewTL ? agentForm.username.trim() : null,
          password: isNewTL ? agentForm.password : null,
          department: "Sales",
          center,
          reportsTo: Number(agentForm.reportsTo),
          email: agentForm.email.trim() || null,
          doj: agentForm.doj.trim() || null,
          status: agentForm.status as "Active" | "Inactive",
        },
      },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListUsersQueryKey() });
          setShowAddAgent(false);
          setAgentForm((f) => ({ ...f, name: "", email: "", doj: "", reportsTo: "", username: "", password: "" }));
        },
        onError: () =>
          setAgentError(isNewTL ? "Could not add (username may already be taken)" : "Could not add agent"),
      },
    );
  };

  const toggleExpand = (id: number) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // ── Gating: deny path for users who cannot see Agent Tracking ────────────
  if (!canSeeTracking) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <View style={{ paddingTop: 80, flex: 1 }}>
          <EmptyState
            icon="lock"
            title="Restricted"
            message="Agent Tracking is available to managers only (Boss, MIS, Center Heads and Team Leaders)."
          />
        </View>
      </View>
    );
  }

  if (usersQuery.isLoading) return <LoadingState />;

  const addRoleOptions: Option[] = isTl
    ? [{ label: "Sales Agent", value: "Sales Agent" }]
    : [
        { label: "Sales Agent", value: "Sales Agent" },
        { label: "Team Leader", value: "Team Leader" },
      ];
  const addCenterOptions: Option[] = (isTl ? [agentForm.center] : AGENT_CENTERS).map((c) => ({
    label: c,
    value: c,
  }));
  const addManagerOptions = managersInCenter(agentForm.center)
    .filter((m) => (agentForm.role === "Team Leader" ? m.label.includes("(Center Head)") : true))
    .filter((m) => !isTl || hierarchyIds.has(Number(m.value)));

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 24, gap: 12 }}
        refreshControl={
          <RefreshControl
            refreshing={usersQuery.isRefetching}
            onRefresh={() => {
              usersQuery.refetch();
              allMetricsQuery.refetch();
              if (dateMode === "today") dayMetricsQuery.refetch();
            }}
          />
        }
      >
        {/* Toolbar */}
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
          <Text style={{ fontFamily: "Inter_700Bold", fontSize: 15, color: colors.foreground }}>
            📋 Agent Tracking
          </Text>
          <Pressable
            onPress={openAddAgent}
            style={({ pressed }) => [
              styles.addBtn,
              { backgroundColor: colors.primary, borderRadius: colors.radius, opacity: pressed ? 0.85 : 1 },
            ]}
          >
            <Feather name="plus" size={15} color={colors.primaryForeground} />
            <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.primaryForeground }}>
              Add Agent
            </Text>
          </Pressable>
        </View>

        {/* Filters */}
        <View style={{ gap: 8 }}>
          <FieldLabel>DATE</FieldLabel>
          <Segmented
            value={dateMode}
            onChange={(v) => setDateMode(v as "today" | "all")}
            options={[
              { label: "Today", value: "today" },
              { label: "All Time", value: "all" },
            ]}
          />
          <FieldLabel>STATUS</FieldLabel>
          <Segmented
            value={statusFilter}
            onChange={(v) => setStatusFilter(v as "Active" | "Inactive" | "All")}
            options={[
              { label: "Active", value: "Active" },
              { label: "Inactive", value: "Inactive" },
              { label: "All", value: "All" },
            ]}
          />
          {centerOptions.length > 1 ? (
            <>
              <FieldLabel>CENTER</FieldLabel>
              <Segmented
                value={centerFilter}
                onChange={setCenterFilter}
                options={centerOptions.map((c) => ({ label: c === "All" ? "All Centers" : c, value: c }))}
              />
            </>
          ) : null}
        </View>

        {dateMode === "today" ? (
          <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
            Editing {today} · numbers save when you tap Save.
          </Text>
        ) : (
          <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
            All-time roll-up (read only). DC / Prospect / Sales FD are summed; MTD, Target &
            averages show the latest value.
          </Text>
        )}

        {/* Add Agent form */}
        {showAddAgent ? (
          <Card style={{ gap: 10 }}>
            <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.foreground }}>
              {agentForm.role === "Team Leader" ? "New Team Leader" : "New Agent"}
            </Text>
            {agentError ? (
              <Text style={{ fontFamily: "Inter_500Medium", fontSize: 12, color: colors.destructive }}>
                {agentError}
              </Text>
            ) : null}
            <Select
              label="Role"
              value={agentForm.role}
              options={addRoleOptions}
              onChange={(v) => setAgentForm((f) => ({ ...f, role: v, reportsTo: "" }))}
            />
            <TextField
              label="Full Name *"
              value={agentForm.name}
              onChangeText={(t) => setAgentForm((f) => ({ ...f, name: t }))}
              placeholder="Full Name"
            />
            <TextField
              label="Email"
              value={agentForm.email}
              onChangeText={(t) => setAgentForm((f) => ({ ...f, email: t }))}
              placeholder="name@example.com"
              keyboardType="email-address"
            />
            <TextField
              label="Date of Joining (YYYY-MM-DD)"
              value={agentForm.doj}
              onChangeText={(t) => setAgentForm((f) => ({ ...f, doj: t }))}
              placeholder="2024-01-15"
            />
            <Select
              label="Center"
              value={agentForm.center}
              options={addCenterOptions}
              onChange={(v) => setAgentForm((f) => ({ ...f, center: v, reportsTo: "" }))}
            />
            <Select
              label="Reports To *"
              value={agentForm.reportsTo || null}
              options={addManagerOptions}
              onChange={(v) => setAgentForm((f) => ({ ...f, reportsTo: v }))}
              placeholder={agentForm.role === "Team Leader" ? "Select Center Head" : "Select TL / Head"}
            />
            <Select
              label="Status"
              value={agentForm.status}
              options={[
                { label: "Active", value: "Active" },
                { label: "Inactive", value: "Inactive" },
              ]}
              onChange={(v) => setAgentForm((f) => ({ ...f, status: v }))}
            />
            {agentForm.role === "Team Leader" ? (
              <>
                <TextField
                  label="Username *"
                  value={agentForm.username}
                  onChangeText={(t) => setAgentForm((f) => ({ ...f, username: t }))}
                  placeholder="username"
                />
                <TextField
                  label="Password *"
                  value={agentForm.password}
                  onChangeText={(t) => setAgentForm((f) => ({ ...f, password: t }))}
                  placeholder="password"
                />
              </>
            ) : null}
            <View style={{ flexDirection: "row", gap: 10 }}>
              <Button
                label={createUser.isPending ? "Adding..." : "Add"}
                icon="check"
                onPress={handleAddAgent}
                loading={createUser.isPending}
                style={{ flex: 1 }}
              />
              <Button
                label="Cancel"
                variant="secondary"
                onPress={() => setShowAddAgent(false)}
                style={{ flex: 1 }}
              />
            </View>
          </Card>
        ) : null}

        {/* Agent list grouped by center */}
        {filtered.length === 0 ? (
          <View style={{ paddingTop: 60 }}>
            <EmptyState icon="users" title="No agents" message="No agents match this filter." />
          </View>
        ) : (
          sections.map((section) => (
            <View key={section.center} style={{ gap: 10 }}>
              <Text style={[styles.sectionHeader, { color: colors.mutedForeground }]}>
                {section.center.toUpperCase()} · {section.agents.length}
              </Text>
              {section.agents.map((a) => {
                const isOpen = expanded.has(a.id);
                const tlName = a.reportsTo != null ? (nameById.get(a.reportsTo) ?? "—") : "—";
                const status = a.status ?? "Active";
                const agg = aggMap.get(a.id);
                const day = dayByAgent.get(a.id);
                const summaryDc = isAllDates ? agg?.dc : day?.dc;
                const summarySales = isAllDates ? agg?.salesFd : day?.salesFd;
                return (
                  <Card key={a.id} style={{ gap: 10 }}>
                    {/* Header row */}
                    <Pressable
                      onPress={() => toggleExpand(a.id)}
                      style={{ flexDirection: "row", alignItems: "center", gap: 10 }}
                    >
                      <View style={{ flex: 1 }}>
                        <Text
                          style={{ fontFamily: "Inter_600SemiBold", fontSize: 15, color: colors.foreground }}
                          numberOfLines={1}
                        >
                          {a.name}
                        </Text>
                        <Text
                          style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}
                          numberOfLines={1}
                        >
                          TL: {tlName} · {tenureBucket(a.doj)}
                        </Text>
                      </View>
                      <View
                        style={[
                          styles.statusPill,
                          {
                            backgroundColor: (status === "Inactive" ? colors.destructive : colors.success) + "22",
                          },
                        ]}
                      >
                        <Text
                          style={{
                            fontFamily: "Inter_600SemiBold",
                            fontSize: 11,
                            color: status === "Inactive" ? colors.destructive : colors.success,
                          }}
                        >
                          {status}
                        </Text>
                      </View>
                      <Feather
                        name={isOpen ? "chevron-up" : "chevron-down"}
                        size={18}
                        color={colors.mutedForeground}
                      />
                    </Pressable>

                    {/* Summary metrics (collapsed peek) */}
                    <View style={{ flexDirection: "row", gap: 16 }}>
                      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                        DC{" "}
                        <Text style={{ fontFamily: "Inter_700Bold", color: colors.foreground }}>
                          {showVal(summaryDc)}
                        </Text>
                      </Text>
                      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                        Sales FD{" "}
                        <Text style={{ fontFamily: "Inter_700Bold", color: colors.foreground }}>
                          {showVal(summarySales)}
                        </Text>
                      </Text>
                    </View>

                    {isOpen ? (
                      <View style={{ gap: 12, borderTopColor: colors.border, borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 12 }}>
                        {/* TL dropdown */}
                        {canAssignTl ? (
                          <Select
                            label="TL Name"
                            value={a.reportsTo != null ? String(a.reportsTo) : ""}
                            options={[
                              { label: "— Unassigned —", value: "" },
                              ...managersInCenter(a.center),
                            ]}
                            onChange={(v) => saveTl(a.id, v)}
                          />
                        ) : (
                          <View style={{ gap: 6 }}>
                            <FieldLabel>TL Name</FieldLabel>
                            <Text style={{ fontFamily: "Inter_500Medium", fontSize: 15, color: colors.foreground }}>
                              {tlName}
                            </Text>
                          </View>
                        )}

                        {/* Center */}
                        {canAssignCenter ? (
                          <Select
                            label="Center"
                            value={a.center ?? null}
                            options={(isTl && myCenter ? [myCenter] : AGENT_CENTERS).map((c) => ({
                              label: c,
                              value: c,
                            }))}
                            onChange={(v) => saveCenter(a.id, v)}
                          />
                        ) : (
                          <View style={{ gap: 6 }}>
                            <FieldLabel>Center</FieldLabel>
                            <Text style={{ fontFamily: "Inter_500Medium", fontSize: 15, color: colors.foreground }}>
                              {a.center ?? "—"}
                            </Text>
                          </View>
                        )}

                        {/* Status */}
                        <View style={{ gap: 6 }}>
                          <FieldLabel>Status</FieldLabel>
                          <Segmented
                            value={status}
                            onChange={(v) => saveStatus(a.id, v)}
                            options={[
                              { label: "Active", value: "Active" },
                              { label: "Inactive", value: "Inactive" },
                            ]}
                          />
                        </View>

                        {/* Tenure (derived, read-only) */}
                        <View style={{ gap: 6 }}>
                          <FieldLabel>DOJ / Tenure</FieldLabel>
                          <Text style={{ fontFamily: "Inter_500Medium", fontSize: 14, color: colors.foreground }}>
                            {a.doj ?? "—"}
                          </Text>
                          <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                            {tenureLabel(a.doj)} · {tenureBucket(a.doj)}
                          </Text>
                        </View>

                        {/* Metric fields */}
                        {isAllDates ? (
                          <View style={{ gap: 8 }}>
                            {METRIC_FIELDS.map((f) => (
                              <View
                                key={f}
                                style={{ flexDirection: "row", justifyContent: "space-between" }}
                              >
                                <Text
                                  style={{
                                    fontFamily: "Inter_500Medium",
                                    fontSize: 13,
                                    color: colors.mutedForeground,
                                  }}
                                >
                                  {METRIC_LABELS[f]}
                                </Text>
                                <Text
                                  style={{ fontFamily: "Inter_700Bold", fontSize: 13, color: colors.foreground }}
                                >
                                  {showVal(agg?.[f])}
                                </Text>
                              </View>
                            ))}
                            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                              <Text
                                style={{
                                  fontFamily: "Inter_500Medium",
                                  fontSize: 13,
                                  color: colors.mutedForeground,
                                }}
                              >
                                Remark
                              </Text>
                              <Text
                                style={{ fontFamily: "Inter_500Medium", fontSize: 13, color: colors.foreground }}
                              >
                                {showVal(agg?.remark)}
                              </Text>
                            </View>
                          </View>
                        ) : (
                          <View style={{ gap: 10 }}>
                            {METRIC_FIELDS.map((f) => (
                              <TextField
                                key={f}
                                label={METRIC_LABELS[f]}
                                value={drafts[a.id]?.[f] ?? ""}
                                onChangeText={(t) => setDraftField(a.id, f, t)}
                                placeholder="0"
                                keyboardType="numeric"
                              />
                            ))}
                            <TextField
                              label="Remark"
                              value={remarkDraft[a.id] ?? ""}
                              onChangeText={(t) => setRemarkDraft((r) => ({ ...r, [a.id]: t }))}
                              placeholder="—"
                            />
                            <Button
                              label="Save metrics"
                              icon="save"
                              onPress={() => saveMetrics(a.id)}
                              loading={upsertMetric.isPending}
                            />
                          </View>
                        )}

                        {/* Actions */}
                        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                          {flash[a.id] ? (
                            <Text
                              style={{
                                fontFamily: "Inter_500Medium",
                                fontSize: 12,
                                color: flash[a.id]?.includes("fail") ? colors.destructive : colors.success,
                              }}
                            >
                              {flash[a.id]}
                            </Text>
                          ) : (
                            <View />
                          )}
                          <Pressable
                            onPress={() => confirmRemove(a.id, a.name)}
                            style={({ pressed }) => [
                              styles.removeBtn,
                              { borderColor: colors.destructive, opacity: pressed ? 0.6 : 1 },
                            ]}
                          >
                            <Feather name="x" size={14} color={colors.destructive} />
                            <Text
                              style={{ fontFamily: "Inter_600SemiBold", fontSize: 12, color: colors.destructive }}
                            >
                              Remove
                            </Text>
                          </Pressable>
                        </View>
                      </View>
                    ) : null}
                  </Card>
                );
              })}
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  sectionHeader: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.6, marginTop: 4 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 12, paddingVertical: 8 },
  statusPill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  removeBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
});
