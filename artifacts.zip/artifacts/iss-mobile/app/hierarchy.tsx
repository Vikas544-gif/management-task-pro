import type { User, UserCredential } from "@workspace/api-client-react";
import {
  getListCredentialsQueryKey,
  getListTasksQueryKey,
  getListUsersQueryKey,
  useCreateUser,
  useDeleteUser,
  useListCredentials,
  useListUsers,
  useUpdateUser,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  Button,
  Card,
  EmptyState,
  FieldLabel,
  LoadingState,
  Select,
  Segmented,
  TextField,
  type Option,
} from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { isAllCentersViewer } from "@/lib/permissions";

const DEPTS = [
  "Management",
  "Operations",
  "Quality & Training",
  "Quality",
  "Training",
  "Accounts",
  "MIS",
  "Director",
  "HR",
  "IT",
];
const CENTER_ORDER = ["Head Office", "Thane Center", "Malad Center", "Pune Center", "Navi Mumbai Center"];

/** Mirrors the web app's resolveAllowedCenters (restriction-only, Boss/MIS). */
function resolveAllowedCenters(
  viewer: User | null | undefined,
  allUsers: { center?: string | null }[],
): Set<string> | null {
  if (!viewer) return null;
  const perms = viewer.centerPermissions;
  if (perms == null) return null;
  const isBoss = viewer.department === "Management" || viewer.role === "Boss";
  const isAll = isAllCentersViewer(viewer);
  if (!isBoss && !isAll) return null;
  const ceiling = new Set(allUsers.map((u) => u.center).filter((c): c is string => Boolean(c)));
  if (isAll && !isBoss) ceiling.delete("Head Office");
  return new Set([...ceiling].filter((c) => perms.includes(c)));
}

export default function HierarchyScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const { user: currentUser } = useAuth();

  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey() } });
  const users = usersQuery.data ?? [];

  const isBoss = currentUser?.department === "Management" || currentUser?.role === "Boss";
  const isMis = isAllCentersViewer(currentUser);
  const isCenterHead = currentUser?.role === "Center Head";
  const seesAll = isBoss || isMis;
  const canView = isBoss || isMis || isCenterHead;
  const myCenter = users.find((u) => u.id === currentUser?.id)?.center ?? null;

  const credParams = isBoss
    ? undefined
    : isMis
      ? { excludeCenter: "Head Office" }
      : myCenter
        ? { center: myCenter }
        : undefined;
  const { data: credentials = [] } = useListCredentials(credParams, {
    query: { enabled: canView && (seesAll || !!myCenter), queryKey: getListCredentialsQueryKey(credParams) },
  });
  const passwordMap = useMemo(
    () => new Map(credentials.map((c: UserCredential) => [c.id, c.password])),
    [credentials],
  );

  const createUser = useCreateUser();
  const updateUser = useUpdateUser();
  const deleteUser = useDeleteUser();

  const [showPasswords, setShowPasswords] = useState(false);
  const [centerFilter, setCenterFilter] = useState("All");
  const [flash, setFlash] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [editUser, setEditUser] = useState<User | null>(null);

  const allowedCenters = resolveAllowedCenters(
    users.find((u) => u.id === currentUser?.id) ?? null,
    users,
  );

  let baseUsers = isBoss
    ? users
    : isMis
      ? users.filter((u) => u.center && u.center !== "Head Office")
      : users.filter((u) => u.center === myCenter);
  if (allowedCenters) baseUsers = baseUsers.filter((u) => u.center && allowedCenters.has(u.center));

  const centerChoices = (isMis ? CENTER_ORDER.filter((c) => c !== "Head Office") : CENTER_ORDER).filter(
    (c) => !allowedCenters || allowedCenters.has(c),
  );
  const centers = useMemo(() => {
    const set = new Set(baseUsers.map((u) => u.center).filter((c): c is string => Boolean(c)));
    const rank = (c: string) => {
      const i = CENTER_ORDER.indexOf(c);
      return i === -1 ? CENTER_ORDER.length : i;
    };
    return Array.from(set).sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseUsers.map((u) => u.center).join("|")]);
  const allCenterOptions = useMemo(() => {
    const set = new Set<string>([
      ...centerChoices,
      ...baseUsers.map((u) => u.center).filter((c): c is string => Boolean(c)),
    ]);
    const rank = (c: string) => {
      const i = CENTER_ORDER.indexOf(c);
      return i === -1 ? CENTER_ORDER.length : i;
    };
    return Array.from(set).sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [centerChoices.join("|"), baseUsers.map((u) => u.center).join("|")]);

  const activeCenter = centerFilter !== "All" && centers.includes(centerFilter) ? centerFilter : "All";

  const hideHrFromCenterHead = isCenterHead && !seesAll;
  const loginUsers = baseUsers.filter(
    (u) => !!u.username && !(hideHrFromCenterHead && u.department === "HR"),
  );
  const visibleUsers = activeCenter === "All" ? loginUsers : loginUsers.filter((u) => u.center === activeCenter);

  const managerOptions = (excludeId?: number): Option[] => [
    { value: "", label: "— Top of hierarchy (Boss) —" },
    ...baseUsers
      .filter((u) => u.role !== "Sales Agent" && u.id !== excludeId)
      .map((u) => ({ value: String(u.id), label: `${u.name} (${u.role})` })),
  ];

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: getListUsersQueryKey() });
    qc.invalidateQueries({ queryKey: getListTasksQueryKey() });
    qc.invalidateQueries({ queryKey: getListCredentialsQueryKey() });
  };

  const showFlash = (msg: string) => {
    setFlash(msg);
    setTimeout(() => setFlash(""), 2500);
  };

  const notify = (msg: string) => {
    if (Platform.OS === "web") window.alert(msg);
    else Alert.alert(msg);
  };

  const handleDelete = (id: number, name: string) => {
    const run = () =>
      deleteUser.mutate(
        { id },
        {
          onSuccess: () => {
            invalidate();
            showFlash("✓ User deleted");
            setEditUser(null);
          },
        },
      );
    if (Platform.OS === "web") {
      if (window.confirm(`Delete "${name}"?`)) run();
    } else {
      Alert.alert("Delete user", `Delete "${name}"?`, [
        { text: "Cancel", style: "cancel" },
        { text: "Delete", style: "destructive", onPress: run },
      ]);
    }
  };

  if (!currentUser) return <LoadingState />;

  if (!canView) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <View style={{ paddingTop: 80, flex: 1 }}>
          <EmptyState
            icon="lock"
            title="Restricted"
            message="Only Boss, MIS or Center Heads can view this page"
          />
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 24, gap: 12 }}>
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>
          {seesAll
            ? "All user login credentials, and who reports to whom"
            : `Login credentials for your center${myCenter ? ` — ${myCenter}` : ""}`}
        </Text>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <Button
            label={showPasswords ? "Hide Passwords" : "Show Passwords"}
            icon={showPasswords ? "eye-off" : "eye"}
            variant="secondary"
            onPress={() => setShowPasswords((v) => !v)}
            style={{ flex: 1 }}
          />
          <Button
            label="Add User"
            icon="user-plus"
            onPress={() => setShowAdd(true)}
            style={{ flex: 1 }}
          />
        </View>

        {flash ? (
          <View style={[styles.flash, { backgroundColor: colors.success + "22", borderColor: colors.success }]}>
            <Text style={{ fontFamily: "Inter_500Medium", fontSize: 13, color: colors.success }}>{flash}</Text>
          </View>
        ) : null}

        {seesAll && centers.length > 1 ? (
          <View style={{ gap: 8 }}>
            <FieldLabel>FILTER BY CENTER</FieldLabel>
            <Segmented
              options={[{ value: "All", label: "All Centers" }, ...centers.map((c) => ({ value: c, label: c }))]}
              value={activeCenter}
              onChange={setCenterFilter}
            />
          </View>
        ) : null}

        {usersQuery.isLoading ? (
          <LoadingState />
        ) : visibleUsers.length === 0 ? (
          <View style={{ paddingTop: 40 }}>
            <EmptyState icon="key" title="No credentials" message="Users with a login will appear here." />
          </View>
        ) : (
          visibleUsers.map((u) => (
            <Card key={u.id} style={{ gap: 8 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{ fontFamily: "Inter_700Bold", fontSize: 16, color: colors.foreground }}
                    numberOfLines={1}
                  >
                    {u.name}
                  </Text>
                  <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                    {u.role}
                    {u.department ? ` · ${u.department}` : ""}
                  </Text>
                </View>
                <Pressable
                  onPress={() => setEditUser(u)}
                  hitSlop={8}
                  style={{ padding: 6 }}
                >
                  <Feather name="edit-2" size={18} color={colors.primary} />
                </Pressable>
              </View>

              <View style={styles.kv}>
                <Text style={[styles.k, { color: colors.mutedForeground }]}>Username</Text>
                <Text style={[styles.v, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
                  {u.username ?? "—"}
                </Text>
              </View>
              <View style={styles.kv}>
                <Text style={[styles.k, { color: colors.mutedForeground }]}>Password</Text>
                <Text style={[styles.v, { color: colors.foreground }]}>
                  {showPasswords ? passwordMap.get(u.id) ?? "—" : "••••••••"}
                </Text>
              </View>
              <View style={styles.kv}>
                <Text style={[styles.k, { color: colors.mutedForeground }]}>Center</Text>
                <Text style={[styles.v, { color: colors.foreground }]}>{u.center ?? "—"}</Text>
              </View>
              <View style={styles.kv}>
                <Text style={[styles.k, { color: colors.mutedForeground }]}>Reports To</Text>
                <Text style={[styles.v, { color: colors.foreground }]}>
                  {u.reportsTo == null ? "Top of hierarchy" : u.reportsToName ?? String(u.reportsTo)}
                </Text>
              </View>
              <View style={styles.kv}>
                <Text style={[styles.k, { color: colors.mutedForeground }]}>Email</Text>
                <Text style={[styles.v, { color: colors.foreground }]} numberOfLines={1}>
                  {u.email ?? "—"}
                </Text>
              </View>
            </Card>
          ))
        )}

        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
          💡 Tap the edit icon to change a user's details, reset their password, or remove them.
        </Text>
      </ScrollView>

      {editUser ? (
        <EditUserModal
          key={editUser.id}
          user={editUser}
          seesAll={seesAll}
          isBoss={isBoss}
          isMis={isMis}
          isSelf={editUser.id === currentUser.id}
          deptOptions={DEPTS.map((d) => ({ value: d, label: d }))}
          centerOptions={(isBoss ? allCenterOptions : centerChoices).map((c) => ({ value: c, label: c }))}
          managerOptions={managerOptions(editUser.id)}
          saving={updateUser.isPending}
          onClose={() => setEditUser(null)}
          onDelete={() => handleDelete(editUser.id, editUser.name)}
          onSave={(data, revert) => {
            if (data.center && isMis && data.center === "Head Office") {
              showFlash("✗ MIS cannot assign Head Office");
              return;
            }
            updateUser.mutate(
              { id: editUser.id, data },
              {
                onSuccess: () => {
                  invalidate();
                  showFlash("✓ Saved");
                  setEditUser(null);
                },
                onError: () => {
                  revert?.();
                  showFlash("✗ Save failed (username may be taken)");
                },
              },
            );
          }}
        />
      ) : null}

      {showAdd ? (
        <AddUserModal
          seesAll={seesAll}
          isBoss={isBoss}
          isMis={isMis}
          myCenter={myCenter}
          deptOptions={DEPTS.map((d) => ({ value: d, label: d }))}
          centerOptions={allCenterOptions.map((c) => ({ value: c, label: c }))}
          managerOptions={managerOptions()}
          saving={createUser.isPending}
          onClose={() => setShowAdd(false)}
          onSave={(form) => {
            createUser.mutate(
              {
                data: {
                  name: form.name,
                  role: form.role,
                  username: form.username,
                  password: form.password,
                  department: form.department,
                  center: isBoss
                    ? form.center.trim() || "Head Office"
                    : isMis
                      ? form.center.trim() && form.center.trim() !== "Head Office"
                        ? form.center.trim()
                        : "Thane Center"
                      : myCenter ?? "Head Office",
                  reportsTo: form.reportsTo === "" ? null : parseInt(form.reportsTo, 10),
                  email: form.email || null,
                },
              },
              {
                onSuccess: () => {
                  invalidate();
                  showFlash("✓ New user added");
                  setShowAdd(false);
                },
                onError: () => notify("Failed to add user (username must be unique)"),
              },
            );
          }}
        />
      ) : null}
    </View>
  );
}

function ModalShell({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View
          style={[
            styles.sheet,
            { backgroundColor: colors.background, borderColor: colors.border, paddingBottom: insets.bottom + 16 },
          ]}
        >
          <View style={[styles.sheetHeader, { borderBottomColor: colors.border }]}>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 18, color: colors.foreground, flex: 1 }}>
              {title}
            </Text>
            <Pressable onPress={onClose} hitSlop={8} style={{ padding: 4 }}>
              <Feather name="x" size={22} color={colors.mutedForeground} />
            </Pressable>
          </View>
          <ScrollView
            contentContainerStyle={{ padding: 16, gap: 14 }}
            keyboardShouldPersistTaps="handled"
          >
            {children}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

function EditUserModal({
  user,
  seesAll,
  isBoss,
  isMis,
  isSelf,
  deptOptions,
  centerOptions,
  managerOptions,
  saving,
  onClose,
  onSave,
  onDelete,
}: {
  user: User;
  seesAll: boolean;
  isBoss: boolean;
  isMis: boolean;
  isSelf: boolean;
  deptOptions: Option[];
  centerOptions: Option[];
  managerOptions: Option[];
  saving: boolean;
  onClose: () => void;
  onSave: (data: Record<string, unknown>, revert?: () => void) => void;
  onDelete: () => void;
}) {
  const colors = useColors();
  const [name, setName] = useState(user.name);
  const [role, setRole] = useState(user.role);
  const [username, setUsername] = useState(user.username ?? "");
  const [email, setEmail] = useState(user.email ?? "");
  const [department, setDepartment] = useState(user.department);
  const [center, setCenter] = useState<string | null>(user.center ?? null);
  const [reportsTo, setReportsTo] = useState<string>(user.reportsTo == null ? "" : String(user.reportsTo));
  const [newPw, setNewPw] = useState("");

  const canEditCenter = isBoss || isMis;

  const handleSave = () => {
    const data: Record<string, unknown> = {};
    if (name.trim() && name.trim() !== user.name) data.name = name.trim();
    if (seesAll && role.trim() && role.trim() !== user.role) data.role = role.trim();
    if (username.trim() && username.trim() !== (user.username ?? "")) data.username = username.trim();
    if ((email || "") !== (user.email ?? "")) data.email = email.trim() === "" ? null : email.trim();
    if (seesAll && department !== user.department) data.department = department;
    if (canEditCenter && center && center !== (user.center ?? "")) data.center = center;
    const nextReports = reportsTo === "" ? null : parseInt(reportsTo, 10);
    if (nextReports !== (user.reportsTo ?? null)) data.reportsTo = nextReports;
    if (newPw.trim()) data.password = newPw.trim();
    if (Object.keys(data).length === 0) {
      onClose();
      return;
    }
    onSave(data);
  };

  return (
    <ModalShell title="Edit User" onClose={onClose}>
      <TextField label="Full Name" value={name} onChangeText={setName} placeholder="Full name" />
      {seesAll ? (
        <TextField label="Role" value={role} onChangeText={setRole} placeholder="Role" />
      ) : (
        <ReadOnlyRow label="Role" value={user.role} />
      )}
      <TextField label="Username" value={username} onChangeText={setUsername} placeholder="username" />
      <TextField
        label="Email (for auto reminders)"
        value={email}
        onChangeText={setEmail}
        placeholder="name@company.com"
        keyboardType="email-address"
      />
      {seesAll ? (
        <Select label="Department" value={department} options={deptOptions} onChange={setDepartment} />
      ) : (
        <ReadOnlyRow label="Department" value={user.department} />
      )}
      {canEditCenter ? (
        <Select label="Center" value={center} options={centerOptions} onChange={setCenter} />
      ) : (
        <ReadOnlyRow label="Center" value={user.center ?? "—"} />
      )}
      <Select
        label="Reports To (Manager)"
        value={reportsTo}
        options={managerOptions}
        onChange={setReportsTo}
        placeholder="— Top of hierarchy —"
      />
      <TextField
        label="Reset Password (leave blank to keep)"
        value={newPw}
        onChangeText={setNewPw}
        placeholder="New password"
      />

      <Button label="Save Changes" icon="check" onPress={handleSave} loading={saving} />
      {!isSelf ? (
        <Button label="Delete User" icon="trash-2" variant="destructive" onPress={onDelete} />
      ) : null}
    </ModalShell>
  );
}

function AddUserModal({
  seesAll,
  isBoss,
  isMis,
  myCenter,
  deptOptions,
  centerOptions,
  managerOptions,
  saving,
  onClose,
  onSave,
}: {
  seesAll: boolean;
  isBoss: boolean;
  isMis: boolean;
  myCenter: string | null;
  deptOptions: Option[];
  centerOptions: Option[];
  managerOptions: Option[];
  saving: boolean;
  onClose: () => void;
  onSave: (form: {
    name: string;
    role: string;
    username: string;
    password: string;
    department: string;
    center: string;
    email: string;
    reportsTo: string;
  }) => void;
}) {
  const colors = useColors();
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [department, setDepartment] = useState("Accounts");
  const [center, setCenter] = useState<string | null>(isMis ? "Thane Center" : "Head Office");
  const [reportsTo, setReportsTo] = useState("");
  const [error, setError] = useState("");

  const submit = () => {
    if (!name || !username || !password || !role) {
      setError("Name, Role, Username, Password are required");
      return;
    }
    setError("");
    onSave({ name, role, username, password, department, center: center ?? "", email, reportsTo });
  };

  return (
    <ModalShell title="New User" onClose={onClose}>
      {error ? (
        <Text style={{ fontFamily: "Inter_500Medium", fontSize: 13, color: colors.destructive }}>{error}</Text>
      ) : null}
      <TextField label="Full Name *" value={name} onChangeText={setName} placeholder="Full name" />
      <TextField label="Role *" value={role} onChangeText={setRole} placeholder="e.g. Asst Manager" />
      <TextField label="Username *" value={username} onChangeText={setUsername} placeholder="username" />
      <TextField label="Password *" value={password} onChangeText={setPassword} placeholder="Password" />
      <TextField
        label="Email (auto reminders)"
        value={email}
        onChangeText={setEmail}
        placeholder="name@company.com"
        keyboardType="email-address"
      />
      <Select label="Department" value={department} options={deptOptions} onChange={setDepartment} />
      {seesAll ? (
        <Select label="Center" value={center} options={centerOptions} onChange={setCenter} />
      ) : (
        <ReadOnlyRow label="Center" value={myCenter ?? "Head Office"} />
      )}
      <Select
        label="Reports To (Manager)"
        value={reportsTo}
        options={managerOptions}
        onChange={setReportsTo}
        placeholder="— Top of hierarchy (Boss) —"
      />
      <Button label="Add User" icon="user-plus" onPress={submit} loading={saving} />
    </ModalShell>
  );
}

function ReadOnlyRow({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={{ gap: 6 }}>
      <FieldLabel>{label}</FieldLabel>
      <Text style={{ fontFamily: "Inter_500Medium", fontSize: 15, color: colors.foreground }}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  flash: { borderWidth: StyleSheet.hairlineWidth, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10 },
  kv: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  k: { fontFamily: "Inter_500Medium", fontSize: 13 },
  v: { fontFamily: "Inter_500Medium", fontSize: 13, flexShrink: 1, textAlign: "right" },
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" },
  sheet: { borderTopLeftRadius: 20, borderTopRightRadius: 20, borderWidth: StyleSheet.hairlineWidth, maxHeight: "92%" },
  sheetHeader: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});
