import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { setBaseUrl } from "@workspace/api-client-react";
import * as Notifications from "expo-notifications";
import { Stack, useRouter, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import React, { useEffect } from "react";
import { ActivityIndicator, View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { ThemeProvider, useTheme } from "@/context/ThemeContext";

// Expo bundles run outside the web proxy, so the API client needs an absolute
// base URL to reach the API server. Registered once at module load.
setBaseUrl(`https://${process.env.EXPO_PUBLIC_DOMAIN}`);

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function RootLayoutNav() {
  const { user, loading } = useAuth();
  const { colors, isDark } = useTheme();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    const inAuthGroup = segments[0] === "login";
    if (!user && !inAuthGroup) {
      router.replace("/login");
    } else if (user && inAuthGroup) {
      router.replace("/");
    }
  }, [user, loading, segments, router]);

  // Instagram-style deep link: tapping a push notification opens the task it
  // is about (payload carries data.taskId from the server).
  const coldStartHandledFor = React.useRef<number | null>(null);
  const lastHandledNotifId = React.useRef<string | null>(null);
  useEffect(() => {
    const goToTask = (resp: Notifications.NotificationResponse | null) => {
      if (!resp) return;
      // The cold-start "last response" can be the same tap the listener
      // already handled — dedupe by the notification identifier.
      const notifId = resp.notification.request.identifier;
      if (notifId && lastHandledNotifId.current === notifId) return;
      const raw = resp.notification.request.content.data?.taskId;
      const taskId = Number(raw);
      if (raw != null && Number.isFinite(taskId) && taskId > 0) {
        lastHandledNotifId.current = notifId ?? null;
        router.push(`/task/${taskId}`);
      }
    };
    // App in background/foreground → listener fires on tap.
    const sub = Notifications.addNotificationResponseReceivedListener(goToTask);
    // App fully closed → the tap that launched it is the "last response".
    // Re-armed per user id so account switches still deep-link correctly.
    if (user && coldStartHandledFor.current !== user.id) {
      coldStartHandledFor.current = user.id;
      Notifications.getLastNotificationResponseAsync()
        .then(goToTask)
        .catch(() => {});
    }
    return () => sub.remove();
  }, [user, router]);

  if (loading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background }}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <>
      <StatusBar style={isDark ? "light" : "dark"} />
      <Stack screenOptions={{ headerBackTitle: "Back" }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="login" options={{ headerShown: false }} />
      <Stack.Screen name="task/[id]" options={{ title: "Task Details" }} />
      <Stack.Screen name="assign-task" options={{ title: "Assign Task" }} />
      <Stack.Screen name="team" options={{ title: "Team" }} />
      <Stack.Screen name="attendance" options={{ title: "Attendance" }} />
      <Stack.Screen name="eod" options={{ title: "EOD Report" }} />
      <Stack.Screen name="reports" options={{ title: "Reports" }} />
      </Stack>
    </>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView>
            <KeyboardProvider>
              <ThemeProvider>
                <AuthProvider>
                  <RootLayoutNav />
                </AuthProvider>
              </ThemeProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
