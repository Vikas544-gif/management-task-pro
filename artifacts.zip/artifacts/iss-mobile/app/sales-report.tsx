import type { AgentMetric, User } from "@workspace/api-client-react";
import {
  getListAgentMetricsQueryKey,
  getListUsersQueryKey,
  useListAgentMetrics,
  useListUsers,
} from "@workspace/api-client-react";
import React, { useMemo, useState } from "react";
import { Dimensions, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BarChart } from "@/components/charts";
import { Card, EmptyState, ErrorState, LoadingState, Segmented, type Option } from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { isAllCentersViewer, roleFlags } from "@/lib/permissions";

const CENTER_ORDER = ["Head Office", "Thane Center", "Malad Center", "Pune Center", "Navi Mumbai Center"];

// Data-series colors (mirror the web report). Intentionally fixed hues, not theme tokens.
const SERIES = {
  mtd: "#10b981",
  target: "#6366f1",
  dc: "#3b82f6",
  prospect: "#f59e0b",
  salesFd: "#14b8a6",
};

const PERIODS: Option[] = [
  { value: "month", label: "This Month" },
  { value: "30", label: "Last 30 Days" },
  { value: "all", label: "All Time" },
];

const toISO = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const todayISO = () => toISO(new Date());
const monthStartISO = () => {
  const d = new Date();
  return toISO(new Date(d.getFullYear(), d.getMonth(), 1));
};

const fmt = (n: number) => n.toLocaleString("en-IN");
const firstName = (name: string) => name.split(" ")[0];
const achColor = (pct: number) => (pct >= 100 ? "#10b981" : pct >= 50 ? "#f59e0b" : "#ef4444");

// Recursive org-chart subtree under rootId (mirror of the web's buildHierarchySet).
function buildHierarchySet(rootId: number, allUsers: { id: number; reportsTo?: number | null }[]): Set<number> {
  const result = new Set<number>([rootId]);
  const queue = [rootId];
  while (queue.length > 0) {
    const parentId = queue.shift()!;
    for (const u of allUsers) {
      if (u.reportsTo === parentId && !result.has(u.id)) {
        result.add(u.id);
        queue.push(u.id);
      }
    }
  }
  return result;
}

// Roll every metric row up per agent: DC / Prospect / Sales FD are daily activity
// counts (SUM across the window); Sales MTD / Target are point-in-time (latest non-null;
// rows arrive newest-first).
function aggregateByAgent(rows: AgentMetric[]) {
  const sums = new Map<number, { dc: number; prospectCount: number; salesFd: number }>();
  const latest = new Map<number, Record<string, number | null>>();
  const POINT = ["salesMtd", "target", "last3mAvg", "last6mAvg"] as const;
  for (const m of rows) {
    const s = sums.get(m.agentId) ?? { dc: 0, prospectCount: 0, salesFd: 0 };
    s.dc += Number(m.dc) || 0;
    s.prospectCount += Number(m.prospectCount) || 0;
    s.salesFd += Number(m.salesFd) || 0;
    sums.set(m.agentId, s);
    const p = latest.get(m.agentId) ?? {};
    for (const f of POINT) if (p[f] == null && m[f] != null) p[f] = m[f] as number;
    latest.set(m.agentId, p);
  }
  const out = new Map<number, {
    agentId: number;
    dc: number;
    prospectCount: number;
    salesFd: number;
    salesMtd: number | null;
    target: number | null;
  }>();
  for (const [id, s] of sums) {
    const p = latest.get(id) ?? {};
    out.set(id, {
      agentId: id,
      dc: s.dc,
      prospectCount: s.prospectCount,
      salesFd: s.salesFd,
      salesMtd: p.salesMtd ?? null,
      target: p.target ?? null,
    });
  }
  return out;
}

function KpiCard({ label, value, sub, accent }: { label: string; value: string; sub?: string; accent: string }) {
  const colors = useColors();
  return (
    <Card style={styles.kpiCard}>
      <Text style={[styles.kpiLabel, { color: colors.mutedForeground }]}>{label.toUpperCase()}</Text>
      <Text style={[styles.kpiValue, { color: accent }]}>{value}</Text>
      {sub ? <Text style={[styles.kpiSub, { color: colors.mutedForeground }]}>{sub}</Text> : null}
    </Card>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  const colors = useColors();
  return <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>{children}</Text>;
}

function ProgressBar({ frac, color }: { frac: number; color: string }) {
  const colors = useColors();
  const pct = Math.max(0, Math.min(1, frac));
  return (
    <View style={[styles.track, { backgroundColor: colors.border }]}>
      <View style={{ width: `${pct * 100}%`, height: "100%", backgroundColor: color, borderRadius: 999 }} />
    </View>
  );
}

interface AgentRow {
  id: number;
  name: string;
  short: string;
  center: string;
  dc: number;
  prospectCount: number;
  salesFd: number;
  salesMtd: number;
  target: number;
  achievement: number;
}

export default function SalesReportScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [period, setPeriod] = useState("month");
  const [centerFilter, setCenterFilter] = useState<string>("All");
  const [tlFilter, setTlFilter] = useState<string>("All");

  const { isBoss: rBoss, isCenterHead: rCenterHead, isMis: rMis, isTl: rTl } = roleFlags(user);
  const canView = rBoss || rMis || rCenterHead || rTl;

  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey(), enabled: canView } });
  const metricsQuery = useListAgentMetrics(
    {},
    { query: { queryKey: getListAgentMetricsQueryKey({}), enabled: canView } },
  );

  const { from, to } = useMemo(() => {
    const today = todayISO();
    if (period === "all") return { from: "", to: today };
    if (period === "30") {
      const d = new Date();
      d.setDate(d.getDate() - 29);
      return { from: toISO(d), to: today };
    }
    return { from: monthStartISO(), to: today };
  }, [period]);

  const isBoss = user?.department === "Management" || user?.role === "Boss";
  const isMis = isAllCentersViewer(user);
  const seesAllCenters = isBoss || isMis;

  const allUsers = useMemo(() => usersQuery.data ?? [], [usersQuery.data]);
  const allMetrics = useMemo(() => metricsQuery.data ?? [], [metricsQuery.data]);

  // Which Sales Agents this viewer may see.
  const scopedAgents = useMemo(() => {
    const salesAgents = allUsers.filter((u: User) => u.role === "Sales Agent");
    if (seesAllCenters) return salesAgents;
    if (!user) return [];
    const subtree = buildHierarchySet(user.id, allUsers as User[]);
    return salesAgents.filter((u: User) => subtree.has(u.id));
  }, [allUsers, seesAllCenters, user]);

  const centers = useMemo(() => {
    const set = new Set<string>();
    for (const a of scopedAgents) if (a.center) set.add(a.center);
    return [...set].sort((x, y) => {
      const ix = CENTER_ORDER.indexOf(x);
      const iy = CENTER_ORDER.indexOf(y);
      return (ix === -1 ? 99 : ix) - (iy === -1 ? 99 : iy);
    });
  }, [scopedAgents]);

  // Agents after the center filter (before the Team Leader filter).
  const centerAgents = useMemo(
    () => scopedAgents.filter((a: User) => centerFilter === "All" || a.center === centerFilter),
    [scopedAgents, centerFilter],
  );

  // Team Leaders available as filter options — only those whose org-chart subtree
  // contains at least one of the center-filtered agents.
  const teamLeaders = useMemo(() => {
    return (allUsers as User[])
      .filter((u) => u.role === "Team Leader")
      .filter((tl) => {
        const set = buildHierarchySet(tl.id, allUsers as User[]);
        return centerAgents.some((a: User) => set.has(a.id));
      })
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [allUsers, centerAgents]);

  // Agents after the TL filter (an agent belongs to a TL when it sits inside that
  // TL's org-chart subtree).
  const displayAgents = useMemo(() => {
    if (tlFilter === "All") return centerAgents;
    const set = buildHierarchySet(Number(tlFilter), allUsers as User[]);
    return centerAgents.filter((a: User) => set.has(a.id));
  }, [centerAgents, tlFilter, allUsers]);
  const displayAgentIds = useMemo(() => new Set(displayAgents.map((a: User) => a.id)), [displayAgents]);

  const windowMetrics = useMemo(
    () =>
      allMetrics.filter(
        (m: AgentMetric) => displayAgentIds.has(m.agentId) && (!from || m.date >= from) && (!to || m.date <= to),
      ),
    [allMetrics, displayAgentIds, from, to],
  );

  const aggMap = useMemo(() => aggregateByAgent(windowMetrics), [windowMetrics]);

  const agentRows = useMemo(() => {
    const rows: AgentRow[] = [];
    for (const a of displayAgents) {
      const m = aggMap.get(a.id);
      if (!m) continue;
      const mtd = Number(m.salesMtd) || 0;
      const target = Number(m.target) || 0;
      rows.push({
        id: a.id,
        name: a.name,
        short: firstName(a.name),
        center: a.center ?? "—",
        dc: Number(m.dc) || 0,
        prospectCount: Number(m.prospectCount) || 0,
        salesFd: Number(m.salesFd) || 0,
        salesMtd: mtd,
        target,
        achievement: target > 0 ? Math.round((mtd / target) * 100) : 0,
      });
    }
    return rows;
  }, [displayAgents, aggMap]);

  const totals = useMemo(() => {
    const t = { dc: 0, prospectCount: 0, salesFd: 0, salesMtd: 0, target: 0 };
    for (const r of agentRows) {
      t.dc += r.dc;
      t.prospectCount += r.prospectCount;
      t.salesFd += r.salesFd;
      t.salesMtd += r.salesMtd;
      t.target += r.target;
    }
    return t;
  }, [agentRows]);
  const overallAch = totals.target > 0 ? Math.round((totals.salesMtd / totals.target) * 100) : 0;

  const topByMtd = useMemo(() => [...agentRows].sort((a, b) => b.salesMtd - a.salesMtd).slice(0, 12), [agentRows]);
  const topByActivity = useMemo(
    () =>
      [...agentRows]
        .sort((a, b) => b.dc + b.prospectCount + b.salesFd - (a.dc + a.prospectCount + a.salesFd))
        .slice(0, 12),
    [agentRows],
  );
  const achRanked = useMemo(
    () => agentRows.filter((r) => r.target > 0).sort((a, b) => b.achievement - a.achievement).slice(0, 12),
    [agentRows],
  );

  const byCenter = useMemo(() => {
    const m = new Map<string, { center: string; name: string; salesMtd: number; target: number }>();
    for (const r of agentRows) {
      const e = m.get(r.center) ?? { center: r.center, name: r.center.replace(/ Center$/, ""), salesMtd: 0, target: 0 };
      e.salesMtd += r.salesMtd;
      e.target += r.target;
      m.set(r.center, e);
    }
    return [...m.values()];
  }, [agentRows]);

  const trend = useMemo(() => {
    const m = new Map<string, number>();
    for (const row of windowMetrics) {
      m.set(row.date, (m.get(row.date) || 0) + (Number(row.salesFd) || 0));
    }
    return [...m.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, salesFd]) => ({ label: date.slice(5), value: salesFd }));
  }, [windowMetrics]);

  if (!canView) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <EmptyState
          icon="lock"
          title="Restricted"
          message="This report is for the Boss, MIS, Center Heads, and Team Leaders only."
        />
      </View>
    );
  }
  if (usersQuery.isLoading || metricsQuery.isLoading) return <LoadingState />;
  if (usersQuery.isError || metricsQuery.isError) {
    return (
      <ErrorState
        onRetry={() => {
          usersQuery.refetch();
          metricsQuery.refetch();
        }}
      />
    );
  }

  const hasData = agentRows.length > 0 && windowMetrics.length > 0;
  const chartW = Dimensions.get("window").width - 32 - 32;

  const maxMtdTarget = Math.max(1, ...topByMtd.map((r) => Math.max(r.salesMtd, r.target)));
  const maxActivity = Math.max(1, ...topByActivity.map((r) => Math.max(r.dc, r.prospectCount, r.salesFd)));
  const maxCenter = Math.max(1, ...byCenter.map((c) => Math.max(c.salesMtd, c.target)));

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 24, gap: 16 }}
    >
      <View style={{ gap: 4 }}>
        <Text style={{ fontFamily: "Inter_700Bold", fontSize: 20, color: colors.foreground }}>Sales Report</Text>
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>
          Agent performance — Sales MTD, Target, DC &amp; activity
        </Text>
      </View>

      <Segmented options={PERIODS} value={period} onChange={setPeriod} />

      {seesAllCenters && centers.length > 1 ? (
        <Segmented
          options={[
            { value: "All", label: "All Centers" },
            ...centers.map((c) => ({ value: c, label: c.replace(/ Center$/, "") })),
          ]}
          value={centerFilter}
          onChange={(v) => {
            setCenterFilter(v);
            setTlFilter("All");
          }}
        />
      ) : null}

      {teamLeaders.length > 1 ? (
        <Segmented
          options={[
            { value: "All", label: "All TLs" },
            ...teamLeaders.map((tl) => ({ value: String(tl.id), label: firstName(tl.name) })),
          ]}
          value={tlFilter}
          onChange={setTlFilter}
        />
      ) : null}

      {/* KPI cards */}
      <View style={styles.kpiGrid}>
        <KpiCard label="Sales MTD" value={fmt(totals.salesMtd)} accent={SERIES.mtd} />
        <KpiCard label="Target" value={fmt(totals.target)} accent={SERIES.target} />
        <KpiCard
          label="Achievement"
          value={`${overallAch}%`}
          accent={achColor(overallAch)}
          sub={`${fmt(totals.salesMtd)} / ${fmt(totals.target)}`}
        />
        <KpiCard label="DC" value={fmt(totals.dc)} accent={SERIES.dc} />
        <KpiCard label="Prospect Count" value={fmt(totals.prospectCount)} accent={SERIES.prospect} />
        <KpiCard label="Sales FD" value={fmt(totals.salesFd)} accent={SERIES.salesFd} />
      </View>

      {!hasData ? (
        <View style={{ paddingTop: 40 }}>
          <EmptyState icon="bar-chart-2" title="No sales data" message="No sales data for the selected period." />
        </View>
      ) : (
        <>
          {/* Sales MTD vs Target — Top Agents */}
          <View style={{ gap: 8 }}>
            <SectionTitle>SALES MTD VS TARGET — TOP AGENTS</SectionTitle>
            <Card style={{ gap: 14 }}>
              {topByMtd.map((r) => (
                <View key={r.id} style={{ gap: 6 }}>
                  <View style={styles.rowHead}>
                    <Text style={[styles.agentName, { color: colors.foreground }]} numberOfLines={1}>
                      {r.short}
                    </Text>
                    <Text style={[styles.agentMeta, { color: colors.mutedForeground }]}>
                      {fmt(r.salesMtd)} / {fmt(r.target)}
                    </Text>
                  </View>
                  <ProgressBar frac={r.salesMtd / maxMtdTarget} color={SERIES.mtd} />
                  <ProgressBar frac={r.target / maxMtdTarget} color={SERIES.target} />
                </View>
              ))}
              <Legend items={[{ label: "Sales MTD", color: SERIES.mtd }, { label: "Target", color: SERIES.target }]} />
            </Card>
          </View>

          {/* Achievement % — Top Agents */}
          <View style={{ gap: 8 }}>
            <SectionTitle>ACHIEVEMENT % — TOP AGENTS (SALES MTD ÷ TARGET)</SectionTitle>
            <Card style={{ gap: 14 }}>
              {achRanked.length === 0 ? (
                <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>
                  No targets set for this period.
                </Text>
              ) : (
                achRanked.map((r) => (
                  <View key={r.id} style={{ gap: 6 }}>
                    <View style={styles.rowHead}>
                      <Text style={[styles.agentName, { color: colors.foreground }]} numberOfLines={1}>
                        {r.short}
                      </Text>
                      <Text style={[styles.agentMeta, { color: achColor(r.achievement) }]}>{r.achievement}%</Text>
                    </View>
                    <ProgressBar frac={r.achievement / 100} color={achColor(r.achievement)} />
                  </View>
                ))
              )}
            </Card>
          </View>

          {/* Activity — DC / Prospect / Sales FD */}
          <View style={{ gap: 8 }}>
            <SectionTitle>ACTIVITY — DC / PROSPECT / SALES FD (TOP AGENTS)</SectionTitle>
            <Card style={{ gap: 14 }}>
              {topByActivity.map((r) => (
                <View key={r.id} style={{ gap: 6 }}>
                  <Text style={[styles.agentName, { color: colors.foreground }]} numberOfLines={1}>
                    {r.short}
                  </Text>
                  <View style={styles.activityRow}>
                    <View style={{ flex: 1, gap: 4 }}>
                      <ProgressBar frac={r.dc / maxActivity} color={SERIES.dc} />
                    </View>
                    <Text style={[styles.activityVal, { color: colors.mutedForeground }]}>{fmt(r.dc)}</Text>
                  </View>
                  <View style={styles.activityRow}>
                    <View style={{ flex: 1, gap: 4 }}>
                      <ProgressBar frac={r.prospectCount / maxActivity} color={SERIES.prospect} />
                    </View>
                    <Text style={[styles.activityVal, { color: colors.mutedForeground }]}>{fmt(r.prospectCount)}</Text>
                  </View>
                  <View style={styles.activityRow}>
                    <View style={{ flex: 1, gap: 4 }}>
                      <ProgressBar frac={r.salesFd / maxActivity} color={SERIES.salesFd} />
                    </View>
                    <Text style={[styles.activityVal, { color: colors.mutedForeground }]}>{fmt(r.salesFd)}</Text>
                  </View>
                </View>
              ))}
              <Legend
                items={[
                  { label: "DC", color: SERIES.dc },
                  { label: "Prospect", color: SERIES.prospect },
                  { label: "Sales FD", color: SERIES.salesFd },
                ]}
              />
            </Card>
          </View>

          {/* Sales MTD vs Target — by Center */}
          <View style={{ gap: 8 }}>
            <SectionTitle>SALES MTD VS TARGET — BY CENTER</SectionTitle>
            <Card style={{ gap: 14 }}>
              {byCenter.map((c) => (
                <View key={c.center} style={{ gap: 6 }}>
                  <View style={styles.rowHead}>
                    <Text style={[styles.agentName, { color: colors.foreground }]} numberOfLines={1}>
                      {c.name}
                    </Text>
                    <Text style={[styles.agentMeta, { color: colors.mutedForeground }]}>
                      {fmt(c.salesMtd)} / {fmt(c.target)}
                    </Text>
                  </View>
                  <ProgressBar frac={c.salesMtd / maxCenter} color={SERIES.mtd} />
                  <ProgressBar frac={c.target / maxCenter} color={SERIES.target} />
                </View>
              ))}
              <Legend items={[{ label: "Sales MTD", color: SERIES.mtd }, { label: "Target", color: SERIES.target }]} />
            </Card>
          </View>

          {/* Daily Sales (FD) Trend */}
          <View style={{ gap: 8 }}>
            <SectionTitle>DAILY SALES (FD) TREND</SectionTitle>
            <Card>
              {trend.length > 0 ? (
                <BarChart data={trend.map((t) => ({ label: t.label, value: t.value, color: SERIES.salesFd }))} width={chartW} />
              ) : (
                <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>
                  No data.
                </Text>
              )}
            </Card>
          </View>
        </>
      )}
    </ScrollView>
  );
}

function Legend({ items }: { items: { label: string; color: string }[] }) {
  const colors = useColors();
  return (
    <View style={styles.legendRow}>
      {items.map((it) => (
        <View key={it.label} style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: it.color }]} />
          <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>{it.label}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  kpiGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  kpiCard: { width: "47%", flexGrow: 1, gap: 2 },
  kpiLabel: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.6 },
  kpiValue: { fontFamily: "Inter_700Bold", fontSize: 22, marginTop: 2 },
  kpiSub: { fontFamily: "Inter_400Regular", fontSize: 12 },
  sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.6, marginLeft: 4 },
  rowHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  agentName: { flex: 1, fontFamily: "Inter_600SemiBold", fontSize: 14 },
  agentMeta: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  track: { height: 8, borderRadius: 999, overflow: "hidden" },
  activityRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  activityVal: { fontFamily: "Inter_500Medium", fontSize: 12, width: 56, textAlign: "right" },
  legendRow: { flexDirection: "row", flexWrap: "wrap", gap: 16, marginTop: 4, justifyContent: "center" },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  legendDot: { width: 10, height: 10, borderRadius: 3 },
});
