import type { Task, User } from "@workspace/api-client-react";
import {
  getListTasksQueryKey,
  getListUsersQueryKey,
  useListTasks,
  useListUsers,
} from "@workspace/api-client-react";
import React, { useMemo, useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Card, LoadingState, Segmented, type Option } from "@/components/ui";
import { useColors } from "@/hooks/useColors";

const PERIODS: Option[] = [
  { value: "month", label: "This Month" },
  { value: "30", label: "Last 30 Days" },
  { value: "all", label: "All Time" },
];

function withinPeriod(task: Task, period: string): boolean {
  if (period === "all") return true;
  const raw = task.dueDate || task.createdAt;
  if (!raw) return true;
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return true;
  const now = new Date();
  if (period === "month") {
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
  }
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 30);
  return d >= cutoff;
}

export default function ReportsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [period, setPeriod] = useState("month");

  const tasksQuery = useListTasks({}, { query: { queryKey: getListTasksQueryKey({}) } });
  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey() } });

  const nameById = useMemo(() => {
    const map = new Map<number, string>();
    (usersQuery.data ?? []).forEach((u: User) => map.set(u.id, u.name));
    return map;
  }, [usersQuery.data]);

  const stats = useMemo(() => {
    const tasks = (tasksQuery.data ?? []).filter((t: Task) => withinPeriod(t, period));
    const total = tasks.length;
    const done = tasks.filter((t) => t.status === "done").length;
    const pending = tasks.filter((t) => t.status === "pending").length;
    const inProgress = tasks.filter((t) => t.status === "inProgress").length;
    const doneRate = total > 0 ? Math.round((done / total) * 100) : 0;

    const byType = new Map<string, number>();
    const byMember = new Map<number, { total: number; done: number }>();
    tasks.forEach((t) => {
      byType.set(t.type, (byType.get(t.type) ?? 0) + 1);
      if (t.assignedTo != null) {
        const m = byMember.get(t.assignedTo) ?? { total: 0, done: 0 };
        m.total += 1;
        if (t.status === "done") m.done += 1;
        byMember.set(t.assignedTo, m);
      }
    });

    const members = [...byMember.entries()]
      .map(([id, m]) => ({ id, name: nameById.get(id) ?? `#${id}`, ...m }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 15);

    return { total, done, pending, inProgress, doneRate, byType: [...byType.entries()], members };
  }, [tasksQuery.data, period, nameById]);

  if (tasksQuery.isLoading || usersQuery.isLoading) return <LoadingState />;

  const kpis = [
    { label: "Total", value: stats.total, color: colors.foreground },
    { label: "Done", value: stats.done, color: colors.success },
    { label: "In Progress", value: stats.inProgress, color: colors.primary },
    { label: "Pending", value: stats.pending, color: colors.warning },
  ];

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 24, gap: 16 }}
    >
      <Segmented options={PERIODS} value={period} onChange={setPeriod} />

      <Card style={{ alignItems: "center", gap: 4 }}>
        <Text style={{ fontFamily: "Inter_700Bold", fontSize: 40, color: colors.primary }}>{stats.doneRate}%</Text>
        <Text style={{ fontFamily: "Inter_500Medium", fontSize: 13, color: colors.mutedForeground }}>
          Completion Rate
        </Text>
      </Card>

      <View style={styles.kpiGrid}>
        {kpis.map((k) => (
          <Card key={k.label} style={styles.kpiCard}>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 22, color: k.color }}>{k.value}</Text>
            <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
              {k.label}
            </Text>
          </Card>
        ))}
      </View>

      {stats.byType.length > 0 ? (
        <View style={{ gap: 8 }}>
          <Text style={[styles.section, { color: colors.mutedForeground }]}>BY TYPE</Text>
          <Card style={{ padding: 0 }}>
            {stats.byType.map(([type, count], i) => (
              <View
                key={type}
                style={[
                  styles.rowItem,
                  i < stats.byType.length - 1
                    ? { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth }
                    : null,
                ]}
              >
                <Text style={{ flex: 1, fontFamily: "Inter_500Medium", fontSize: 14, color: colors.foreground }}>
                  {type}
                </Text>
                <Text style={{ fontFamily: "Inter_700Bold", fontSize: 14, color: colors.foreground }}>{count}</Text>
              </View>
            ))}
          </Card>
        </View>
      ) : null}

      {stats.members.length > 0 ? (
        <View style={{ gap: 8 }}>
          <Text style={[styles.section, { color: colors.mutedForeground }]}>MEMBER PERFORMANCE</Text>
          <Card style={{ padding: 0 }}>
            {stats.members.map((m, i) => {
              const rate = m.total > 0 ? Math.round((m.done / m.total) * 100) : 0;
              return (
                <View
                  key={m.id}
                  style={[
                    styles.rowItem,
                    i < stats.members.length - 1
                      ? { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth }
                      : null,
                  ]}
                >
                  <Text
                    style={{ flex: 1, fontFamily: "Inter_500Medium", fontSize: 14, color: colors.foreground }}
                    numberOfLines={1}
                  >
                    {m.name}
                  </Text>
                  <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground, marginRight: 10 }}>
                    {m.done}/{m.total}
                  </Text>
                  <Text style={{ fontFamily: "Inter_700Bold", fontSize: 13, color: colors.primary, width: 44, textAlign: "right" }}>
                    {rate}%
                  </Text>
                </View>
              );
            })}
          </Card>
        </View>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  kpiGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  kpiCard: { width: "47%", flexGrow: 1, alignItems: "center", gap: 2 },
  section: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.6, marginLeft: 4 },
  rowItem: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14 },
});
