import type { Task, User } from "@workspace/api-client-react";
import {
  getListTasksQueryKey,
  getListUsersQueryKey,
  useListTasks,
  useListUsers,
} from "@workspace/api-client-react";
import React, { useMemo, useState } from "react";
import { FlatList, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  Card,
  EmptyState,
  ErrorState,
  LoadingState,
  Segmented,
  Select,
  StatusPill,
  TextField,
  type Option,
} from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { isAllCentersViewer } from "@/lib/permissions";

const CENTER_ORDER = ["Head Office", "Thane Center", "Malad Center", "Pune Center", "Navi Mumbai Center"];

const STATUS_OPTIONS: Option[] = [
  { value: "all", label: "All" },
  { value: "pending", label: "Pending" },
  { value: "inProgress", label: "In Progress" },
  { value: "done", label: "Done" },
];

const PERIOD_OPTIONS: Option[] = [
  { value: "all", label: "All Time" },
  { value: "today", label: "Today" },
  { value: "7", label: "Last 7 Days" },
  { value: "30", label: "Last 30 Days" },
  { value: "month", label: "This Month" },
];

/** Today's date (YYYY-MM-DD) in IST — matches how task dates are bucketed elsewhere. */
function istTodayStr(): string {
  return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
}

/** Compute inclusive [from, to] YYYY-MM-DD bounds for a period preset. */
function periodBounds(period: string): { from: string; to: string } {
  const today = istTodayStr();
  if (period === "all") return { from: "", to: "" };
  if (period === "today") return { from: today, to: today };
  if (period === "month") return { from: today.slice(0, 8) + "01", to: today };
  const days = period === "7" ? 6 : 29;
  const d = new Date(today + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() - days);
  return { from: d.toISOString().slice(0, 10), to: today };
}

function formatDate(d: string | null | undefined): string {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

/**
 * Mirror of the web app's resolveAllowedCenters — the set of centers a viewer
 * may see AFTER applying any per-user centerPermissions restriction. Returns
 * null when there is no center-level restriction.
 */
function resolveAllowedCenters(
  viewer: User | null | undefined,
  allUsers: User[],
): Set<string> | null {
  if (!viewer) return null;
  const perms = viewer.centerPermissions;
  if (perms == null) return null;
  const isBoss = viewer.department === "Management" || viewer.role === "Boss";
  const isAll = isAllCentersViewer(viewer);
  if (!isBoss && !isAll) return null;
  const ceiling = new Set(
    allUsers.map((u) => u.center).filter((c): c is string => Boolean(c)),
  );
  if (isAll && !isBoss) ceiling.delete("Head Office");
  return new Set([...ceiling].filter((c) => perms.includes(c)));
}

export default function AssignmentMonitorScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user: currentUser } = useAuth();

  const isBoss = !!currentUser && (currentUser.department === "Management" || currentUser.role === "Boss");
  const isMis = isAllCentersViewer(currentUser);
  const isCenterHead = !!currentUser && currentUser.role === "Center Head";
  const seesAll = isBoss || isMis;
  const canView = seesAll || isCenterHead;

  const tasksQuery = useListTasks({}, { query: { enabled: canView, queryKey: getListTasksQueryKey({}) } });
  const usersQuery = useListUsers({ query: { enabled: canView, queryKey: getListUsersQueryKey() } });

  const allTasks: Task[] = tasksQuery.data ?? [];
  const users: User[] = usersQuery.data ?? [];

  const userCenter = useMemo(() => new Map(users.map((u) => [u.id, u.center])), [users]);
  const myCenter = useMemo(
    () => users.find((u) => u.id === currentUser?.id)?.center ?? null,
    [users, currentUser],
  );
  const me = useMemo(() => users.find((u) => u.id === currentUser?.id) ?? null, [users, currentUser]);
  const allowedCenters = useMemo(() => resolveAllowedCenters(me, users), [me, users]);

  const scopedUsers = useMemo(() => {
    let base = isBoss
      ? users
      : isMis
        ? users.filter((u) => u.center && u.center !== "Head Office")
        : users.filter((u) => u.center === myCenter);
    if (allowedCenters) base = base.filter((u) => u.center && allowedCenters.has(u.center));
    return base;
  }, [isBoss, isMis, users, myCenter, allowedCenters]);

  const [centerFilter, setCenterFilter] = useState<string>("all");
  const [assignerFilter, setAssignerFilter] = useState<string>("all");
  const [assigneeFilter, setAssigneeFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [period, setPeriod] = useState<string>("all");
  const [search, setSearch] = useState("");

  const { from: fromDate, to: toDate } = useMemo(() => periodBounds(period), [period]);

  const centerOptions = useMemo(() => {
    const set = new Set(scopedUsers.map((u) => u.center).filter((c): c is string => Boolean(c)));
    const rank = (c: string) => {
      const i = CENTER_ORDER.indexOf(c);
      return i === -1 ? CENTER_ORDER.length : i;
    };
    return Array.from(set).sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
  }, [scopedUsers]);

  const centerScopedUsers = useMemo(
    () => (centerFilter === "all" ? scopedUsers : scopedUsers.filter((u) => u.center === centerFilter)),
    [scopedUsers, centerFilter],
  );

  const assigners = useMemo(() => {
    const ids = new Set<number>();
    for (const t of allTasks) if (t.assignedBy != null) ids.add(t.assignedBy);
    return centerScopedUsers.filter((u) => ids.has(u.id));
  }, [allTasks, centerScopedUsers]);

  const rows = useMemo(() => {
    let t = allTasks.filter((x) => x.assignedBy != null && x.assignedTo != null);
    if (!seesAll) {
      t = t.filter(
        (x) => userCenter.get(x.assignedTo!) === myCenter && userCenter.get(x.assignedBy!) === myCenter,
      );
    } else if (isMis) {
      t = t.filter((x) => {
        const to = userCenter.get(x.assignedTo!);
        const by = userCenter.get(x.assignedBy!);
        return !!to && to !== "Head Office" && !!by && by !== "Head Office";
      });
    }
    if (allowedCenters) {
      t = t.filter((x) => {
        const to = userCenter.get(x.assignedTo!);
        const by = userCenter.get(x.assignedBy!);
        return !!to && allowedCenters.has(to) && !!by && allowedCenters.has(by);
      });
    }
    if (centerFilter !== "all") t = t.filter((x) => userCenter.get(x.assignedTo!) === centerFilter);
    if (assignerFilter !== "all") t = t.filter((x) => x.assignedBy === Number(assignerFilter));
    if (assigneeFilter !== "all") t = t.filter((x) => x.assignedTo === Number(assigneeFilter));
    if (statusFilter !== "all") t = t.filter((x) => x.status === statusFilter);
    if (fromDate) t = t.filter((x) => (x.createdAt ?? "").slice(0, 10) >= fromDate);
    if (toDate) t = t.filter((x) => (x.createdAt ?? "").slice(0, 10) <= toDate);
    if (search.trim()) {
      const q = search.toLowerCase();
      t = t.filter(
        (x) =>
          x.title.toLowerCase().includes(q) ||
          (x.assignedByName ?? "").toLowerCase().includes(q) ||
          (x.assignedToName ?? "").toLowerCase().includes(q),
      );
    }
    return [...t].sort((a, b) => (b.createdAt ?? "").localeCompare(a.createdAt ?? ""));
  }, [
    allTasks,
    centerFilter,
    assignerFilter,
    assigneeFilter,
    statusFilter,
    fromDate,
    toDate,
    search,
    seesAll,
    isMis,
    userCenter,
    myCenter,
    allowedCenters,
  ]);

  const totalAssignments = rows.length;
  const selfAssigned = rows.filter((r) => r.assignedBy === r.assignedTo).length;
  const crossAssigned = totalAssignments - selfAssigned;

  if (!canView) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <EmptyState
          icon="lock"
          title="Restricted"
          message="This page is for the Boss, MIS, and Center Heads only."
        />
      </View>
    );
  }

  if (tasksQuery.isLoading || usersQuery.isLoading) return <LoadingState />;
  if (tasksQuery.isError) return <ErrorState onRetry={() => tasksQuery.refetch()} />;

  const centerSelectOptions: Option[] = [
    { value: "all", label: "All Centers" },
    ...centerOptions.map((c) => ({ value: c, label: c })),
  ];
  const assignerSelectOptions: Option[] = [
    { value: "all", label: "All" },
    ...assigners.map((u) => ({ value: String(u.id), label: u.name })),
  ];
  const assigneeSelectOptions: Option[] = [
    { value: "all", label: "All" },
    ...centerScopedUsers.map((u) => ({ value: String(u.id), label: u.name })),
  ];

  const kpis = [
    { label: "Total assignments", value: totalAssignments, color: colors.foreground },
    { label: "Assigned to others", value: crossAssigned, color: colors.primary },
    { label: "Assigned to self", value: selfAssigned, color: colors.warning },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        data={rows}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 24, gap: 12 }}
        refreshing={tasksQuery.isRefetching}
        onRefresh={() => {
          tasksQuery.refetch();
          usersQuery.refetch();
        }}
        ListHeaderComponent={
          <View style={{ gap: 14, marginBottom: 4 }}>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              {seesAll
                ? "See who is assigning tasks to whom, across all centers."
                : `See who is assigning tasks to whom in your center${myCenter ? ` — ${myCenter}` : ""}.`}
            </Text>

            <View style={styles.kpiGrid}>
              {kpis.map((k) => (
                <Card key={k.label} style={styles.kpiCard}>
                  <Text style={{ fontFamily: "Inter_700Bold", fontSize: 22, color: k.color }}>{k.value}</Text>
                  <Text
                    style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}
                    numberOfLines={1}
                  >
                    {k.label}
                  </Text>
                </Card>
              ))}
            </View>

            <View style={{ gap: 6 }}>
              <Text style={[styles.filterLabel, { color: colors.mutedForeground }]}>DATE</Text>
              <Segmented options={PERIOD_OPTIONS} value={period} onChange={setPeriod} />
            </View>

            <View style={{ gap: 6 }}>
              <Text style={[styles.filterLabel, { color: colors.mutedForeground }]}>STATUS</Text>
              <Segmented options={STATUS_OPTIONS} value={statusFilter} onChange={setStatusFilter} />
            </View>

            {seesAll && centerOptions.length > 1 ? (
              <Select
                label="Center"
                value={centerFilter}
                options={centerSelectOptions}
                onChange={(v) => {
                  setCenterFilter(v);
                  setAssignerFilter("all");
                  setAssigneeFilter("all");
                }}
              />
            ) : null}

            <Select
              label="Assigned by (Assigner)"
              value={assignerFilter}
              options={assignerSelectOptions}
              onChange={setAssignerFilter}
            />

            <Select
              label="Assigned to (Assignee)"
              value={assigneeFilter}
              options={assigneeSelectOptions}
              onChange={setAssigneeFilter}
            />

            <TextField
              label="Search"
              value={search}
              onChangeText={setSearch}
              placeholder="Search by task or name..."
            />

            <Text style={[styles.count, { color: colors.mutedForeground }]}>
              {totalAssignments} {totalAssignments === 1 ? "assignment" : "assignments"}
            </Text>
          </View>
        }
        ListEmptyComponent={
          <View style={{ paddingTop: 40 }}>
            <EmptyState icon="inbox" title="No assignments found" message="Try changing the filters above." />
          </View>
        }
        renderItem={({ item }) => (
          <Card style={{ gap: 10 }}>
            <View style={styles.rowTop}>
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                {formatDate(item.createdAt)}
              </Text>
              <StatusPill status={item.status} />
            </View>
            <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 15, color: colors.foreground }}>
              {item.title}
            </Text>
            <View style={styles.people}>
              <Text style={{ fontFamily: "Inter_500Medium", fontSize: 13, color: colors.foreground }} numberOfLines={1}>
                {item.assignedByName ?? "—"}
              </Text>
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>→</Text>
              <Text style={{ fontFamily: "Inter_500Medium", fontSize: 13, color: colors.foreground }} numberOfLines={1}>
                {item.assignedToName ?? "—"}
              </Text>
            </View>
          </Card>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  subtitle: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 19 },
  kpiGrid: { flexDirection: "row", gap: 10 },
  kpiCard: { flex: 1, alignItems: "center", gap: 2, padding: 12 },
  filterLabel: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.4, marginLeft: 2 },
  count: { fontFamily: "Inter_500Medium", fontSize: 13, marginTop: 2 },
  rowTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  people: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" },
});
