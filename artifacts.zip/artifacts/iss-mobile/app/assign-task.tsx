import type { Category, User } from "@workspace/api-client-react";
import {
  getListCategoriesQueryKey,
  getListUsersQueryKey,
  useCreateTask,
  useListCategories,
  useListUsers,
} from "@workspace/api-client-react";
import { resolveAssignableUsers } from "@workspace/assign-scope";
import { useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import { Alert, Platform, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Button, Select, TextField, type Option } from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

const PRIORITY_OPTIONS: Option[] = [
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "urgent", label: "Urgent" },
];

const TYPE_OPTIONS: Option[] = [
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "one_time", label: "One Time" },
];

export default function AssignTaskScreen() {
  const colors = useColors();
  const router = useRouter();
  const qc = useQueryClient();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey() } });
  const categoriesQuery = useListCategories({
    query: { queryKey: getListCategoriesQueryKey() },
  });
  const createTask = useCreateTask();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [assignedTo, setAssignedTo] = useState<string | null>(null);
  const [category, setCategory] = useState<string | null>(null);
  const [priority, setPriority] = useState("medium");
  const [type, setType] = useState("daily");
  const [dueDate, setDueDate] = useState("");

  const userOptions: Option[] = useMemo(
    () =>
      resolveAssignableUsers(user, usersQuery.data ?? []).map((u: User) => ({
        value: String(u.id),
        label: u.center ? `${u.name} · ${u.center}` : u.name,
      })),
    [usersQuery.data, user],
  );
  const categoryOptions: Option[] = useMemo(
    () => (categoriesQuery.data ?? []).map((c: Category) => ({ value: c.name, label: c.name })),
    [categoriesQuery.data],
  );

  const notify = (msg: string) => {
    if (Platform.OS === "web") window.alert(msg);
    else Alert.alert(msg);
  };

  const onSubmit = async () => {
    if (!title.trim()) {
      notify("Please enter a task title.");
      return;
    }
    try {
      await createTask.mutateAsync({
        data: {
          title: title.trim(),
          description: description.trim() || null,
          assignedTo: assignedTo ? Number(assignedTo) : null,
          assignedBy: user?.id ?? null,
          dueDate: dueDate.trim() || null,
          priority,
          type,
          category: category || null,
          sendEmail: true,
        },
      });
      qc.invalidateQueries();
      notify("Task assigned successfully.");
      router.back();
    } catch {
      notify("Could not assign the task. Please try again.");
    }
  };

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 32, gap: 16 }}
      keyboardShouldPersistTaps="handled"
    >
      <TextField label="Task Title" value={title} onChangeText={setTitle} placeholder="e.g. Follow up with client" />
      <TextField
        label="Description"
        value={description}
        onChangeText={setDescription}
        placeholder="Add details (optional)"
        multiline
      />
      <Select
        label="Assign To"
        value={assignedTo}
        options={userOptions}
        onChange={setAssignedTo}
        placeholder="— Unassigned —"
      />
      <Select
        label="Category"
        value={category}
        options={categoryOptions}
        onChange={setCategory}
        placeholder="No Category"
      />
      <Select label="Priority" value={priority} options={PRIORITY_OPTIONS} onChange={setPriority} />
      <Select label="Type" value={type} options={TYPE_OPTIONS} onChange={setType} />
      <TextField label="Due Date" value={dueDate} onChangeText={setDueDate} placeholder="YYYY-MM-DD" />

      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
        The assignee will be notified in-app and by email.
      </Text>

      <Button label="Assign Task" icon="plus-circle" onPress={onSubmit} loading={createTask.isPending} />
    </ScrollView>
  );
}
