import type { Holiday } from "@workspace/api-client-react";
import {
  getListHolidaysQueryKey,
  useCreateHoliday,
  useDeleteHoliday,
  useListHolidays,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import React, { useMemo, useState } from "react";
import { Alert, Platform, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  Button,
  Card,
  EmptyState,
  LoadingState,
  Select,
  TextField,
  type Option,
} from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { canManage } from "@/lib/permissions";

const TYPE_OPTIONS: Option[] = [
  { value: "full", label: "Full Day" },
  { value: "half", label: "Half Day" },
  { value: "weekend", label: "Weekend" },
];

const TYPE_LABELS: Record<string, string> = {
  full: "Full Day",
  half: "Half Day",
  weekend: "Weekend",
};

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function dayOfWeek(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  return DAYS[d.getDay()];
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function monthLabel(ym: string): string {
  const [year, m] = ym.split("-");
  return `${MONTHS[parseInt(m, 10) - 1]} ${year}`;
}

export default function HolidaysScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const { user } = useAuth();

  const holidaysQuery = useListHolidays({ query: { queryKey: getListHolidaysQueryKey() } });
  const createHoliday = useCreateHoliday();
  const deleteHoliday = useDeleteHoliday();

  const manage = canManage(user);

  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ date: "", name: "", type: "full" });
  const [error, setError] = useState("");

  const typeBadge = (type: string): string => {
    if (type === "full") return colors.destructive;
    if (type === "half") return colors.warning;
    if (type === "weekend") return colors.primary;
    return colors.mutedForeground;
  };

  const notify = (msg: string) => {
    if (Platform.OS === "web") window.alert(msg);
    else Alert.alert(msg);
  };

  const grouped = useMemo(() => {
    const holidays = holidaysQuery.data ?? [];
    const sorted = [...holidays].sort((a, b) => a.date.localeCompare(b.date));
    const byMonth = new Map<string, Holiday[]>();
    for (const h of sorted) {
      const month = h.date.slice(0, 7);
      if (!byMonth.has(month)) byMonth.set(month, []);
      byMonth.get(month)!.push(h);
    }
    return Array.from(byMonth.entries());
  }, [holidaysQuery.data]);

  const handleAdd = () => {
    setError("");
    if (!form.date.trim() || !form.name.trim()) {
      setError("Please enter both a date and a holiday name.");
      return;
    }
    createHoliday.mutate(
      {
        data: {
          date: form.date.trim(),
          name: form.name.trim(),
          day: dayOfWeek(form.date.trim()),
          type: form.type,
        },
      },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListHolidaysQueryKey() });
          setForm({ date: "", name: "", type: "full" });
          setShowAdd(false);
        },
        onError: () =>
          setError("This holiday could not be saved. It may already exist for that date."),
      },
    );
  };

  const doDelete = (h: Holiday) => {
    deleteHoliday.mutate(
      { id: h.id },
      { onSuccess: () => qc.invalidateQueries({ queryKey: getListHolidaysQueryKey() }) },
    );
  };

  const handleDelete = (h: Holiday) => {
    if (Platform.OS === "web") {
      if (window.confirm(`Remove the "${h.name}" holiday?`)) doDelete(h);
      return;
    }
    Alert.alert("Remove Holiday", `Remove the "${h.name}" holiday?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Remove", style: "destructive", onPress: () => doDelete(h) },
    ]);
  };

  if (holidaysQuery.isLoading) return <LoadingState />;

  const holidays = holidaysQuery.data ?? [];

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 32, gap: 16 }}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.headerRow}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontFamily: "Inter_700Bold", fontSize: 20, color: colors.foreground }}>
            🎉 Holiday List 2026
          </Text>
          <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground, marginTop: 2 }}>
            Head Office off days for the year.
          </Text>
        </View>
        {manage ? (
          <Button
            label={showAdd ? "Cancel" : "Add"}
            icon={showAdd ? "x" : "plus"}
            variant={showAdd ? "secondary" : "primary"}
            onPress={() => {
              setShowAdd((s) => !s);
              setError("");
            }}
          />
        ) : null}
      </View>

      {manage && showAdd ? (
        <Card style={{ gap: 12 }}>
          <TextField
            label="Date"
            value={form.date}
            onChangeText={(t) => setForm((f) => ({ ...f, date: t }))}
            placeholder="YYYY-MM-DD"
          />
          <Select
            label="Type"
            value={form.type}
            options={TYPE_OPTIONS}
            onChange={(v) => setForm((f) => ({ ...f, type: v }))}
          />
          <TextField
            label="Holiday Name"
            value={form.name}
            onChangeText={(t) => setForm((f) => ({ ...f, name: t }))}
            placeholder="e.g. Republic Day"
          />
          {error ? (
            <Text style={{ fontFamily: "Inter_500Medium", fontSize: 12, color: colors.destructive }}>
              {error}
            </Text>
          ) : null}
          <Button
            label={createHoliday.isPending ? "Saving..." : "Save Holiday"}
            icon="check"
            onPress={handleAdd}
            loading={createHoliday.isPending}
          />
        </Card>
      ) : null}

      {holidays.length === 0 ? (
        <View style={{ paddingTop: 60 }}>
          <EmptyState icon="calendar" title="No holidays added yet" />
        </View>
      ) : (
        grouped.map(([month, items]) => (
          <View key={month} style={{ gap: 8 }}>
            <Text style={[styles.monthHeader, { color: colors.mutedForeground }]}>
              {monthLabel(month).toUpperCase()}
            </Text>
            <Card style={{ padding: 0 }}>
              {items.map((h, i) => {
                const badge = typeBadge(h.type);
                return (
                  <View
                    key={h.id}
                    style={[
                      styles.row,
                      i < items.length - 1
                        ? { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth }
                        : null,
                    ]}
                  >
                    <View style={styles.dateBox}>
                      <Text style={{ fontFamily: "Inter_700Bold", fontSize: 18, color: colors.foreground }}>
                        {h.date.slice(8, 10)}
                      </Text>
                      <Text style={{ fontFamily: "Inter_500Medium", fontSize: 11, color: colors.mutedForeground }}>
                        {MONTHS[parseInt(h.date.slice(5, 7), 10) - 1].slice(0, 3).toUpperCase()}
                      </Text>
                    </View>
                    <View style={{ flex: 1, minWidth: 0 }}>
                      <Text
                        style={{ fontFamily: "Inter_600SemiBold", fontSize: 15, color: colors.foreground }}
                        numberOfLines={1}
                      >
                        {h.name}
                      </Text>
                      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                        {h.day} · {formatDate(h.date)}
                      </Text>
                    </View>
                    <View style={[styles.badge, { backgroundColor: badge + "22" }]}>
                      <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 12, color: badge }}>
                        {TYPE_LABELS[h.type] ?? h.type}
                      </Text>
                    </View>
                    {manage ? (
                      <Text
                        onPress={() => handleDelete(h)}
                        style={{ fontFamily: "Inter_600SemiBold", fontSize: 12, color: colors.destructive }}
                      >
                        Remove
                      </Text>
                    ) : null}
                  </View>
                );
              })}
            </Card>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  monthHeader: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.6, marginLeft: 4 },
  row: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 14, paddingVertical: 12 },
  dateBox: { width: 44, alignItems: "center" },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999 },
});
