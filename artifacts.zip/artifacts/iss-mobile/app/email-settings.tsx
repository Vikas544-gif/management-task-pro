import type { EmailSettings } from "@workspace/api-client-react";
import {
  getGetEmailSettingsQueryKey,
  useGetEmailSettings,
  useSendDashboardNow,
  useSendDigestNow,
  useSendTestEmail,
} from "@workspace/api-client-react";
import React, { useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Button, Card, EmptyState, LoadingState, TextField } from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { canManage } from "@/lib/permissions";

const HOW_IT_WORKS = [
  "Emails are sent through Resend — no SMTP password needed",
  "Every time a task is assigned, the assignee gets an email automatically",
  "Daily task reminders go out every morning at 9:00 AM",
  "Weekly reminders go every Monday at 9:00 AM",
  "Monthly reminders go on the 1st of each month at 9:00 AM",
  "Each team member must have their email set in the Team page",
];

export default function EmailSettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const canView = canManage(user);

  const { data: settings, isLoading } = useGetEmailSettings({
    query: { queryKey: getGetEmailSettingsQueryKey(), enabled: canView },
  });
  const sendTest = useSendTestEmail();
  const sendDigest = useSendDigestNow();
  const sendDashboard = useSendDashboardNow();

  const [testEmail, setTestEmail] = useState("");
  const [testResult, setTestResult] = useState("");
  const [digestResult, setDigestResult] = useState("");
  const [digestOk, setDigestOk] = useState(false);
  const [dashboardResult, setDashboardResult] = useState("");
  const [dashboardOk, setDashboardOk] = useState(false);

  if (!canView) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <EmptyState
          icon="lock"
          title="Access denied"
          message="You do not have permission to view Email Settings."
        />
      </View>
    );
  }

  if (isLoading) return <LoadingState />;

  const configured = (settings as EmailSettings | undefined)?.configured ?? false;

  const handleTest = () => {
    setTestResult("");
    sendTest.mutate(
      { data: { toEmail: testEmail } },
      {
        onSuccess: (res) => setTestResult(res.message),
        onError: () => setTestResult("Failed to send test email"),
      },
    );
  };

  const handleSendDigest = () => {
    setDigestResult("");
    sendDigest.mutate(undefined, {
      onSuccess: (res) => {
        setDigestResult(res.message);
        setDigestOk(res.sent > 0);
      },
      onError: () => {
        setDigestResult("There was a problem sending the reminder");
        setDigestOk(false);
      },
    });
  };

  const handleSendDashboard = () => {
    setDashboardResult("");
    sendDashboard.mutate(undefined, {
      onSuccess: (res) => {
        setDashboardResult(res.message);
        setDashboardOk(res.sent > 0);
      },
      onError: () => {
        setDashboardResult("There was a problem sending the dashboard summary");
        setDashboardOk(false);
      },
    });
  };

  const testOk = testResult.includes("success");

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 24, gap: 16 }}
      keyboardShouldPersistTaps="handled"
    >
      <View style={{ gap: 2 }}>
        <Text style={{ fontFamily: "Inter_700Bold", fontSize: 20, color: colors.foreground }}>
          Email Settings
        </Text>
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>
          Auto email notifications for tasks and reminders
        </Text>
      </View>

      {/* Info box */}
      <View
        style={[
          styles.infoBox,
          { backgroundColor: colors.primary + "1A", borderColor: colors.primary + "4D" },
        ]}
      >
        <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.primary, marginBottom: 6 }}>
          How Auto Email Works
        </Text>
        <View style={{ gap: 6 }}>
          {HOW_IT_WORKS.map((line) => (
            <View key={line} style={{ flexDirection: "row", gap: 6 }}>
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.primary }}>•</Text>
              <Text style={{ flex: 1, fontFamily: "Inter_400Regular", fontSize: 12, color: colors.primary, lineHeight: 18 }}>
                {line}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* Status */}
      <View
        style={[
          styles.status,
          configured
            ? { backgroundColor: colors.success + "1A", borderColor: colors.success + "4D" }
            : { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <View
          style={[
            styles.statusDot,
            { backgroundColor: configured ? colors.success : colors.mutedForeground },
          ]}
        />
        <Text
          style={{
            flex: 1,
            fontFamily: "Inter_500Medium",
            fontSize: 13,
            color: configured ? colors.success : colors.mutedForeground,
          }}
        >
          {configured
            ? `Auto email active — sending from ${(settings as EmailSettings).smtpEmail ?? ""}`
            : "Email not configured"}
        </Text>
      </View>

      {/* Domain verification note */}
      <View style={[styles.infoBox, { backgroundColor: colors.warning + "1A", borderColor: colors.warning + "4D" }]}>
        <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 13, color: colors.warning, marginBottom: 4 }}>
          Sending to your whole team
        </Text>
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.warning, lineHeight: 18 }}>
          Right now emails send from a Resend test address, which can only deliver to the email you signed up to
          Resend with. To send notifications to all team members, verify your company domain in Resend (Domains →
          Add Domain → add the DNS records). Once verified, tell us and we'll switch the sender to your company
          address.
        </Text>
      </View>

      {/* Test email */}
      <Card style={{ gap: 10 }}>
        <Text style={[styles.cardLabel, { color: colors.mutedForeground }]}>SEND TEST EMAIL</Text>
        <TextField
          value={testEmail}
          onChangeText={setTestEmail}
          placeholder="Recipient email"
          keyboardType="email-address"
        />
        <Button
          label={sendTest.isPending ? "Sending..." : "Send Test"}
          icon="send"
          onPress={handleTest}
          loading={sendTest.isPending}
          disabled={!testEmail || !configured}
        />
        {testResult ? (
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 12,
              color: testOk ? colors.success : colors.destructive,
            }}
          >
            {testResult}
          </Text>
        ) : null}
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
          Tip: send the first test to the email you used to sign up for Resend.
        </Text>
      </Card>

      {/* Daily pending-task reminder */}
      <Card style={{ gap: 10 }}>
        <Text style={[styles.cardLabel, { color: colors.mutedForeground }]}>DAILY PENDING-TASK REMINDER</Text>
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, lineHeight: 18 }}>
          This goes out automatically every morning at 9:00 AM. To test it now, tap the button below — anyone who
          has a due/pending task today and a configured email will receive a reminder.
        </Text>
        <Button
          label={sendDigest.isPending ? "Sending..." : "Send reminder now"}
          icon="mail"
          onPress={handleSendDigest}
          loading={sendDigest.isPending}
          disabled={!configured}
        />
        {digestResult ? (
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 12,
              color: digestOk ? colors.success : colors.warning,
            }}
          >
            {digestResult}
          </Text>
        ) : null}
      </Card>

      {/* Daily dashboard summary */}
      <Card style={{ gap: 10 }}>
        <Text style={[styles.cardLabel, { color: colors.mutedForeground }]}>DAILY DASHBOARD SUMMARY</Text>
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, lineHeight: 18 }}>
          A live dashboard snapshot (totals, pending, in progress, completed, completion rate, plus category and
          team breakdowns) goes out automatically every morning at 9:00 AM to the selected recipients. Tap below to
          send it now.
        </Text>
        <Button
          label={sendDashboard.isPending ? "Sending..." : "Send dashboard now"}
          icon="bar-chart-2"
          onPress={handleSendDashboard}
          loading={sendDashboard.isPending}
          disabled={!configured}
        />
        {dashboardResult ? (
          <Text
            style={{
              fontFamily: "Inter_500Medium",
              fontSize: 12,
              color: dashboardOk ? colors.success : colors.warning,
            }}
          >
            {dashboardResult}
          </Text>
        ) : null}
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  infoBox: { borderWidth: StyleSheet.hairlineWidth, borderRadius: 14, padding: 14 },
  status: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  statusDot: { width: 8, height: 8, borderRadius: 999 },
  cardLabel: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.4 },
});
