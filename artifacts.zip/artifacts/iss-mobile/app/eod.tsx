import type { EodReport, User } from "@workspace/api-client-react";
import {
  getListEodReportsQueryKey,
  getListUsersQueryKey,
  useListEodReports,
  useListUsers,
  useUpsertEodReport,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import React, { useEffect, useMemo, useState } from "react";
import { Alert, Platform, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Button, Card, LoadingState, Select, TextField, type Option } from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

const CENTER_ORDER = ["Head Office", "Thane Center", "Malad Center", "Pune Center", "Navi Mumbai Center"];

const NUMERIC_FIELDS: { key: keyof FormState; label: string }[] = [
  { key: "salesFd", label: "Sales (FD)" },
  { key: "salesMtd", label: "Sales (MTD)" },
  { key: "dc", label: "DC" },
  { key: "hc", label: "HC" },
  { key: "present", label: "Present" },
  { key: "absent", label: "Absent" },
  { key: "attrition", label: "Attrition" },
];

type FormState = {
  salesFd: string;
  salesMtd: string;
  dc: string;
  hc: string;
  present: string;
  absent: string;
  attrition: string;
  notes: string;
};

const EMPTY: FormState = {
  salesFd: "",
  salesMtd: "",
  dc: "",
  hc: "",
  present: "",
  absent: "",
  attrition: "",
  notes: "",
};

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export default function EodScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const { user } = useAuth();
  const date = todayStr();

  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey() } });
  const reportsQuery = useListEodReports(
    { date },
    { query: { queryKey: getListEodReportsQueryKey({ date }) } },
  );
  const upsert = useUpsertEodReport();

  const centerOptions: Option[] = useMemo(() => {
    const centers = new Set<string>();
    (usersQuery.data ?? []).forEach((u: User) => centers.add(u.center || "Head Office"));
    const ordered = [
      ...CENTER_ORDER.filter((c) => centers.has(c)),
      ...[...centers].filter((c) => !CENTER_ORDER.includes(c)).sort(),
    ];
    return ordered.map((c) => ({ value: c, label: c }));
  }, [usersQuery.data]);

  const [center, setCenter] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY);

  useEffect(() => {
    if (!center && centerOptions.length > 0) setCenter(centerOptions[0].value);
  }, [centerOptions, center]);

  const existing = useMemo(
    () => (reportsQuery.data ?? []).find((r: EodReport) => r.center === center),
    [reportsQuery.data, center],
  );

  useEffect(() => {
    if (existing) {
      setForm({
        salesFd: String(existing.salesFd),
        salesMtd: String(existing.salesMtd),
        dc: String(existing.dc),
        hc: String(existing.hc),
        present: String(existing.present),
        absent: String(existing.absent),
        attrition: String(existing.attrition),
        notes: existing.notes ?? "",
      });
    } else {
      setForm(EMPTY);
    }
  }, [existing, center]);

  const notify = (msg: string) => {
    if (Platform.OS === "web") window.alert(msg);
    else Alert.alert(msg);
  };

  const num = (v: string) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  };

  const onSubmit = async () => {
    if (!center) {
      notify("Please select a center.");
      return;
    }
    try {
      await upsert.mutateAsync({
        data: {
          center,
          date,
          salesFd: num(form.salesFd),
          salesMtd: num(form.salesMtd),
          dc: num(form.dc),
          hc: num(form.hc),
          present: num(form.present),
          absent: num(form.absent),
          attrition: num(form.attrition),
          notes: form.notes.trim() || null,
          // Rows are keyed by (submittedBy, date) server-side. When correcting a
          // report that already exists for this center (often filed by a Team
          // Leader), reuse its original submitter so we UPDATE that row instead
          // of clobbering the caller's own row. New reports use the caller's id.
          submittedBy: existing?.submittedBy ?? (user?.id ?? 0),
        },
      });
      qc.invalidateQueries({ queryKey: getListEodReportsQueryKey({ date }) });
      notify("EOD report saved.");
    } catch {
      notify("Could not save the EOD report. Please try again.");
    }
  };

  if (usersQuery.isLoading || reportsQuery.isLoading) return <LoadingState />;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 32, gap: 16 }}
      keyboardShouldPersistTaps="handled"
    >
      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>
        End-of-day report for {date}
      </Text>
      <Select label="Center" value={center} options={centerOptions} onChange={setCenter} />
      {existing ? (
        <Card style={{ paddingVertical: 10 }}>
          <Text style={{ fontFamily: "Inter_500Medium", fontSize: 12, color: colors.primary }}>
            Editing today's submitted report
          </Text>
        </Card>
      ) : null}

      <View style={styles.grid}>
        {NUMERIC_FIELDS.map((f) => (
          <View key={f.key} style={styles.gridItem}>
            <TextField
              label={f.label}
              value={form[f.key]}
              onChangeText={(t) => setForm((p) => ({ ...p, [f.key]: t }))}
              placeholder="0"
              keyboardType="numeric"
            />
          </View>
        ))}
      </View>

      <TextField
        label="Notes"
        value={form.notes}
        onChangeText={(t) => setForm((p) => ({ ...p, notes: t }))}
        placeholder="Optional remarks"
        multiline
      />

      <Button
        label={existing ? "Update Report" : "Submit Report"}
        icon="file-text"
        onPress={onSubmit}
        loading={upsert.isPending}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  gridItem: { width: "47%", flexGrow: 1 },
});
