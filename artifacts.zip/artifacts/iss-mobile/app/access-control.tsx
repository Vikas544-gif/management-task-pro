import type { User } from "@workspace/api-client-react";
import {
  getListUsersQueryKey,
  useForceRelogin,
  useListUsers,
  useUpdateUser,
} from "@workspace/api-client-react";
import { Feather } from "@expo/vector-icons";
import { useQueryClient } from "@tanstack/react-query";
import React, { useMemo, useState } from "react";
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Button, Card, EmptyState, LoadingState, Segmented, type Option } from "@/components/ui";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import {
  CENTER_ORDER,
  CONTROLLABLE_ITEMS,
  canManage,
  isAllCentersViewer,
  roleDefaultVisible,
} from "@/lib/permissions";

const HEAD_OFFICE = "Head Office";

const MODE_OPTIONS: Option[] = [
  { value: "default", label: "Default (by role)" },
  { value: "custom", label: "Custom access" },
];
const CENTER_MODE_OPTIONS: Option[] = [
  { value: "default", label: "Default (all centers)" },
  { value: "custom", label: "Custom centers" },
];
const ASSIGN_MODE_OPTIONS: Option[] = [
  { value: "default", label: "Default (by rules)" },
  { value: "custom", label: "Custom people" },
];

function CheckRow({
  label,
  detail,
  checked,
  disabled,
  onToggle,
  emoji,
}: {
  label: string;
  detail?: string;
  checked: boolean;
  disabled?: boolean;
  onToggle: () => void;
  emoji?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={disabled ? undefined : onToggle}
      style={[
        styles.checkRow,
        {
          borderColor: colors.border,
          backgroundColor: disabled ? colors.muted : colors.card,
          opacity: checked ? 1 : 0.6,
        },
      ]}
    >
      <Feather
        name={checked ? "check-square" : "square"}
        size={20}
        color={checked ? colors.primary : colors.mutedForeground}
      />
      {emoji ? <Text style={{ fontSize: 15 }}>{emoji}</Text> : null}
      <Text
        style={{ flex: 1, fontFamily: "Inter_500Medium", fontSize: 14, color: colors.foreground }}
        numberOfLines={1}
      >
        {label}
      </Text>
      {detail ? (
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground }}>
          {detail}
        </Text>
      ) : null}
    </Pressable>
  );
}

export default function AccessControlScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const { user: currentUser } = useAuth();

  const usersQuery = useListUsers({ query: { queryKey: getListUsersQueryKey() } });
  const updateUser = useUpdateUser();
  const forceRelogin = useForceRelogin();

  const users = usersQuery.data ?? [];

  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [mode, setMode] = useState<"default" | "custom">("default");
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const [centerMode, setCenterMode] = useState<"default" | "custom">("default");
  const [centerChecked, setCenterChecked] = useState<Set<string>>(new Set());
  const [assignMode, setAssignMode] = useState<"default" | "custom">("default");
  const [assignChecked, setAssignChecked] = useState<Set<number>>(new Set());
  const [autoTasks, setAutoTasks] = useState(true);
  const [saved, setSaved] = useState(false);

  const loginUsers = useMemo(
    () =>
      users
        .filter((u) => !!u.username)
        .sort((a, b) => (a.center ?? "").localeCompare(b.center ?? "") || a.name.localeCompare(b.name)),
    [users]
  );

  const byCenter = useMemo(() => {
    const map = new Map<string, User[]>();
    for (const u of loginUsers) {
      const c = u.center ?? "—";
      if (!map.has(c)) map.set(c, []);
      map.get(c)!.push(u);
    }
    return map;
  }, [loginUsers]);

  const selected = users.find((u) => u.id === selectedId) ?? null;

  const allCenters = useMemo(() => {
    const set = new Set<string>([
      ...CENTER_ORDER,
      ...users.map((u) => u.center).filter((c): c is string => Boolean(c)),
    ]);
    const rank = (c: string) => {
      const i = CENTER_ORDER.indexOf(c);
      return i === -1 ? CENTER_ORDER.length : i;
    };
    return Array.from(set).sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
  }, [users]);

  const selectedIsBoss = !!selected && (selected.department === "Management" || selected.role === "Boss");
  const selectedIsAllViewer = isAllCentersViewer(selected);
  const centerEligible = selectedIsBoss || selectedIsAllViewer;
  const centerCeiling = useMemo(
    () => (selectedIsBoss ? allCenters : allCenters.filter((c) => c !== HEAD_OFFICE)),
    [selectedIsBoss, allCenters]
  );

  const selectUser = (id: number) => {
    const u = users.find((x) => x.id === id);
    setSelectedId(id);
    setSaved(false);
    const perms = u?.pagePermissions;
    if (perms == null) {
      setMode("default");
      const base = new Set<string>(
        CONTROLLABLE_ITEMS.filter((item) => roleDefaultVisible(item, u, users)).map((i) => i.href)
      );
      setChecked(base);
    } else {
      setMode("custom");
      setChecked(new Set(perms));
    }
    const cperms = u?.centerPermissions;
    const uIsBoss = !!u && (u.department === "Management" || u.role === "Boss");
    const ceiling = uIsBoss ? allCenters : allCenters.filter((c) => c !== HEAD_OFFICE);
    if (cperms == null) {
      setCenterMode("default");
      setCenterChecked(new Set(ceiling));
    } else {
      setCenterMode("custom");
      setCenterChecked(new Set(cperms));
    }
    const avis = u?.assignVisibleUserIds;
    if (avis == null) {
      setAssignMode("default");
      setAssignChecked(new Set());
    } else {
      setAssignMode("custom");
      setAssignChecked(new Set(avis));
    }
    setAutoTasks(u?.autoTasksEnabled !== false);
  };

  const toggle = (href: string) => {
    setChecked((prev) => {
      const next = new Set(prev);
      if (next.has(href)) next.delete(href);
      else next.add(href);
      return next;
    });
    setSaved(false);
  };

  const centerToggle = (center: string) => {
    setCenterChecked((prev) => {
      const next = new Set(prev);
      if (next.has(center)) next.delete(center);
      else next.add(center);
      return next;
    });
    setSaved(false);
  };

  const assignToggle = (uid: number) => {
    setAssignChecked((prev) => {
      const next = new Set(prev);
      if (next.has(uid)) next.delete(uid);
      else next.add(uid);
      return next;
    });
    setSaved(false);
  };

  const notify = (msg: string) => {
    if (Platform.OS === "web") window.alert(msg);
    else Alert.alert(msg);
  };

  const handleSave = () => {
    if (!selected) return;
    const pagePermissions = mode === "default" ? null : Array.from(checked);
    const centerPermissions =
      !centerEligible || centerMode === "default"
        ? null
        : centerCeiling.filter((c) => centerChecked.has(c));
    const assignVisibleUserIds =
      assignMode === "default"
        ? null
        : Array.from(assignChecked).filter((uid) => uid !== selected.id);
    updateUser.mutate(
      { id: selected.id, data: { pagePermissions, centerPermissions, assignVisibleUserIds, autoTasksEnabled: autoTasks } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListUsersQueryKey() });
          setSaved(true);
        },
        onError: () => notify("Could not save access. Please try again."),
      }
    );
  };

  const doForceRelogin = () => {
    forceRelogin.mutate(undefined, {
      onSuccess: () =>
        notify("Done. Everyone else has been logged out and will need to log in again. You stay logged in."),
      onError: () => notify("Something went wrong. Please try again."),
    });
  };

  const confirmForceRelogin = () => {
    const message =
      "This logs out all other users immediately — they'll have to log in again to keep using the app. You will stay logged in.";
    if (Platform.OS === "web") {
      if (window.confirm(message)) doForceRelogin();
    } else {
      Alert.alert("Force everyone to re-login?", message, [
        { text: "Cancel", style: "cancel" },
        { text: "Yes, log everyone out", style: "destructive", onPress: doForceRelogin },
      ]);
    }
  };

  if (usersQuery.isLoading) return <LoadingState />;

  if (!canManage(currentUser)) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background, justifyContent: "center" }}>
        <EmptyState
          icon="lock"
          title="Access denied"
          message="Only Boss and MIS-level people can manage access control."
        />
      </View>
    );
  }

  // ── Editor view ──────────────────────────────────────────────────────────
  if (selected) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 32, gap: 16 }}>
          <Pressable
            onPress={() => setSelectedId(null)}
            style={{ flexDirection: "row", alignItems: "center", gap: 6 }}
          >
            <Feather name="chevron-left" size={18} color={colors.primary} />
            <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.primary }}>
              Back to people
            </Text>
          </Pressable>

          <Card style={{ gap: 4 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
              <Text style={{ fontFamily: "Inter_700Bold", fontSize: 17, color: colors.foreground }}>
                {selected.name}
                {selected.id === currentUser?.id ? " (you)" : ""}
              </Text>
              {saved ? (
                <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 12, color: colors.success }}>
                  ✓ Saved
                </Text>
              ) : null}
            </View>
            <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
              {selected.role} · {selected.department} · {selected.center ?? "—"}
            </Text>
          </Card>

          {/* Page access */}
          <View style={{ gap: 10 }}>
            <Text style={[styles.section, { color: colors.mutedForeground }]}>PAGE ACCESS</Text>
            <Segmented
              options={MODE_OPTIONS}
              value={mode}
              onChange={(v) => {
                setMode(v as "default" | "custom");
                setSaved(false);
              }}
            />
            <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
              {mode === "default"
                ? "This person sees the sections their role normally allows (shown below, read-only)."
                : "Untick a section to hide it from this person. You can only hide sections their role already allows — you can never grant a section their role doesn't include."}
            </Text>
            <View style={{ gap: 8 }}>
              {CONTROLLABLE_ITEMS.map((item) => {
                const roleAllowed = roleDefaultVisible(item, selected, users);
                const disabled = mode === "default" || !roleAllowed;
                const on = !roleAllowed ? false : mode === "default" ? roleAllowed : checked.has(item.href);
                return (
                  <CheckRow
                    key={item.href}
                    label={item.label}
                    emoji={item.icon}
                    checked={on}
                    disabled={disabled}
                    onToggle={() => toggle(item.href)}
                    detail={mode === "custom" && !roleAllowed ? "not for this role" : undefined}
                  />
                );
              })}
            </View>
          </View>

          {/* Center access */}
          <View style={{ gap: 10 }}>
            <Text style={[styles.section, { color: colors.mutedForeground }]}>CENTER ACCESS</Text>
            {!centerEligible ? (
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                Center access only applies to Boss and MIS-level people who can see every center. This person is
                already limited to their own center by their role, so there is nothing to restrict here.
              </Text>
            ) : (
              <>
                <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                  By default this person sees every center their role allows. Switch to custom to limit them to
                  specific centers — you can only narrow what their role already allows, never grant beyond it.
                </Text>
                <Segmented
                  options={CENTER_MODE_OPTIONS}
                  value={centerMode}
                  onChange={(v) => {
                    setCenterMode(v as "default" | "custom");
                    setSaved(false);
                  }}
                />
                <View style={{ gap: 8 }}>
                  {allCenters.map((center) => {
                    const roleAllowed = centerCeiling.includes(center);
                    const disabled = centerMode === "default" || !roleAllowed;
                    const on = !roleAllowed ? false : centerMode === "default" ? true : centerChecked.has(center);
                    return (
                      <CheckRow
                        key={center}
                        label={center}
                        checked={on}
                        disabled={disabled}
                        onToggle={() => centerToggle(center)}
                        detail={centerMode === "custom" && !roleAllowed ? "not for this role" : undefined}
                      />
                    );
                  })}
                </View>
              </>
            )}
          </View>

          {/* Assign-list visibility */}
          <View style={{ gap: 10 }}>
            <Text style={[styles.section, { color: colors.mutedForeground }]}>ASSIGN-LIST VISIBILITY</Text>
            <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
              Controls who appears in {selected.name}'s "Assign To" dropdown on the Assign Task page. By default it
              follows the normal center rules. Switch to custom to choose exactly which people they can assign tasks
              to — everyone else is hidden from their picker.
            </Text>
            <Segmented
              options={ASSIGN_MODE_OPTIONS}
              value={assignMode}
              onChange={(v) => {
                setAssignMode(v as "default" | "custom");
                setSaved(false);
              }}
            />
            {assignMode === "custom" ? (
              <View style={{ gap: 12 }}>
                {Array.from(byCenter.entries()).map(([center, members]) => {
                  const selectable = members.filter((u) => u.id !== selected.id);
                  if (selectable.length === 0) return null;
                  return (
                    <View key={center} style={{ gap: 8 }}>
                      <Text style={[styles.subLabel, { color: colors.mutedForeground }]}>
                        {center.toUpperCase()}
                      </Text>
                      {selectable.map((u) => (
                        <CheckRow
                          key={u.id}
                          label={u.name}
                          detail={u.role ?? undefined}
                          checked={assignChecked.has(u.id)}
                          onToggle={() => assignToggle(u.id)}
                        />
                      ))}
                    </View>
                  );
                })}
              </View>
            ) : null}
          </View>

          {/* Auto-generate recurring tasks */}
          <View style={{ gap: 10 }}>
            <Text style={[styles.section, { color: colors.mutedForeground }]}>AUTO-GENERATE RECURRING TASKS</Text>
            <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
              When ON, the system automatically creates this person's daily / weekly / monthly recurring tasks. Turn
              it OFF to stop generating tasks for {selected.name} — their existing recurring tasks will also be
              removed. Turn it back ON any time to resume.
            </Text>
            <CheckRow
              label={autoTasks ? "Auto-generation is ON" : "Auto-generation is OFF"}
              detail={autoTasks ? "Tasks are created automatically" : "No tasks will be created"}
              checked={autoTasks}
              onToggle={() => {
                setAutoTasks((v) => !v);
                setSaved(false);
              }}
            />
          </View>

          <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
            <Button
              label={updateUser.isPending ? "Saving..." : "Save access"}
              icon="save"
              onPress={handleSave}
              loading={updateUser.isPending}
              style={{ flex: 1 }}
            />
            {mode === "custom" ? (
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground }}>
                {checked.size} section{checked.size === 1 ? "" : "s"} allowed
              </Text>
            ) : null}
          </View>
        </ScrollView>
      </View>
    );
  }

  // ── People list view ─────────────────────────────────────────────────────
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 32, gap: 16 }}>
        <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground }}>
          Choose which sections each person can open. By default everyone follows their role's rules — switch a
          person to custom access to hide or show specific sections just for them.
        </Text>

        <Button
          label="Force everyone to re-login"
          icon="refresh-cw"
          variant="secondary"
          onPress={confirmForceRelogin}
          loading={forceRelogin.isPending}
        />

        {loginUsers.length === 0 ? (
          <View style={{ paddingTop: 60 }}>
            <EmptyState icon="users" title="No people" message="People who can log in will appear here." />
          </View>
        ) : (
          Array.from(byCenter.entries()).map(([center, members]) => (
            <View key={center} style={{ gap: 8 }}>
              <Text style={[styles.subLabel, { color: colors.mutedForeground }]}>{center.toUpperCase()}</Text>
              <Card style={{ padding: 0 }}>
                {members.map((u, i) => {
                  const custom =
                    u.pagePermissions != null ||
                    u.centerPermissions != null ||
                    u.assignVisibleUserIds != null;
                  return (
                    <Pressable
                      key={u.id}
                      onPress={() => selectUser(u.id)}
                      style={[
                        styles.personRow,
                        i < members.length - 1
                          ? { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth }
                          : null,
                      ]}
                    >
                      <Text
                        style={{ flex: 1, fontFamily: "Inter_500Medium", fontSize: 15, color: colors.foreground }}
                        numberOfLines={1}
                      >
                        {u.name}
                        {u.id === currentUser?.id ? " (you)" : ""}
                      </Text>
                      {custom ? (
                        <View style={[styles.badge, { backgroundColor: colors.warning + "22" }]}>
                          <Text style={{ fontFamily: "Inter_700Bold", fontSize: 10, color: colors.warning }}>
                            CUSTOM
                          </Text>
                        </View>
                      ) : null}
                      <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
                    </Pressable>
                  );
                })}
              </Card>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  section: { fontFamily: "Inter_600SemiBold", fontSize: 12, letterSpacing: 0.6, marginLeft: 2 },
  subLabel: { fontFamily: "Inter_600SemiBold", fontSize: 11, letterSpacing: 0.6, marginLeft: 2 },
  checkRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: 12,
  },
  personRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 16, paddingVertical: 14 },
  badge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
});
